--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Debian 16.9-1.pgdg120+1)
-- Dumped by pg_dump version 16.9 (Debian 16.9-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attr_dept_higher_ed_001_budget_breakdown; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_higher_ed_001_budget_breakdown (
    id integer NOT NULL,
    entity_attribute_id integer,
    category text NOT NULL,
    allocated integer NOT NULL,
    spent integer NOT NULL,
    remaining integer NOT NULL,
    percentage text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_higher_ed_001_budget_breakdown OWNER TO postgres;

--
-- Name: attr_dept_higher_ed_001_budget_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_higher_ed_001_budget_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_higher_ed_001_budget_breakdown_id_seq OWNER TO postgres;

--
-- Name: attr_dept_higher_ed_001_budget_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_higher_ed_001_budget_breakdown_id_seq OWNED BY public.attr_dept_higher_ed_001_budget_breakdown.id;


--
-- Name: attr_dept_higher_ed_001_department_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_higher_ed_001_department_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    field text NOT NULL,
    value text NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_higher_ed_001_department_information OWNER TO postgres;

--
-- Name: attr_dept_higher_ed_001_department_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_higher_ed_001_department_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_higher_ed_001_department_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_higher_ed_001_department_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_higher_ed_001_department_information_id_seq OWNED BY public.attr_dept_higher_ed_001_department_information.id;


--
-- Name: attr_dept_higher_ed_001_project_portfolio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_higher_ed_001_project_portfolio (
    id integer NOT NULL,
    entity_attribute_id integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    progress text NOT NULL,
    project_name text NOT NULL,
    status text NOT NULL,
    budget integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_higher_ed_001_project_portfolio OWNER TO postgres;

--
-- Name: attr_dept_higher_ed_001_project_portfolio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_higher_ed_001_project_portfolio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_higher_ed_001_project_portfolio_id_seq OWNER TO postgres;

--
-- Name: attr_dept_higher_ed_001_project_portfolio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_higher_ed_001_project_portfolio_id_seq OWNED BY public.attr_dept_higher_ed_001_project_portfolio.id;


--
-- Name: attr_dept_higher_ed_001_staff_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_higher_ed_001_staff_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    salary_grade text NOT NULL,
    department text NOT NULL,
    "position" text NOT NULL,
    count integer NOT NULL,
    vacant integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_higher_ed_001_staff_information OWNER TO postgres;

--
-- Name: attr_dept_higher_ed_001_staff_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_higher_ed_001_staff_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_higher_ed_001_staff_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_higher_ed_001_staff_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_higher_ed_001_staff_information_id_seq OWNED BY public.attr_dept_higher_ed_001_staff_information.id;


--
-- Name: attr_dept_hospitals_001_budget_breakdown; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_hospitals_001_budget_breakdown (
    id integer NOT NULL,
    entity_attribute_id integer,
    allocated integer NOT NULL,
    spent integer NOT NULL,
    remaining integer NOT NULL,
    percentage text NOT NULL,
    category text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_hospitals_001_budget_breakdown OWNER TO postgres;

--
-- Name: attr_dept_hospitals_001_budget_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_hospitals_001_budget_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_hospitals_001_budget_breakdown_id_seq OWNER TO postgres;

--
-- Name: attr_dept_hospitals_001_budget_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_hospitals_001_budget_breakdown_id_seq OWNED BY public.attr_dept_hospitals_001_budget_breakdown.id;


--
-- Name: attr_dept_hospitals_001_department_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_hospitals_001_department_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    field text NOT NULL,
    value text NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_hospitals_001_department_information OWNER TO postgres;

--
-- Name: attr_dept_hospitals_001_department_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_hospitals_001_department_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_hospitals_001_department_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_hospitals_001_department_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_hospitals_001_department_information_id_seq OWNED BY public.attr_dept_hospitals_001_department_information.id;


--
-- Name: attr_dept_hospitals_001_project_portfolio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_hospitals_001_project_portfolio (
    id integer NOT NULL,
    entity_attribute_id integer,
    progress text NOT NULL,
    project_name text NOT NULL,
    status text NOT NULL,
    budget integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_hospitals_001_project_portfolio OWNER TO postgres;

--
-- Name: attr_dept_hospitals_001_project_portfolio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_hospitals_001_project_portfolio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_hospitals_001_project_portfolio_id_seq OWNER TO postgres;

--
-- Name: attr_dept_hospitals_001_project_portfolio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_hospitals_001_project_portfolio_id_seq OWNED BY public.attr_dept_hospitals_001_project_portfolio.id;


--
-- Name: attr_dept_hospitals_001_staff_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_hospitals_001_staff_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    vacant integer NOT NULL,
    salary_grade text NOT NULL,
    department text NOT NULL,
    "position" text NOT NULL,
    count integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_hospitals_001_staff_information OWNER TO postgres;

--
-- Name: attr_dept_hospitals_001_staff_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_hospitals_001_staff_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_hospitals_001_staff_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_hospitals_001_staff_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_hospitals_001_staff_information_id_seq OWNED BY public.attr_dept_hospitals_001_staff_information.id;


--
-- Name: attr_dept_ict_001_budget_breakdown; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_ict_001_budget_breakdown (
    id integer NOT NULL,
    entity_attribute_id integer,
    allocated integer NOT NULL,
    spent integer NOT NULL,
    remaining integer NOT NULL,
    percentage text NOT NULL,
    category text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_ict_001_budget_breakdown OWNER TO postgres;

--
-- Name: attr_dept_ict_001_budget_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_ict_001_budget_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_ict_001_budget_breakdown_id_seq OWNER TO postgres;

--
-- Name: attr_dept_ict_001_budget_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_ict_001_budget_breakdown_id_seq OWNED BY public.attr_dept_ict_001_budget_breakdown.id;


--
-- Name: attr_dept_ict_001_department_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_ict_001_department_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    field text NOT NULL,
    value text NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_ict_001_department_information OWNER TO postgres;

--
-- Name: attr_dept_ict_001_department_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_ict_001_department_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_ict_001_department_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_ict_001_department_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_ict_001_department_information_id_seq OWNED BY public.attr_dept_ict_001_department_information.id;


--
-- Name: attr_dept_ict_001_project_portfolio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_ict_001_project_portfolio (
    id integer NOT NULL,
    entity_attribute_id integer,
    project_name text NOT NULL,
    status text NOT NULL,
    budget integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    progress text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_ict_001_project_portfolio OWNER TO postgres;

--
-- Name: attr_dept_ict_001_project_portfolio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_ict_001_project_portfolio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_ict_001_project_portfolio_id_seq OWNER TO postgres;

--
-- Name: attr_dept_ict_001_project_portfolio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_ict_001_project_portfolio_id_seq OWNED BY public.attr_dept_ict_001_project_portfolio.id;


--
-- Name: attr_dept_ict_001_staff_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_ict_001_staff_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    "position" text NOT NULL,
    count integer NOT NULL,
    vacant integer NOT NULL,
    salary_grade text NOT NULL,
    department text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_ict_001_staff_information OWNER TO postgres;

--
-- Name: attr_dept_ict_001_staff_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_ict_001_staff_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_ict_001_staff_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_ict_001_staff_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_ict_001_staff_information_id_seq OWNED BY public.attr_dept_ict_001_staff_information.id;


--
-- Name: attr_dept_innovation_001_budget_breakdown; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_innovation_001_budget_breakdown (
    id integer NOT NULL,
    entity_attribute_id integer,
    allocated integer NOT NULL,
    spent integer NOT NULL,
    remaining integer NOT NULL,
    percentage text NOT NULL,
    category text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_innovation_001_budget_breakdown OWNER TO postgres;

--
-- Name: attr_dept_innovation_001_budget_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_innovation_001_budget_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_innovation_001_budget_breakdown_id_seq OWNER TO postgres;

--
-- Name: attr_dept_innovation_001_budget_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_innovation_001_budget_breakdown_id_seq OWNED BY public.attr_dept_innovation_001_budget_breakdown.id;


--
-- Name: attr_dept_innovation_001_department_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_innovation_001_department_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    field text NOT NULL,
    value text NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_innovation_001_department_information OWNER TO postgres;

--
-- Name: attr_dept_innovation_001_department_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_innovation_001_department_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_innovation_001_department_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_innovation_001_department_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_innovation_001_department_information_id_seq OWNED BY public.attr_dept_innovation_001_department_information.id;


--
-- Name: attr_dept_innovation_001_project_portfolio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_innovation_001_project_portfolio (
    id integer NOT NULL,
    entity_attribute_id integer,
    end_date date NOT NULL,
    progress text NOT NULL,
    project_name text NOT NULL,
    status text NOT NULL,
    budget integer NOT NULL,
    start_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_innovation_001_project_portfolio OWNER TO postgres;

--
-- Name: attr_dept_innovation_001_project_portfolio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_innovation_001_project_portfolio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_innovation_001_project_portfolio_id_seq OWNER TO postgres;

--
-- Name: attr_dept_innovation_001_project_portfolio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_innovation_001_project_portfolio_id_seq OWNED BY public.attr_dept_innovation_001_project_portfolio.id;


--
-- Name: attr_dept_innovation_001_staff_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_innovation_001_staff_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    "position" text NOT NULL,
    count integer NOT NULL,
    vacant integer NOT NULL,
    salary_grade text NOT NULL,
    department text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_innovation_001_staff_information OWNER TO postgres;

--
-- Name: attr_dept_innovation_001_staff_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_innovation_001_staff_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_innovation_001_staff_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_innovation_001_staff_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_innovation_001_staff_information_id_seq OWNED BY public.attr_dept_innovation_001_staff_information.id;


--
-- Name: attr_dept_public_health_001_budget_breakdown; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_public_health_001_budget_breakdown (
    id integer NOT NULL,
    entity_attribute_id integer,
    remaining integer NOT NULL,
    percentage text NOT NULL,
    category text NOT NULL,
    allocated integer NOT NULL,
    spent integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_public_health_001_budget_breakdown OWNER TO postgres;

--
-- Name: attr_dept_public_health_001_budget_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_public_health_001_budget_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_public_health_001_budget_breakdown_id_seq OWNER TO postgres;

--
-- Name: attr_dept_public_health_001_budget_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_public_health_001_budget_breakdown_id_seq OWNED BY public.attr_dept_public_health_001_budget_breakdown.id;


--
-- Name: attr_dept_public_health_001_department_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_public_health_001_department_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    field text NOT NULL,
    value text NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_public_health_001_department_information OWNER TO postgres;

--
-- Name: attr_dept_public_health_001_department_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_public_health_001_department_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_public_health_001_department_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_public_health_001_department_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_public_health_001_department_information_id_seq OWNED BY public.attr_dept_public_health_001_department_information.id;


--
-- Name: attr_dept_public_health_001_project_portfolio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_public_health_001_project_portfolio (
    id integer NOT NULL,
    entity_attribute_id integer,
    budget integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    progress text NOT NULL,
    project_name text NOT NULL,
    status text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_public_health_001_project_portfolio OWNER TO postgres;

--
-- Name: attr_dept_public_health_001_project_portfolio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_public_health_001_project_portfolio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_public_health_001_project_portfolio_id_seq OWNER TO postgres;

--
-- Name: attr_dept_public_health_001_project_portfolio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_public_health_001_project_portfolio_id_seq OWNED BY public.attr_dept_public_health_001_project_portfolio.id;


--
-- Name: attr_dept_public_health_001_staff_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_public_health_001_staff_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    department text NOT NULL,
    "position" text NOT NULL,
    count integer NOT NULL,
    vacant integer NOT NULL,
    salary_grade text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_public_health_001_staff_information OWNER TO postgres;

--
-- Name: attr_dept_public_health_001_staff_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_public_health_001_staff_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_public_health_001_staff_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_public_health_001_staff_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_public_health_001_staff_information_id_seq OWNED BY public.attr_dept_public_health_001_staff_information.id;


--
-- Name: attr_dept_schools_001_budget_breakdown; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_schools_001_budget_breakdown (
    id integer NOT NULL,
    entity_attribute_id integer,
    category text NOT NULL,
    allocated integer NOT NULL,
    spent integer NOT NULL,
    remaining integer NOT NULL,
    percentage text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_schools_001_budget_breakdown OWNER TO postgres;

--
-- Name: attr_dept_schools_001_budget_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_schools_001_budget_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_schools_001_budget_breakdown_id_seq OWNER TO postgres;

--
-- Name: attr_dept_schools_001_budget_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_schools_001_budget_breakdown_id_seq OWNED BY public.attr_dept_schools_001_budget_breakdown.id;


--
-- Name: attr_dept_schools_001_department_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_schools_001_department_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    field text NOT NULL,
    value text NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_schools_001_department_information OWNER TO postgres;

--
-- Name: attr_dept_schools_001_department_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_schools_001_department_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_schools_001_department_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_schools_001_department_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_schools_001_department_information_id_seq OWNED BY public.attr_dept_schools_001_department_information.id;


--
-- Name: attr_dept_schools_001_project_portfolio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_schools_001_project_portfolio (
    id integer NOT NULL,
    entity_attribute_id integer,
    budget integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    progress text NOT NULL,
    project_name text NOT NULL,
    status text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_schools_001_project_portfolio OWNER TO postgres;

--
-- Name: attr_dept_schools_001_project_portfolio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_schools_001_project_portfolio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_schools_001_project_portfolio_id_seq OWNER TO postgres;

--
-- Name: attr_dept_schools_001_project_portfolio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_schools_001_project_portfolio_id_seq OWNED BY public.attr_dept_schools_001_project_portfolio.id;


--
-- Name: attr_dept_schools_001_staff_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_dept_schools_001_staff_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    salary_grade text NOT NULL,
    department text NOT NULL,
    "position" text NOT NULL,
    count integer NOT NULL,
    vacant integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_dept_schools_001_staff_information OWNER TO postgres;

--
-- Name: attr_dept_schools_001_staff_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_dept_schools_001_staff_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_dept_schools_001_staff_information_id_seq OWNER TO postgres;

--
-- Name: attr_dept_schools_001_staff_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_dept_schools_001_staff_information_id_seq OWNED BY public.attr_dept_schools_001_staff_information.id;


--
-- Name: attr_minister_education_001_budget_allocation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_minister_education_001_budget_allocation (
    id integer NOT NULL,
    entity_attribute_id integer,
    allocated_amount integer NOT NULL,
    spent_amount integer NOT NULL,
    remaining integer NOT NULL,
    fiscal_year text NOT NULL,
    category text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_minister_education_001_budget_allocation OWNER TO postgres;

--
-- Name: attr_minister_education_001_budget_allocation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_minister_education_001_budget_allocation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_minister_education_001_budget_allocation_id_seq OWNER TO postgres;

--
-- Name: attr_minister_education_001_budget_allocation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_minister_education_001_budget_allocation_id_seq OWNED BY public.attr_minister_education_001_budget_allocation.id;


--
-- Name: attr_minister_education_001_performance_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_minister_education_001_performance_metrics (
    id integer NOT NULL,
    entity_attribute_id integer,
    metric text NOT NULL,
    target text NOT NULL,
    actual text NOT NULL,
    period text NOT NULL,
    status text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_minister_education_001_performance_metrics OWNER TO postgres;

--
-- Name: attr_minister_education_001_performance_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_minister_education_001_performance_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_minister_education_001_performance_metrics_id_seq OWNER TO postgres;

--
-- Name: attr_minister_education_001_performance_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_minister_education_001_performance_metrics_id_seq OWNED BY public.attr_minister_education_001_performance_metrics.id;


--
-- Name: attr_minister_education_001_personal_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_minister_education_001_personal_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    value text NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    field text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_minister_education_001_personal_information OWNER TO postgres;

--
-- Name: attr_minister_education_001_personal_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_minister_education_001_personal_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_minister_education_001_personal_information_id_seq OWNER TO postgres;

--
-- Name: attr_minister_education_001_personal_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_minister_education_001_personal_information_id_seq OWNED BY public.attr_minister_education_001_personal_information.id;


--
-- Name: attr_minister_health_001_budget_allocation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_minister_health_001_budget_allocation (
    id integer NOT NULL,
    entity_attribute_id integer,
    category text NOT NULL,
    allocated_amount integer NOT NULL,
    spent_amount integer NOT NULL,
    remaining integer NOT NULL,
    fiscal_year text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_minister_health_001_budget_allocation OWNER TO postgres;

--
-- Name: attr_minister_health_001_budget_allocation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_minister_health_001_budget_allocation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_minister_health_001_budget_allocation_id_seq OWNER TO postgres;

--
-- Name: attr_minister_health_001_budget_allocation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_minister_health_001_budget_allocation_id_seq OWNED BY public.attr_minister_health_001_budget_allocation.id;


--
-- Name: attr_minister_health_001_performance_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_minister_health_001_performance_metrics (
    id integer NOT NULL,
    entity_attribute_id integer,
    actual text NOT NULL,
    period text NOT NULL,
    status text NOT NULL,
    metric text NOT NULL,
    target text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_minister_health_001_performance_metrics OWNER TO postgres;

--
-- Name: attr_minister_health_001_performance_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_minister_health_001_performance_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_minister_health_001_performance_metrics_id_seq OWNER TO postgres;

--
-- Name: attr_minister_health_001_performance_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_minister_health_001_performance_metrics_id_seq OWNED BY public.attr_minister_health_001_performance_metrics.id;


--
-- Name: attr_minister_health_001_personal_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_minister_health_001_personal_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    last_updated timestamp with time zone NOT NULL,
    field text NOT NULL,
    value text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_minister_health_001_personal_information OWNER TO postgres;

--
-- Name: attr_minister_health_001_personal_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_minister_health_001_personal_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_minister_health_001_personal_information_id_seq OWNER TO postgres;

--
-- Name: attr_minister_health_001_personal_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_minister_health_001_personal_information_id_seq OWNED BY public.attr_minister_health_001_personal_information.id;


--
-- Name: attr_minister_tech_001_budget_allocation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_minister_tech_001_budget_allocation (
    id integer NOT NULL,
    entity_attribute_id integer,
    remaining integer NOT NULL,
    fiscal_year text NOT NULL,
    category text NOT NULL,
    allocated_amount integer NOT NULL,
    spent_amount integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_minister_tech_001_budget_allocation OWNER TO postgres;

--
-- Name: attr_minister_tech_001_budget_allocation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_minister_tech_001_budget_allocation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_minister_tech_001_budget_allocation_id_seq OWNER TO postgres;

--
-- Name: attr_minister_tech_001_budget_allocation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_minister_tech_001_budget_allocation_id_seq OWNED BY public.attr_minister_tech_001_budget_allocation.id;


--
-- Name: attr_minister_tech_001_performance_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_minister_tech_001_performance_metrics (
    id integer NOT NULL,
    entity_attribute_id integer,
    status text NOT NULL,
    metric text NOT NULL,
    target text NOT NULL,
    actual text NOT NULL,
    period text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_minister_tech_001_performance_metrics OWNER TO postgres;

--
-- Name: attr_minister_tech_001_performance_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_minister_tech_001_performance_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_minister_tech_001_performance_metrics_id_seq OWNER TO postgres;

--
-- Name: attr_minister_tech_001_performance_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_minister_tech_001_performance_metrics_id_seq OWNED BY public.attr_minister_tech_001_performance_metrics.id;


--
-- Name: attr_minister_tech_001_personal_information; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_minister_tech_001_personal_information (
    id integer NOT NULL,
    entity_attribute_id integer,
    field text NOT NULL,
    value text NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_minister_tech_001_personal_information OWNER TO postgres;

--
-- Name: attr_minister_tech_001_personal_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_minister_tech_001_personal_information_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_minister_tech_001_personal_information_id_seq OWNER TO postgres;

--
-- Name: attr_minister_tech_001_personal_information_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_minister_tech_001_personal_information_id_seq OWNED BY public.attr_minister_tech_001_personal_information.id;


--
-- Name: attribute_schemas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attribute_schemas (
    id integer NOT NULL,
    table_name character varying(255) NOT NULL,
    schema_version integer NOT NULL,
    schema_definition jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attribute_schemas OWNER TO postgres;

--
-- Name: attribute_schemas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attribute_schemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attribute_schemas_id_seq OWNER TO postgres;

--
-- Name: attribute_schemas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attribute_schemas_id_seq OWNED BY public.attribute_schemas.id;


--
-- Name: entity_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entity_attributes (
    id integer NOT NULL,
    entity_id character varying(255) NOT NULL,
    attribute_name character varying(255) NOT NULL,
    table_name character varying(255) NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.entity_attributes OWNER TO postgres;

--
-- Name: entity_attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.entity_attributes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.entity_attributes_id_seq OWNER TO postgres;

--
-- Name: entity_attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.entity_attributes_id_seq OWNED BY public.entity_attributes.id;


--
-- Name: attr_dept_higher_ed_001_budget_breakdown id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_budget_breakdown ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_higher_ed_001_budget_breakdown_id_seq'::regclass);


--
-- Name: attr_dept_higher_ed_001_department_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_department_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_higher_ed_001_department_information_id_seq'::regclass);


--
-- Name: attr_dept_higher_ed_001_project_portfolio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_project_portfolio ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_higher_ed_001_project_portfolio_id_seq'::regclass);


--
-- Name: attr_dept_higher_ed_001_staff_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_staff_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_higher_ed_001_staff_information_id_seq'::regclass);


--
-- Name: attr_dept_hospitals_001_budget_breakdown id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_budget_breakdown ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_hospitals_001_budget_breakdown_id_seq'::regclass);


--
-- Name: attr_dept_hospitals_001_department_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_department_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_hospitals_001_department_information_id_seq'::regclass);


--
-- Name: attr_dept_hospitals_001_project_portfolio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_project_portfolio ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_hospitals_001_project_portfolio_id_seq'::regclass);


--
-- Name: attr_dept_hospitals_001_staff_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_staff_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_hospitals_001_staff_information_id_seq'::regclass);


--
-- Name: attr_dept_ict_001_budget_breakdown id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_budget_breakdown ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_ict_001_budget_breakdown_id_seq'::regclass);


--
-- Name: attr_dept_ict_001_department_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_department_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_ict_001_department_information_id_seq'::regclass);


--
-- Name: attr_dept_ict_001_project_portfolio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_project_portfolio ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_ict_001_project_portfolio_id_seq'::regclass);


--
-- Name: attr_dept_ict_001_staff_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_staff_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_ict_001_staff_information_id_seq'::regclass);


--
-- Name: attr_dept_innovation_001_budget_breakdown id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_budget_breakdown ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_innovation_001_budget_breakdown_id_seq'::regclass);


--
-- Name: attr_dept_innovation_001_department_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_department_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_innovation_001_department_information_id_seq'::regclass);


--
-- Name: attr_dept_innovation_001_project_portfolio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_project_portfolio ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_innovation_001_project_portfolio_id_seq'::regclass);


--
-- Name: attr_dept_innovation_001_staff_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_staff_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_innovation_001_staff_information_id_seq'::regclass);


--
-- Name: attr_dept_public_health_001_budget_breakdown id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_budget_breakdown ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_public_health_001_budget_breakdown_id_seq'::regclass);


--
-- Name: attr_dept_public_health_001_department_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_department_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_public_health_001_department_information_id_seq'::regclass);


--
-- Name: attr_dept_public_health_001_project_portfolio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_project_portfolio ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_public_health_001_project_portfolio_id_seq'::regclass);


--
-- Name: attr_dept_public_health_001_staff_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_staff_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_public_health_001_staff_information_id_seq'::regclass);


--
-- Name: attr_dept_schools_001_budget_breakdown id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_budget_breakdown ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_schools_001_budget_breakdown_id_seq'::regclass);


--
-- Name: attr_dept_schools_001_department_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_department_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_schools_001_department_information_id_seq'::regclass);


--
-- Name: attr_dept_schools_001_project_portfolio id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_project_portfolio ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_schools_001_project_portfolio_id_seq'::regclass);


--
-- Name: attr_dept_schools_001_staff_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_staff_information ALTER COLUMN id SET DEFAULT nextval('public.attr_dept_schools_001_staff_information_id_seq'::regclass);


--
-- Name: attr_minister_education_001_budget_allocation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_education_001_budget_allocation ALTER COLUMN id SET DEFAULT nextval('public.attr_minister_education_001_budget_allocation_id_seq'::regclass);


--
-- Name: attr_minister_education_001_performance_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_education_001_performance_metrics ALTER COLUMN id SET DEFAULT nextval('public.attr_minister_education_001_performance_metrics_id_seq'::regclass);


--
-- Name: attr_minister_education_001_personal_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_education_001_personal_information ALTER COLUMN id SET DEFAULT nextval('public.attr_minister_education_001_personal_information_id_seq'::regclass);


--
-- Name: attr_minister_health_001_budget_allocation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_health_001_budget_allocation ALTER COLUMN id SET DEFAULT nextval('public.attr_minister_health_001_budget_allocation_id_seq'::regclass);


--
-- Name: attr_minister_health_001_performance_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_health_001_performance_metrics ALTER COLUMN id SET DEFAULT nextval('public.attr_minister_health_001_performance_metrics_id_seq'::regclass);


--
-- Name: attr_minister_health_001_personal_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_health_001_personal_information ALTER COLUMN id SET DEFAULT nextval('public.attr_minister_health_001_personal_information_id_seq'::regclass);


--
-- Name: attr_minister_tech_001_budget_allocation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_tech_001_budget_allocation ALTER COLUMN id SET DEFAULT nextval('public.attr_minister_tech_001_budget_allocation_id_seq'::regclass);


--
-- Name: attr_minister_tech_001_performance_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_tech_001_performance_metrics ALTER COLUMN id SET DEFAULT nextval('public.attr_minister_tech_001_performance_metrics_id_seq'::regclass);


--
-- Name: attr_minister_tech_001_personal_information id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_tech_001_personal_information ALTER COLUMN id SET DEFAULT nextval('public.attr_minister_tech_001_personal_information_id_seq'::regclass);


--
-- Name: attribute_schemas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attribute_schemas ALTER COLUMN id SET DEFAULT nextval('public.attribute_schemas_id_seq'::regclass);


--
-- Name: entity_attributes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_attributes ALTER COLUMN id SET DEFAULT nextval('public.entity_attributes_id_seq'::regclass);


--
-- Data for Name: attr_dept_higher_ed_001_budget_breakdown; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_higher_ed_001_budget_breakdown (id, entity_attribute_id, category, allocated, spent, remaining, percentage, created_at) FROM stdin;
1	32	Personnel Costs	40000000	38000000	2000000	40%	2025-09-15 08:43:23.964948
2	32	Operational Expenses	20000000	15000000	5000000	20%	2025-09-15 08:43:23.964948
3	32	Capital Expenditure	30000000	20000000	10000000	30%	2025-09-15 08:43:23.964948
4	32	Programs and Projects	10000000	5000000	5000000	10%	2025-09-15 08:43:23.964948
\.


--
-- Data for Name: attr_dept_higher_ed_001_department_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_higher_ed_001_department_information (id, entity_attribute_id, field, value, last_updated, created_at) FROM stdin;
1	33	department_name	Department of Higher Education and Research	2024-01-15 00:00:00+00	2025-09-15 08:43:24.10287
2	33	short_name	Higher Education	2024-01-15 00:00:00+00	2025-09-15 08:43:24.10287
3	33	focus_area	Universities and Research	2024-01-15 00:00:00+00	2025-09-15 08:43:24.10287
4	33	establishment_date	2024-01-15T00:00:00Z	2024-01-15 00:00:00+00	2025-09-15 08:43:24.10287
5	33	headquarters	Colombo, Sri Lanka	2024-01-15 00:00:00+00	2025-09-15 08:43:24.10287
6	33	contact_phone	+94-11-123-4567	2024-01-15 00:00:00+00	2025-09-15 08:43:24.10287
7	33	website	www.dept-higher-ed-001.gov.lk	2024-01-15 00:00:00+00	2025-09-15 08:43:24.10287
\.


--
-- Data for Name: attr_dept_higher_ed_001_project_portfolio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_higher_ed_001_project_portfolio (id, entity_attribute_id, start_date, end_date, progress, project_name, status, budget, created_at) FROM stdin;
1	31	2024-01-01	2024-12-31	65%	Digital Transformation Initiative	In Progress	25000000	2025-09-15 08:43:23.826847
2	31	2024-06-01	2025-05-31	10%	Infrastructure Modernization	Planning	15000000	2025-09-15 08:43:23.826847
3	31	2024-01-01	2024-03-31	100%	Staff Training Program	Completed	5000000	2025-09-15 08:43:23.826847
4	31	2024-02-01	2024-08-31	40%	Policy Framework Update	In Progress	3000000	2025-09-15 08:43:23.826847
5	31	2024-07-01	2024-12-31	5%	Public Outreach Campaign	Planning	8000000	2025-09-15 08:43:23.826847
\.


--
-- Data for Name: attr_dept_higher_ed_001_staff_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_higher_ed_001_staff_information (id, entity_attribute_id, salary_grade, department, "position", count, vacant, created_at) FROM stdin;
1	30	SL-1	Higher Education	Director General	1	0	2025-09-15 08:43:23.724536
2	30	SL-2	Higher Education	Deputy Director	2	0	2025-09-15 08:43:23.724536
3	30	SL-3	Higher Education	Assistant Director	5	1	2025-09-15 08:43:23.724536
4	30	SL-4	Higher Education	Senior Officer	15	2	2025-09-15 08:43:23.724536
5	30	SL-5	Higher Education	Officer	25	3	2025-09-15 08:43:23.724536
6	30	SL-6	Higher Education	Support Staff	30	5	2025-09-15 08:43:23.724536
7	30	SL-4	Higher Education	Technical Staff	20	2	2025-09-15 08:43:23.724536
\.


--
-- Data for Name: attr_dept_hospitals_001_budget_breakdown; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_hospitals_001_budget_breakdown (id, entity_attribute_id, allocated, spent, remaining, percentage, category, created_at) FROM stdin;
1	21	40000000	38000000	2000000	40%	Personnel Costs	2025-09-15 08:43:22.217471
2	21	20000000	15000000	5000000	20%	Operational Expenses	2025-09-15 08:43:22.217471
3	21	30000000	20000000	10000000	30%	Capital Expenditure	2025-09-15 08:43:22.217471
4	21	10000000	5000000	5000000	10%	Programs and Projects	2025-09-15 08:43:22.217471
\.


--
-- Data for Name: attr_dept_hospitals_001_department_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_hospitals_001_department_information (id, entity_attribute_id, field, value, last_updated, created_at) FROM stdin;
1	18	department_name	Department of Hospital Services	2024-01-15 00:00:00+00	2025-09-15 08:43:21.800637
2	18	short_name	Hospital Services	2024-01-15 00:00:00+00	2025-09-15 08:43:21.800637
3	18	focus_area	Healthcare Delivery	2024-01-15 00:00:00+00	2025-09-15 08:43:21.800637
4	18	establishment_date	2024-01-15T00:00:00Z	2024-01-15 00:00:00+00	2025-09-15 08:43:21.800637
5	18	headquarters	Colombo, Sri Lanka	2024-01-15 00:00:00+00	2025-09-15 08:43:21.800637
6	18	contact_phone	+94-11-123-4567	2024-01-15 00:00:00+00	2025-09-15 08:43:21.800637
7	18	website	www.dept-hospitals-001.gov.lk	2024-01-15 00:00:00+00	2025-09-15 08:43:21.800637
\.


--
-- Data for Name: attr_dept_hospitals_001_project_portfolio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_hospitals_001_project_portfolio (id, entity_attribute_id, progress, project_name, status, budget, start_date, end_date, created_at) FROM stdin;
1	20	65%	Digital Transformation Initiative	In Progress	25000000	2024-01-01	2024-12-31	2025-09-15 08:43:22.07374
2	20	10%	Infrastructure Modernization	Planning	15000000	2024-06-01	2025-05-31	2025-09-15 08:43:22.07374
3	20	100%	Staff Training Program	Completed	5000000	2024-01-01	2024-03-31	2025-09-15 08:43:22.07374
4	20	40%	Policy Framework Update	In Progress	3000000	2024-02-01	2024-08-31	2025-09-15 08:43:22.07374
5	20	5%	Public Outreach Campaign	Planning	8000000	2024-07-01	2024-12-31	2025-09-15 08:43:22.07374
\.


--
-- Data for Name: attr_dept_hospitals_001_staff_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_hospitals_001_staff_information (id, entity_attribute_id, vacant, salary_grade, department, "position", count, created_at) FROM stdin;
1	19	0	SL-1	Hospital Services	Director General	1	2025-09-15 08:43:21.948979
2	19	0	SL-2	Hospital Services	Deputy Director	2	2025-09-15 08:43:21.948979
3	19	1	SL-3	Hospital Services	Assistant Director	5	2025-09-15 08:43:21.948979
4	19	2	SL-4	Hospital Services	Senior Officer	15	2025-09-15 08:43:21.948979
5	19	3	SL-5	Hospital Services	Officer	25	2025-09-15 08:43:21.948979
6	19	5	SL-6	Hospital Services	Support Staff	30	2025-09-15 08:43:21.948979
7	19	2	SL-4	Hospital Services	Technical Staff	20	2025-09-15 08:43:21.948979
\.


--
-- Data for Name: attr_dept_ict_001_budget_breakdown; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_ict_001_budget_breakdown (id, entity_attribute_id, allocated, spent, remaining, percentage, category, created_at) FROM stdin;
1	11	40000000	38000000	2000000	40%	Personnel Costs	2025-09-15 08:43:20.468533
2	11	20000000	15000000	5000000	20%	Operational Expenses	2025-09-15 08:43:20.468533
3	11	30000000	20000000	10000000	30%	Capital Expenditure	2025-09-15 08:43:20.468533
4	11	10000000	5000000	5000000	10%	Programs and Projects	2025-09-15 08:43:20.468533
\.


--
-- Data for Name: attr_dept_ict_001_department_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_ict_001_department_information (id, entity_attribute_id, field, value, last_updated, created_at) FROM stdin;
1	12	department_name	Department of Information and Communication Technology	2024-01-15 00:00:00+00	2025-09-15 08:43:20.620313
2	12	short_name	ICT Department	2024-01-15 00:00:00+00	2025-09-15 08:43:20.620313
3	12	focus_area	Digital Infrastructure	2024-01-15 00:00:00+00	2025-09-15 08:43:20.620313
4	12	establishment_date	2024-01-15T00:00:00Z	2024-01-15 00:00:00+00	2025-09-15 08:43:20.620313
5	12	headquarters	Colombo, Sri Lanka	2024-01-15 00:00:00+00	2025-09-15 08:43:20.620313
6	12	contact_phone	+94-11-123-4567	2024-01-15 00:00:00+00	2025-09-15 08:43:20.620313
7	12	website	www.dept-ict-001.gov.lk	2024-01-15 00:00:00+00	2025-09-15 08:43:20.620313
\.


--
-- Data for Name: attr_dept_ict_001_project_portfolio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_ict_001_project_portfolio (id, entity_attribute_id, project_name, status, budget, start_date, end_date, progress, created_at) FROM stdin;
1	10	Digital Transformation Initiative	In Progress	25000000	2024-01-01	2024-12-31	65%	2025-09-15 08:43:20.319748
2	10	Infrastructure Modernization	Planning	15000000	2024-06-01	2025-05-31	10%	2025-09-15 08:43:20.319748
3	10	Staff Training Program	Completed	5000000	2024-01-01	2024-03-31	100%	2025-09-15 08:43:20.319748
4	10	Policy Framework Update	In Progress	3000000	2024-02-01	2024-08-31	40%	2025-09-15 08:43:20.319748
5	10	Public Outreach Campaign	Planning	8000000	2024-07-01	2024-12-31	5%	2025-09-15 08:43:20.319748
\.


--
-- Data for Name: attr_dept_ict_001_staff_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_ict_001_staff_information (id, entity_attribute_id, "position", count, vacant, salary_grade, department, created_at) FROM stdin;
1	13	Director General	1	0	SL-1	ICT Department	2025-09-15 08:43:20.772077
2	13	Deputy Director	2	0	SL-2	ICT Department	2025-09-15 08:43:20.772077
3	13	Assistant Director	5	1	SL-3	ICT Department	2025-09-15 08:43:20.772077
4	13	Senior Officer	15	2	SL-4	ICT Department	2025-09-15 08:43:20.772077
5	13	Officer	25	3	SL-5	ICT Department	2025-09-15 08:43:20.772077
6	13	Support Staff	30	5	SL-6	ICT Department	2025-09-15 08:43:20.772077
7	13	Technical Staff	20	2	SL-4	ICT Department	2025-09-15 08:43:20.772077
\.


--
-- Data for Name: attr_dept_innovation_001_budget_breakdown; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_innovation_001_budget_breakdown (id, entity_attribute_id, allocated, spent, remaining, percentage, category, created_at) FROM stdin;
1	17	40000000	38000000	2000000	40%	Personnel Costs	2025-09-15 08:43:21.584101
2	17	20000000	15000000	5000000	20%	Operational Expenses	2025-09-15 08:43:21.584101
3	17	30000000	20000000	10000000	30%	Capital Expenditure	2025-09-15 08:43:21.584101
4	17	10000000	5000000	5000000	10%	Programs and Projects	2025-09-15 08:43:21.584101
\.


--
-- Data for Name: attr_dept_innovation_001_department_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_innovation_001_department_information (id, entity_attribute_id, field, value, last_updated, created_at) FROM stdin;
1	14	department_name	Department of Digital Innovation and Research	2024-01-15 00:00:00+00	2025-09-15 08:43:21.124225
2	14	short_name	Innovation Department	2024-01-15 00:00:00+00	2025-09-15 08:43:21.124225
3	14	focus_area	R&D and Innovation	2024-01-15 00:00:00+00	2025-09-15 08:43:21.124225
4	14	establishment_date	2024-01-15T00:00:00Z	2024-01-15 00:00:00+00	2025-09-15 08:43:21.124225
5	14	headquarters	Colombo, Sri Lanka	2024-01-15 00:00:00+00	2025-09-15 08:43:21.124225
6	14	contact_phone	+94-11-123-4567	2024-01-15 00:00:00+00	2025-09-15 08:43:21.124225
7	14	website	www.dept-innovation-001.gov.lk	2024-01-15 00:00:00+00	2025-09-15 08:43:21.124225
\.


--
-- Data for Name: attr_dept_innovation_001_project_portfolio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_innovation_001_project_portfolio (id, entity_attribute_id, end_date, progress, project_name, status, budget, start_date, created_at) FROM stdin;
1	16	2024-12-31	65%	Digital Transformation Initiative	In Progress	25000000	2024-01-01	2025-09-15 08:43:21.436801
2	16	2025-05-31	10%	Infrastructure Modernization	Planning	15000000	2024-06-01	2025-09-15 08:43:21.436801
3	16	2024-03-31	100%	Staff Training Program	Completed	5000000	2024-01-01	2025-09-15 08:43:21.436801
4	16	2024-08-31	40%	Policy Framework Update	In Progress	3000000	2024-02-01	2025-09-15 08:43:21.436801
5	16	2024-12-31	5%	Public Outreach Campaign	Planning	8000000	2024-07-01	2025-09-15 08:43:21.436801
\.


--
-- Data for Name: attr_dept_innovation_001_staff_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_innovation_001_staff_information (id, entity_attribute_id, "position", count, vacant, salary_grade, department, created_at) FROM stdin;
1	15	Director General	1	0	SL-1	Innovation Department	2025-09-15 08:43:21.268808
2	15	Deputy Director	2	0	SL-2	Innovation Department	2025-09-15 08:43:21.268808
3	15	Assistant Director	5	1	SL-3	Innovation Department	2025-09-15 08:43:21.268808
4	15	Senior Officer	15	2	SL-4	Innovation Department	2025-09-15 08:43:21.268808
5	15	Officer	25	3	SL-5	Innovation Department	2025-09-15 08:43:21.268808
6	15	Support Staff	30	5	SL-6	Innovation Department	2025-09-15 08:43:21.268808
7	15	Technical Staff	20	2	SL-4	Innovation Department	2025-09-15 08:43:21.268808
\.


--
-- Data for Name: attr_dept_public_health_001_budget_breakdown; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_public_health_001_budget_breakdown (id, entity_attribute_id, remaining, percentage, category, allocated, spent, created_at) FROM stdin;
1	23	2000000	40%	Personnel Costs	40000000	38000000	2025-09-15 08:43:22.616679
2	23	5000000	20%	Operational Expenses	20000000	15000000	2025-09-15 08:43:22.616679
3	23	10000000	30%	Capital Expenditure	30000000	20000000	2025-09-15 08:43:22.616679
4	23	5000000	10%	Programs and Projects	10000000	5000000	2025-09-15 08:43:22.616679
\.


--
-- Data for Name: attr_dept_public_health_001_department_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_public_health_001_department_information (id, entity_attribute_id, field, value, last_updated, created_at) FROM stdin;
1	24	department_name	Department of Public Health and Prevention	2024-01-15 00:00:00+00	2025-09-15 08:43:22.7632
2	24	short_name	Public Health	2024-01-15 00:00:00+00	2025-09-15 08:43:22.7632
3	24	focus_area	Preventive Healthcare	2024-01-15 00:00:00+00	2025-09-15 08:43:22.7632
4	24	establishment_date	2024-01-15T00:00:00Z	2024-01-15 00:00:00+00	2025-09-15 08:43:22.7632
5	24	headquarters	Colombo, Sri Lanka	2024-01-15 00:00:00+00	2025-09-15 08:43:22.7632
6	24	contact_phone	+94-11-123-4567	2024-01-15 00:00:00+00	2025-09-15 08:43:22.7632
7	24	website	www.dept-public-health-001.gov.lk	2024-01-15 00:00:00+00	2025-09-15 08:43:22.7632
\.


--
-- Data for Name: attr_dept_public_health_001_project_portfolio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_public_health_001_project_portfolio (id, entity_attribute_id, budget, start_date, end_date, progress, project_name, status, created_at) FROM stdin;
1	22	25000000	2024-01-01	2024-12-31	65%	Digital Transformation Initiative	In Progress	2025-09-15 08:43:22.476115
2	22	15000000	2024-06-01	2025-05-31	10%	Infrastructure Modernization	Planning	2025-09-15 08:43:22.476115
3	22	5000000	2024-01-01	2024-03-31	100%	Staff Training Program	Completed	2025-09-15 08:43:22.476115
4	22	3000000	2024-02-01	2024-08-31	40%	Policy Framework Update	In Progress	2025-09-15 08:43:22.476115
5	22	8000000	2024-07-01	2024-12-31	5%	Public Outreach Campaign	Planning	2025-09-15 08:43:22.476115
\.


--
-- Data for Name: attr_dept_public_health_001_staff_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_public_health_001_staff_information (id, entity_attribute_id, department, "position", count, vacant, salary_grade, created_at) FROM stdin;
1	25	Public Health	Director General	1	0	SL-1	2025-09-15 08:43:22.896257
2	25	Public Health	Deputy Director	2	0	SL-2	2025-09-15 08:43:22.896257
3	25	Public Health	Assistant Director	5	1	SL-3	2025-09-15 08:43:22.896257
4	25	Public Health	Senior Officer	15	2	SL-4	2025-09-15 08:43:22.896257
5	25	Public Health	Officer	25	3	SL-5	2025-09-15 08:43:22.896257
6	25	Public Health	Support Staff	30	5	SL-6	2025-09-15 08:43:22.896257
7	25	Public Health	Technical Staff	20	2	SL-4	2025-09-15 08:43:22.896257
\.


--
-- Data for Name: attr_dept_schools_001_budget_breakdown; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_schools_001_budget_breakdown (id, entity_attribute_id, category, allocated, spent, remaining, percentage, created_at) FROM stdin;
1	29	Personnel Costs	40000000	38000000	2000000	40%	2025-09-15 08:43:23.51497
2	29	Operational Expenses	20000000	15000000	5000000	20%	2025-09-15 08:43:23.51497
3	29	Capital Expenditure	30000000	20000000	10000000	30%	2025-09-15 08:43:23.51497
4	29	Programs and Projects	10000000	5000000	5000000	10%	2025-09-15 08:43:23.51497
\.


--
-- Data for Name: attr_dept_schools_001_department_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_schools_001_department_information (id, entity_attribute_id, field, value, last_updated, created_at) FROM stdin;
1	26	department_name	Department of School Education	2024-01-15 00:00:00+00	2025-09-15 08:43:23.100898
2	26	short_name	School Education	2024-01-15 00:00:00+00	2025-09-15 08:43:23.100898
3	26	focus_area	Primary and Secondary Education	2024-01-15 00:00:00+00	2025-09-15 08:43:23.100898
4	26	establishment_date	2024-01-15T00:00:00Z	2024-01-15 00:00:00+00	2025-09-15 08:43:23.100898
5	26	headquarters	Colombo, Sri Lanka	2024-01-15 00:00:00+00	2025-09-15 08:43:23.100898
6	26	contact_phone	+94-11-123-4567	2024-01-15 00:00:00+00	2025-09-15 08:43:23.100898
7	26	website	www.dept-schools-001.gov.lk	2024-01-15 00:00:00+00	2025-09-15 08:43:23.100898
\.


--
-- Data for Name: attr_dept_schools_001_project_portfolio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_schools_001_project_portfolio (id, entity_attribute_id, budget, start_date, end_date, progress, project_name, status, created_at) FROM stdin;
1	28	25000000	2024-01-01	2024-12-31	65%	Digital Transformation Initiative	In Progress	2025-09-15 08:43:23.382009
2	28	15000000	2024-06-01	2025-05-31	10%	Infrastructure Modernization	Planning	2025-09-15 08:43:23.382009
3	28	5000000	2024-01-01	2024-03-31	100%	Staff Training Program	Completed	2025-09-15 08:43:23.382009
4	28	3000000	2024-02-01	2024-08-31	40%	Policy Framework Update	In Progress	2025-09-15 08:43:23.382009
5	28	8000000	2024-07-01	2024-12-31	5%	Public Outreach Campaign	Planning	2025-09-15 08:43:23.382009
\.


--
-- Data for Name: attr_dept_schools_001_staff_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_dept_schools_001_staff_information (id, entity_attribute_id, salary_grade, department, "position", count, vacant, created_at) FROM stdin;
1	27	SL-1	School Education	Director General	1	0	2025-09-15 08:43:23.236621
2	27	SL-2	School Education	Deputy Director	2	0	2025-09-15 08:43:23.236621
3	27	SL-3	School Education	Assistant Director	5	1	2025-09-15 08:43:23.236621
4	27	SL-4	School Education	Senior Officer	15	2	2025-09-15 08:43:23.236621
5	27	SL-5	School Education	Officer	25	3	2025-09-15 08:43:23.236621
6	27	SL-6	School Education	Support Staff	30	5	2025-09-15 08:43:23.236621
7	27	SL-4	School Education	Technical Staff	20	2	2025-09-15 08:43:23.236621
\.


--
-- Data for Name: attr_minister_education_001_budget_allocation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_minister_education_001_budget_allocation (id, entity_attribute_id, allocated_amount, spent_amount, remaining, fiscal_year, category, created_at) FROM stdin;
1	9	50000000	45000000	5000000	2024	operational_expenses	2025-09-15 08:43:20.093644
2	9	200000000	120000000	80000000	2024	capital_investments	2025-09-15 08:43:20.093644
3	9	30000000	30000000	0	2024	staff_salaries	2025-09-15 08:43:20.093644
4	9	50000000	35000000	15000000	2024	research_grants	2025-09-15 08:43:20.093644
5	9	20000000	5000000	15000000	2024	emergency_fund	2025-09-15 08:43:20.093644
\.


--
-- Data for Name: attr_minister_education_001_performance_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_minister_education_001_performance_metrics (id, entity_attribute_id, metric, target, actual, period, status, created_at) FROM stdin;
1	8	budget_utilization	95%	92%	Q1-2024	On Track	2025-09-15 08:43:19.959779
2	8	policy_implementations	5	3	Q1-2024	In Progress	2025-09-15 08:43:19.959779
3	8	public_approval_rating	80%	78%	Q1-2024	Good	2025-09-15 08:43:19.959779
4	8	department_efficiency	90%	88%	Q1-2024	Good	2025-09-15 08:43:19.959779
5	8	stakeholder_satisfaction	85%	82%	Q1-2024	Good	2025-09-15 08:43:19.959779
\.


--
-- Data for Name: attr_minister_education_001_personal_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_minister_education_001_personal_information (id, entity_attribute_id, value, last_updated, field, created_at) FROM stdin;
1	7	Minister of Education and Human Development	2024-01-15 00:00:00+00	full_name	2025-09-15 08:43:19.814639
2	7	Education Minister	2024-01-15 00:00:00+00	short_name	2025-09-15 08:43:19.814639
3	7	Education	2024-01-15 00:00:00+00	portfolio	2025-09-15 08:43:19.814639
4	7	2024-01-15T00:00:00Z	2024-01-15 00:00:00+00	appointment_date	2025-09-15 08:43:19.814639
5	7	Parliament Complex, Colombo	2024-01-15 00:00:00+00	office_location	2025-09-15 08:43:19.814639
6	7	minister-education-001@gov.lk	2024-01-15 00:00:00+00	contact_email	2025-09-15 08:43:19.814639
7	7	Top Secret	2024-01-15 00:00:00+00	security_clearance	2025-09-15 08:43:19.814639
\.


--
-- Data for Name: attr_minister_health_001_budget_allocation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_minister_health_001_budget_allocation (id, entity_attribute_id, category, allocated_amount, spent_amount, remaining, fiscal_year, created_at) FROM stdin;
1	6	operational_expenses	50000000	45000000	5000000	2024	2025-09-15 08:43:19.661337
2	6	capital_investments	200000000	120000000	80000000	2024	2025-09-15 08:43:19.661337
3	6	staff_salaries	30000000	30000000	0	2024	2025-09-15 08:43:19.661337
4	6	research_grants	50000000	35000000	15000000	2024	2025-09-15 08:43:19.661337
5	6	emergency_fund	20000000	5000000	15000000	2024	2025-09-15 08:43:19.661337
\.


--
-- Data for Name: attr_minister_health_001_performance_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_minister_health_001_performance_metrics (id, entity_attribute_id, actual, period, status, metric, target, created_at) FROM stdin;
1	5	92%	Q1-2024	On Track	budget_utilization	95%	2025-09-15 08:43:19.560909
2	5	3	Q1-2024	In Progress	policy_implementations	5	2025-09-15 08:43:19.560909
3	5	78%	Q1-2024	Good	public_approval_rating	80%	2025-09-15 08:43:19.560909
4	5	88%	Q1-2024	Good	department_efficiency	90%	2025-09-15 08:43:19.560909
5	5	82%	Q1-2024	Good	stakeholder_satisfaction	85%	2025-09-15 08:43:19.560909
\.


--
-- Data for Name: attr_minister_health_001_personal_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_minister_health_001_personal_information (id, entity_attribute_id, last_updated, field, value, created_at) FROM stdin;
1	4	2024-01-15 00:00:00+00	full_name	Minister of Health and Social Services	2025-09-15 08:43:19.405869
2	4	2024-01-15 00:00:00+00	short_name	Health Minister	2025-09-15 08:43:19.405869
3	4	2024-01-15 00:00:00+00	portfolio	Health	2025-09-15 08:43:19.405869
4	4	2024-01-15 00:00:00+00	appointment_date	2024-01-15T00:00:00Z	2025-09-15 08:43:19.405869
5	4	2024-01-15 00:00:00+00	office_location	Parliament Complex, Colombo	2025-09-15 08:43:19.405869
6	4	2024-01-15 00:00:00+00	contact_email	minister-health-001@gov.lk	2025-09-15 08:43:19.405869
7	4	2024-01-15 00:00:00+00	security_clearance	Top Secret	2025-09-15 08:43:19.405869
\.


--
-- Data for Name: attr_minister_tech_001_budget_allocation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_minister_tech_001_budget_allocation (id, entity_attribute_id, remaining, fiscal_year, category, allocated_amount, spent_amount, created_at) FROM stdin;
1	3	5000000	2024	operational_expenses	50000000	45000000	2025-09-15 08:43:19.221547
2	3	80000000	2024	capital_investments	200000000	120000000	2025-09-15 08:43:19.221547
3	3	0	2024	staff_salaries	30000000	30000000	2025-09-15 08:43:19.221547
4	3	15000000	2024	research_grants	50000000	35000000	2025-09-15 08:43:19.221547
5	3	15000000	2024	emergency_fund	20000000	5000000	2025-09-15 08:43:19.221547
\.


--
-- Data for Name: attr_minister_tech_001_performance_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_minister_tech_001_performance_metrics (id, entity_attribute_id, status, metric, target, actual, period, created_at) FROM stdin;
1	2	On Track	budget_utilization	95%	92%	Q1-2024	2025-09-15 08:43:19.072954
2	2	In Progress	policy_implementations	5	3	Q1-2024	2025-09-15 08:43:19.072954
3	2	Good	public_approval_rating	80%	78%	Q1-2024	2025-09-15 08:43:19.072954
4	2	Good	department_efficiency	90%	88%	Q1-2024	2025-09-15 08:43:19.072954
5	2	Good	stakeholder_satisfaction	85%	82%	Q1-2024	2025-09-15 08:43:19.072954
\.


--
-- Data for Name: attr_minister_tech_001_personal_information; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_minister_tech_001_personal_information (id, entity_attribute_id, field, value, last_updated, created_at) FROM stdin;
1	1	full_name	Minister of Technology and Digital Innovation	2024-01-15 00:00:00+00	2025-09-15 08:43:18.95531
2	1	short_name	Tech Minister	2024-01-15 00:00:00+00	2025-09-15 08:43:18.95531
3	1	portfolio	Technology	2024-01-15 00:00:00+00	2025-09-15 08:43:18.95531
4	1	appointment_date	2024-01-15T00:00:00Z	2024-01-15 00:00:00+00	2025-09-15 08:43:18.95531
5	1	office_location	Parliament Complex, Colombo	2024-01-15 00:00:00+00	2025-09-15 08:43:18.95531
6	1	contact_email	minister-tech-001@gov.lk	2024-01-15 00:00:00+00	2025-09-15 08:43:18.95531
7	1	security_clearance	Top Secret	2024-01-15 00:00:00+00	2025-09-15 08:43:18.95531
\.


--
-- Data for Name: attribute_schemas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attribute_schemas (id, table_name, schema_version, schema_definition, created_at) FROM stdin;
1	attr_minister_tech_001_personal_information	1	{"Items": null, "Fields": {"field": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "value": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "last_updated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:18.949523
2	attr_minister_tech_001_performance_metrics	1	{"Items": null, "Fields": {"actual": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "metric": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "period": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "target": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:19.068171
3	attr_minister_tech_001_budget_allocation	1	{"Items": null, "Fields": {"category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "remaining": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "fiscal_year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "spent_amount": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "allocated_amount": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:19.21398
4	attr_minister_health_001_personal_information	1	{"Items": null, "Fields": {"field": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "value": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "last_updated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:19.399515
5	attr_minister_health_001_performance_metrics	1	{"Items": null, "Fields": {"actual": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "metric": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "period": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "target": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:19.553615
6	attr_minister_health_001_budget_allocation	1	{"Items": null, "Fields": {"category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "remaining": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "fiscal_year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "spent_amount": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "allocated_amount": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:19.65659
7	attr_minister_education_001_personal_information	1	{"Items": null, "Fields": {"field": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "value": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "last_updated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:19.80999
8	attr_minister_education_001_performance_metrics	1	{"Items": null, "Fields": {"actual": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "metric": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "period": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "target": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:19.95388
9	attr_minister_education_001_budget_allocation	1	{"Items": null, "Fields": {"category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "remaining": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "fiscal_year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "spent_amount": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "allocated_amount": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:20.086173
10	attr_dept_ict_001_project_portfolio	1	{"Items": null, "Fields": {"budget": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "end_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "progress": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "start_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "project_name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:20.313109
11	attr_dept_ict_001_budget_breakdown	1	{"Items": null, "Fields": {"spent": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "allocated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "remaining": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "percentage": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:20.463581
12	attr_dept_ict_001_department_information	1	{"Items": null, "Fields": {"field": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "value": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "last_updated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:20.614375
13	attr_dept_ict_001_staff_information	1	{"Items": null, "Fields": {"count": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "vacant": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "position": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "department": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary_grade": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:20.764562
14	attr_dept_innovation_001_department_information	1	{"Items": null, "Fields": {"field": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "value": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "last_updated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:21.117642
15	attr_dept_innovation_001_staff_information	1	{"Items": null, "Fields": {"count": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "vacant": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "position": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "department": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary_grade": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:21.26365
16	attr_dept_innovation_001_project_portfolio	1	{"Items": null, "Fields": {"budget": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "end_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "progress": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "start_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "project_name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:21.428479
17	attr_dept_innovation_001_budget_breakdown	1	{"Items": null, "Fields": {"spent": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "allocated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "remaining": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "percentage": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:21.577047
18	attr_dept_hospitals_001_department_information	1	{"Items": null, "Fields": {"field": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "value": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "last_updated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:21.794246
19	attr_dept_hospitals_001_staff_information	1	{"Items": null, "Fields": {"count": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "vacant": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "position": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "department": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary_grade": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:21.942896
26	attr_dept_schools_001_department_information	1	{"Items": null, "Fields": {"field": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "value": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "last_updated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:23.094667
20	attr_dept_hospitals_001_project_portfolio	1	{"Items": null, "Fields": {"budget": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "end_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "progress": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "start_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "project_name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:22.067634
21	attr_dept_hospitals_001_budget_breakdown	1	{"Items": null, "Fields": {"spent": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "allocated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "remaining": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "percentage": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:22.210046
22	attr_dept_public_health_001_project_portfolio	1	{"Items": null, "Fields": {"budget": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "end_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "progress": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "start_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "project_name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:22.470032
23	attr_dept_public_health_001_budget_breakdown	1	{"Items": null, "Fields": {"spent": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "allocated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "remaining": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "percentage": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:22.611443
24	attr_dept_public_health_001_department_information	1	{"Items": null, "Fields": {"field": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "value": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "last_updated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:22.756835
25	attr_dept_public_health_001_staff_information	1	{"Items": null, "Fields": {"count": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "vacant": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "position": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "department": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary_grade": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:22.891075
27	attr_dept_schools_001_staff_information	1	{"Items": null, "Fields": {"count": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "vacant": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "position": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "department": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary_grade": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:23.231313
28	attr_dept_schools_001_project_portfolio	1	{"Items": null, "Fields": {"budget": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "end_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "progress": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "start_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "project_name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:23.377373
29	attr_dept_schools_001_budget_breakdown	1	{"Items": null, "Fields": {"spent": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "allocated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "remaining": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "percentage": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:23.508103
30	attr_dept_higher_ed_001_staff_information	1	{"Items": null, "Fields": {"count": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "vacant": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "position": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "department": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary_grade": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:23.719211
31	attr_dept_higher_ed_001_project_portfolio	1	{"Items": null, "Fields": {"budget": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "end_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "progress": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "start_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "date", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "project_name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:23.820816
32	attr_dept_higher_ed_001_budget_breakdown	1	{"Items": null, "Fields": {"spent": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "allocated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "remaining": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "percentage": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:23.959836
33	attr_dept_higher_ed_001_department_information	1	{"Items": null, "Fields": {"field": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "value": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "last_updated": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-15 08:43:24.095861
\.


--
-- Data for Name: entity_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entity_attributes (id, entity_id, attribute_name, table_name, schema_version, created_at) FROM stdin;
1	minister-tech-001	personal_information	attr_minister_tech_001_personal_information	1	2025-09-15 08:43:18.953742
2	minister-tech-001	performance_metrics	attr_minister_tech_001_performance_metrics	1	2025-09-15 08:43:19.071542
3	minister-tech-001	budget_allocation	attr_minister_tech_001_budget_allocation	1	2025-09-15 08:43:19.218993
4	minister-health-001	personal_information	attr_minister_health_001_personal_information	1	2025-09-15 08:43:19.404075
5	minister-health-001	performance_metrics	attr_minister_health_001_performance_metrics	1	2025-09-15 08:43:19.558228
6	minister-health-001	budget_allocation	attr_minister_health_001_budget_allocation	1	2025-09-15 08:43:19.659796
7	minister-education-001	personal_information	attr_minister_education_001_personal_information	1	2025-09-15 08:43:19.813163
8	minister-education-001	performance_metrics	attr_minister_education_001_performance_metrics	1	2025-09-15 08:43:19.957892
9	minister-education-001	budget_allocation	attr_minister_education_001_budget_allocation	1	2025-09-15 08:43:20.091119
10	dept-ict-001	project_portfolio	attr_dept_ict_001_project_portfolio	1	2025-09-15 08:43:20.31771
11	dept-ict-001	budget_breakdown	attr_dept_ict_001_budget_breakdown	1	2025-09-15 08:43:20.466909
12	dept-ict-001	department_information	attr_dept_ict_001_department_information	1	2025-09-15 08:43:20.618473
13	dept-ict-001	staff_information	attr_dept_ict_001_staff_information	1	2025-09-15 08:43:20.770433
14	dept-innovation-001	department_information	attr_dept_innovation_001_department_information	1	2025-09-15 08:43:21.12206
15	dept-innovation-001	staff_information	attr_dept_innovation_001_staff_information	1	2025-09-15 08:43:21.267206
16	dept-innovation-001	project_portfolio	attr_dept_innovation_001_project_portfolio	1	2025-09-15 08:43:21.433801
17	dept-innovation-001	budget_breakdown	attr_dept_innovation_001_budget_breakdown	1	2025-09-15 08:43:21.582577
18	dept-hospitals-001	department_information	attr_dept_hospitals_001_department_information	1	2025-09-15 08:43:21.798589
19	dept-hospitals-001	staff_information	attr_dept_hospitals_001_staff_information	1	2025-09-15 08:43:21.947105
20	dept-hospitals-001	project_portfolio	attr_dept_hospitals_001_project_portfolio	1	2025-09-15 08:43:22.071513
21	dept-hospitals-001	budget_breakdown	attr_dept_hospitals_001_budget_breakdown	1	2025-09-15 08:43:22.215403
22	dept-public-health-001	project_portfolio	attr_dept_public_health_001_project_portfolio	1	2025-09-15 08:43:22.474435
23	dept-public-health-001	budget_breakdown	attr_dept_public_health_001_budget_breakdown	1	2025-09-15 08:43:22.615134
24	dept-public-health-001	department_information	attr_dept_public_health_001_department_information	1	2025-09-15 08:43:22.760933
25	dept-public-health-001	staff_information	attr_dept_public_health_001_staff_information	1	2025-09-15 08:43:22.894679
26	dept-schools-001	department_information	attr_dept_schools_001_department_information	1	2025-09-15 08:43:23.098871
27	dept-schools-001	staff_information	attr_dept_schools_001_staff_information	1	2025-09-15 08:43:23.235018
28	dept-schools-001	project_portfolio	attr_dept_schools_001_project_portfolio	1	2025-09-15 08:43:23.380533
29	dept-schools-001	budget_breakdown	attr_dept_schools_001_budget_breakdown	1	2025-09-15 08:43:23.512604
30	dept-higher-ed-001	staff_information	attr_dept_higher_ed_001_staff_information	1	2025-09-15 08:43:23.722906
31	dept-higher-ed-001	project_portfolio	attr_dept_higher_ed_001_project_portfolio	1	2025-09-15 08:43:23.824474
32	dept-higher-ed-001	budget_breakdown	attr_dept_higher_ed_001_budget_breakdown	1	2025-09-15 08:43:23.963389
33	dept-higher-ed-001	department_information	attr_dept_higher_ed_001_department_information	1	2025-09-15 08:43:24.100603
\.


--
-- Name: attr_dept_higher_ed_001_budget_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_higher_ed_001_budget_breakdown_id_seq', 4, true);


--
-- Name: attr_dept_higher_ed_001_department_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_higher_ed_001_department_information_id_seq', 7, true);


--
-- Name: attr_dept_higher_ed_001_project_portfolio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_higher_ed_001_project_portfolio_id_seq', 5, true);


--
-- Name: attr_dept_higher_ed_001_staff_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_higher_ed_001_staff_information_id_seq', 7, true);


--
-- Name: attr_dept_hospitals_001_budget_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_hospitals_001_budget_breakdown_id_seq', 4, true);


--
-- Name: attr_dept_hospitals_001_department_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_hospitals_001_department_information_id_seq', 7, true);


--
-- Name: attr_dept_hospitals_001_project_portfolio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_hospitals_001_project_portfolio_id_seq', 5, true);


--
-- Name: attr_dept_hospitals_001_staff_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_hospitals_001_staff_information_id_seq', 7, true);


--
-- Name: attr_dept_ict_001_budget_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_ict_001_budget_breakdown_id_seq', 4, true);


--
-- Name: attr_dept_ict_001_department_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_ict_001_department_information_id_seq', 7, true);


--
-- Name: attr_dept_ict_001_project_portfolio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_ict_001_project_portfolio_id_seq', 5, true);


--
-- Name: attr_dept_ict_001_staff_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_ict_001_staff_information_id_seq', 7, true);


--
-- Name: attr_dept_innovation_001_budget_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_innovation_001_budget_breakdown_id_seq', 4, true);


--
-- Name: attr_dept_innovation_001_department_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_innovation_001_department_information_id_seq', 7, true);


--
-- Name: attr_dept_innovation_001_project_portfolio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_innovation_001_project_portfolio_id_seq', 5, true);


--
-- Name: attr_dept_innovation_001_staff_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_innovation_001_staff_information_id_seq', 7, true);


--
-- Name: attr_dept_public_health_001_budget_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_public_health_001_budget_breakdown_id_seq', 4, true);


--
-- Name: attr_dept_public_health_001_department_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_public_health_001_department_information_id_seq', 7, true);


--
-- Name: attr_dept_public_health_001_project_portfolio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_public_health_001_project_portfolio_id_seq', 5, true);


--
-- Name: attr_dept_public_health_001_staff_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_public_health_001_staff_information_id_seq', 7, true);


--
-- Name: attr_dept_schools_001_budget_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_schools_001_budget_breakdown_id_seq', 4, true);


--
-- Name: attr_dept_schools_001_department_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_schools_001_department_information_id_seq', 7, true);


--
-- Name: attr_dept_schools_001_project_portfolio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_schools_001_project_portfolio_id_seq', 5, true);


--
-- Name: attr_dept_schools_001_staff_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_dept_schools_001_staff_information_id_seq', 7, true);


--
-- Name: attr_minister_education_001_budget_allocation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_minister_education_001_budget_allocation_id_seq', 5, true);


--
-- Name: attr_minister_education_001_performance_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_minister_education_001_performance_metrics_id_seq', 5, true);


--
-- Name: attr_minister_education_001_personal_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_minister_education_001_personal_information_id_seq', 7, true);


--
-- Name: attr_minister_health_001_budget_allocation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_minister_health_001_budget_allocation_id_seq', 5, true);


--
-- Name: attr_minister_health_001_performance_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_minister_health_001_performance_metrics_id_seq', 5, true);


--
-- Name: attr_minister_health_001_personal_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_minister_health_001_personal_information_id_seq', 7, true);


--
-- Name: attr_minister_tech_001_budget_allocation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_minister_tech_001_budget_allocation_id_seq', 5, true);


--
-- Name: attr_minister_tech_001_performance_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_minister_tech_001_performance_metrics_id_seq', 5, true);


--
-- Name: attr_minister_tech_001_personal_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_minister_tech_001_personal_information_id_seq', 7, true);


--
-- Name: attribute_schemas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attribute_schemas_id_seq', 33, true);


--
-- Name: entity_attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.entity_attributes_id_seq', 33, true);


--
-- Name: attr_dept_higher_ed_001_budget_breakdown attr_dept_higher_ed_001_budget_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_budget_breakdown
    ADD CONSTRAINT attr_dept_higher_ed_001_budget_breakdown_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_higher_ed_001_department_information attr_dept_higher_ed_001_department_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_department_information
    ADD CONSTRAINT attr_dept_higher_ed_001_department_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_higher_ed_001_project_portfolio attr_dept_higher_ed_001_project_portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_project_portfolio
    ADD CONSTRAINT attr_dept_higher_ed_001_project_portfolio_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_higher_ed_001_staff_information attr_dept_higher_ed_001_staff_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_staff_information
    ADD CONSTRAINT attr_dept_higher_ed_001_staff_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_hospitals_001_budget_breakdown attr_dept_hospitals_001_budget_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_budget_breakdown
    ADD CONSTRAINT attr_dept_hospitals_001_budget_breakdown_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_hospitals_001_department_information attr_dept_hospitals_001_department_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_department_information
    ADD CONSTRAINT attr_dept_hospitals_001_department_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_hospitals_001_project_portfolio attr_dept_hospitals_001_project_portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_project_portfolio
    ADD CONSTRAINT attr_dept_hospitals_001_project_portfolio_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_hospitals_001_staff_information attr_dept_hospitals_001_staff_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_staff_information
    ADD CONSTRAINT attr_dept_hospitals_001_staff_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_ict_001_budget_breakdown attr_dept_ict_001_budget_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_budget_breakdown
    ADD CONSTRAINT attr_dept_ict_001_budget_breakdown_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_ict_001_department_information attr_dept_ict_001_department_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_department_information
    ADD CONSTRAINT attr_dept_ict_001_department_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_ict_001_project_portfolio attr_dept_ict_001_project_portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_project_portfolio
    ADD CONSTRAINT attr_dept_ict_001_project_portfolio_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_ict_001_staff_information attr_dept_ict_001_staff_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_staff_information
    ADD CONSTRAINT attr_dept_ict_001_staff_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_innovation_001_budget_breakdown attr_dept_innovation_001_budget_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_budget_breakdown
    ADD CONSTRAINT attr_dept_innovation_001_budget_breakdown_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_innovation_001_department_information attr_dept_innovation_001_department_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_department_information
    ADD CONSTRAINT attr_dept_innovation_001_department_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_innovation_001_project_portfolio attr_dept_innovation_001_project_portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_project_portfolio
    ADD CONSTRAINT attr_dept_innovation_001_project_portfolio_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_innovation_001_staff_information attr_dept_innovation_001_staff_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_staff_information
    ADD CONSTRAINT attr_dept_innovation_001_staff_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_public_health_001_budget_breakdown attr_dept_public_health_001_budget_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_budget_breakdown
    ADD CONSTRAINT attr_dept_public_health_001_budget_breakdown_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_public_health_001_department_information attr_dept_public_health_001_department_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_department_information
    ADD CONSTRAINT attr_dept_public_health_001_department_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_public_health_001_project_portfolio attr_dept_public_health_001_project_portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_project_portfolio
    ADD CONSTRAINT attr_dept_public_health_001_project_portfolio_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_public_health_001_staff_information attr_dept_public_health_001_staff_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_staff_information
    ADD CONSTRAINT attr_dept_public_health_001_staff_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_schools_001_budget_breakdown attr_dept_schools_001_budget_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_budget_breakdown
    ADD CONSTRAINT attr_dept_schools_001_budget_breakdown_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_schools_001_department_information attr_dept_schools_001_department_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_department_information
    ADD CONSTRAINT attr_dept_schools_001_department_information_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_schools_001_project_portfolio attr_dept_schools_001_project_portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_project_portfolio
    ADD CONSTRAINT attr_dept_schools_001_project_portfolio_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_schools_001_staff_information attr_dept_schools_001_staff_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_staff_information
    ADD CONSTRAINT attr_dept_schools_001_staff_information_pkey PRIMARY KEY (id);


--
-- Name: attr_minister_education_001_budget_allocation attr_minister_education_001_budget_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_education_001_budget_allocation
    ADD CONSTRAINT attr_minister_education_001_budget_allocation_pkey PRIMARY KEY (id);


--
-- Name: attr_minister_education_001_performance_metrics attr_minister_education_001_performance_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_education_001_performance_metrics
    ADD CONSTRAINT attr_minister_education_001_performance_metrics_pkey PRIMARY KEY (id);


--
-- Name: attr_minister_education_001_personal_information attr_minister_education_001_personal_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_education_001_personal_information
    ADD CONSTRAINT attr_minister_education_001_personal_information_pkey PRIMARY KEY (id);


--
-- Name: attr_minister_health_001_budget_allocation attr_minister_health_001_budget_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_health_001_budget_allocation
    ADD CONSTRAINT attr_minister_health_001_budget_allocation_pkey PRIMARY KEY (id);


--
-- Name: attr_minister_health_001_performance_metrics attr_minister_health_001_performance_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_health_001_performance_metrics
    ADD CONSTRAINT attr_minister_health_001_performance_metrics_pkey PRIMARY KEY (id);


--
-- Name: attr_minister_health_001_personal_information attr_minister_health_001_personal_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_health_001_personal_information
    ADD CONSTRAINT attr_minister_health_001_personal_information_pkey PRIMARY KEY (id);


--
-- Name: attr_minister_tech_001_budget_allocation attr_minister_tech_001_budget_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_tech_001_budget_allocation
    ADD CONSTRAINT attr_minister_tech_001_budget_allocation_pkey PRIMARY KEY (id);


--
-- Name: attr_minister_tech_001_performance_metrics attr_minister_tech_001_performance_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_tech_001_performance_metrics
    ADD CONSTRAINT attr_minister_tech_001_performance_metrics_pkey PRIMARY KEY (id);


--
-- Name: attr_minister_tech_001_personal_information attr_minister_tech_001_personal_information_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_tech_001_personal_information
    ADD CONSTRAINT attr_minister_tech_001_personal_information_pkey PRIMARY KEY (id);


--
-- Name: attribute_schemas attribute_schemas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attribute_schemas
    ADD CONSTRAINT attribute_schemas_pkey PRIMARY KEY (id);


--
-- Name: attribute_schemas attribute_schemas_table_name_schema_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attribute_schemas
    ADD CONSTRAINT attribute_schemas_table_name_schema_version_key UNIQUE (table_name, schema_version);


--
-- Name: entity_attributes entity_attributes_entity_id_attribute_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_attributes
    ADD CONSTRAINT entity_attributes_entity_id_attribute_name_key UNIQUE (entity_id, attribute_name);


--
-- Name: entity_attributes entity_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_attributes
    ADD CONSTRAINT entity_attributes_pkey PRIMARY KEY (id);


--
-- Name: attr_dept_higher_ed_001_budget_breakdown attr_dept_higher_ed_001_budget_breakdo_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_budget_breakdown
    ADD CONSTRAINT attr_dept_higher_ed_001_budget_breakdo_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_higher_ed_001_department_information attr_dept_higher_ed_001_department_inf_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_department_information
    ADD CONSTRAINT attr_dept_higher_ed_001_department_inf_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_higher_ed_001_project_portfolio attr_dept_higher_ed_001_project_portfo_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_project_portfolio
    ADD CONSTRAINT attr_dept_higher_ed_001_project_portfo_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_higher_ed_001_staff_information attr_dept_higher_ed_001_staff_informat_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_higher_ed_001_staff_information
    ADD CONSTRAINT attr_dept_higher_ed_001_staff_informat_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_hospitals_001_budget_breakdown attr_dept_hospitals_001_budget_breakdo_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_budget_breakdown
    ADD CONSTRAINT attr_dept_hospitals_001_budget_breakdo_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_hospitals_001_department_information attr_dept_hospitals_001_department_inf_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_department_information
    ADD CONSTRAINT attr_dept_hospitals_001_department_inf_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_hospitals_001_project_portfolio attr_dept_hospitals_001_project_portfo_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_project_portfolio
    ADD CONSTRAINT attr_dept_hospitals_001_project_portfo_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_hospitals_001_staff_information attr_dept_hospitals_001_staff_informat_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_hospitals_001_staff_information
    ADD CONSTRAINT attr_dept_hospitals_001_staff_informat_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_ict_001_budget_breakdown attr_dept_ict_001_budget_breakdown_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_budget_breakdown
    ADD CONSTRAINT attr_dept_ict_001_budget_breakdown_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_ict_001_department_information attr_dept_ict_001_department_informati_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_department_information
    ADD CONSTRAINT attr_dept_ict_001_department_informati_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_ict_001_project_portfolio attr_dept_ict_001_project_portfolio_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_project_portfolio
    ADD CONSTRAINT attr_dept_ict_001_project_portfolio_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_ict_001_staff_information attr_dept_ict_001_staff_information_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_ict_001_staff_information
    ADD CONSTRAINT attr_dept_ict_001_staff_information_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_innovation_001_budget_breakdown attr_dept_innovation_001_budget_breakd_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_budget_breakdown
    ADD CONSTRAINT attr_dept_innovation_001_budget_breakd_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_innovation_001_department_information attr_dept_innovation_001_department_in_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_department_information
    ADD CONSTRAINT attr_dept_innovation_001_department_in_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_innovation_001_project_portfolio attr_dept_innovation_001_project_portf_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_project_portfolio
    ADD CONSTRAINT attr_dept_innovation_001_project_portf_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_innovation_001_staff_information attr_dept_innovation_001_staff_informa_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_innovation_001_staff_information
    ADD CONSTRAINT attr_dept_innovation_001_staff_informa_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_public_health_001_budget_breakdown attr_dept_public_health_001_budget_bre_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_budget_breakdown
    ADD CONSTRAINT attr_dept_public_health_001_budget_bre_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_public_health_001_department_information attr_dept_public_health_001_department_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_department_information
    ADD CONSTRAINT attr_dept_public_health_001_department_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_public_health_001_project_portfolio attr_dept_public_health_001_project_po_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_project_portfolio
    ADD CONSTRAINT attr_dept_public_health_001_project_po_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_public_health_001_staff_information attr_dept_public_health_001_staff_info_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_public_health_001_staff_information
    ADD CONSTRAINT attr_dept_public_health_001_staff_info_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_schools_001_budget_breakdown attr_dept_schools_001_budget_breakdown_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_budget_breakdown
    ADD CONSTRAINT attr_dept_schools_001_budget_breakdown_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_schools_001_department_information attr_dept_schools_001_department_infor_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_department_information
    ADD CONSTRAINT attr_dept_schools_001_department_infor_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_schools_001_project_portfolio attr_dept_schools_001_project_portfoli_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_project_portfolio
    ADD CONSTRAINT attr_dept_schools_001_project_portfoli_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_dept_schools_001_staff_information attr_dept_schools_001_staff_informatio_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_dept_schools_001_staff_information
    ADD CONSTRAINT attr_dept_schools_001_staff_informatio_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_minister_education_001_budget_allocation attr_minister_education_001_budget_all_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_education_001_budget_allocation
    ADD CONSTRAINT attr_minister_education_001_budget_all_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_minister_education_001_performance_metrics attr_minister_education_001_performanc_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_education_001_performance_metrics
    ADD CONSTRAINT attr_minister_education_001_performanc_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_minister_education_001_personal_information attr_minister_education_001_personal_i_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_education_001_personal_information
    ADD CONSTRAINT attr_minister_education_001_personal_i_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_minister_health_001_budget_allocation attr_minister_health_001_budget_alloca_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_health_001_budget_allocation
    ADD CONSTRAINT attr_minister_health_001_budget_alloca_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_minister_health_001_performance_metrics attr_minister_health_001_performance_m_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_health_001_performance_metrics
    ADD CONSTRAINT attr_minister_health_001_performance_m_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_minister_health_001_personal_information attr_minister_health_001_personal_info_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_health_001_personal_information
    ADD CONSTRAINT attr_minister_health_001_personal_info_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_minister_tech_001_budget_allocation attr_minister_tech_001_budget_allocati_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_tech_001_budget_allocation
    ADD CONSTRAINT attr_minister_tech_001_budget_allocati_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_minister_tech_001_performance_metrics attr_minister_tech_001_performance_met_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_tech_001_performance_metrics
    ADD CONSTRAINT attr_minister_tech_001_performance_met_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_minister_tech_001_personal_information attr_minister_tech_001_personal_inform_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_minister_tech_001_personal_information
    ADD CONSTRAINT attr_minister_tech_001_personal_inform_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- PostgreSQL database dump complete
--

