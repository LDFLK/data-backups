--
-- PostgreSQL database dump
--

\restrict p2rhXKBlKoNhi5jXouG4sluhgKxCOA3aRnbmlNJ7dz9gZSzySJx6BpePky9uBk6

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165 (
    id integer NOT NULL,
    entity_attribute_id integer,
    year text NOT NULL,
    number_of_raids_conducted integer NOT NULL,
    number_of_successful_raids integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_id_seq OWNED BY public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165.id;


--
-- Name: attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165 (
    id integer NOT NULL,
    entity_attribute_id integer,
    middle_east_as_a___of_total_remittance double precision NOT NULL,
    year text NOT NULL,
    remittances_middle_east__rs__million_ integer NOT NULL,
    remittances_middle_east__us__million_ integer NOT NULL,
    remittances_total__rs__million_ integer NOT NULL,
    remittances_total__us__million_ integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_id_seq OWNED BY public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165.id;


--
-- Name: attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165 (
    id integer NOT NULL,
    entity_attribute_id integer,
    month text NOT NULL,
    number_of_arrivals integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_id_seq OWNED BY public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165.id;


--
-- Name: attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165 (
    id integer NOT NULL,
    entity_attribute_id integer,
    year text NOT NULL,
    complaints_resolved integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_id_seq OWNED BY public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165.id;


--
-- Name: attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165 (
    id integer NOT NULL,
    entity_attribute_id integer,
    ref__no_ integer NOT NULL,
    division_activities text NOT NULL,
    _rs_ integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_id_seq OWNED BY public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165.id;


--
-- Name: attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165 (
    id integer NOT NULL,
    entity_attribute_id integer,
    month text NOT NULL,
    earning__rs__million_ double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_id_seq OWNED BY public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165.id;


--
-- Name: attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165 (
    id integer NOT NULL,
    entity_attribute_id integer,
    year text NOT NULL,
    complaints_received integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_id_seq OWNED BY public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165.id;


--
-- Name: attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165 (
    id integer NOT NULL,
    entity_attribute_id integer,
    month text NOT NULL,
    number_of_persons integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_id_seq OWNED BY public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165.id;


--
-- Name: attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20 (
    id integer NOT NULL,
    entity_attribute_id integer,
    nationality text NOT NULL,
    number_of_foreigners_with_refused_entry integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_id_seq OWNED BY public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20.id;


--
-- Name: attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20 (
    id integer NOT NULL,
    entity_attribute_id integer,
    nationality text NOT NULL,
    no__of_persons integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_id_seq OWNED BY public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20.id;


--
-- Name: attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20 (
    id integer NOT NULL,
    entity_attribute_id integer,
    nationality text NOT NULL,
    no__entered integer NOT NULL,
    no__removed integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_id_seq OWNED BY public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20.id;


--
-- Name: attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20 (
    id integer NOT NULL,
    entity_attribute_id integer,
    nationality text NOT NULL,
    no__of_persons integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_id_seq OWNED BY public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20.id;


--
-- Name: attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440 (
    id integer NOT NULL,
    entity_attribute_id integer,
    country text NOT NULL,
    arrivals integer NOT NULL,
    share text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_id_seq OWNED BY public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440.id;


--
-- Name: attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440 (
    id integer NOT NULL,
    entity_attribute_id integer,
    year text NOT NULL,
    value_in_rupees_mn_ integer NOT NULL,
    value_in_usd_mn_ double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440 OWNER TO postgres;

--
-- Name: attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_id_seq OWNER TO postgres;

--
-- Name: attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_id_seq OWNED BY public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440.id;


--
-- Name: attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2 (
    id integer NOT NULL,
    entity_attribute_id integer,
    category text NOT NULL,
    staff_type text NOT NULL,
    approved_cadre integer NOT NULL,
    existing integer NOT NULL,
    vacancy_excess_count integer NOT NULL,
    vacancy_excess_type text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2 OWNER TO postgres;

--
-- Name: attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_id_seq OWNER TO postgres;

--
-- Name: attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_id_seq OWNED BY public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2.id;


--
-- Name: attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30 (
    id integer NOT NULL,
    entity_attribute_id integer,
    title text NOT NULL,
    date text NOT NULL,
    link text NOT NULL,
    summary text NOT NULL,
    category text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30 OWNER TO postgres;

--
-- Name: attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_id_seq OWNER TO postgres;

--
-- Name: attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_id_seq OWNED BY public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30.id;


--
-- Name: attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb (
    id integer NOT NULL,
    entity_attribute_id integer,
    percentage double precision NOT NULL,
    country text NOT NULL,
    number integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb OWNER TO postgres;

--
-- Name: attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_id_seq OWNER TO postgres;

--
-- Name: attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_id_seq OWNED BY public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb.id;


--
-- Name: attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1 (
    id integer NOT NULL,
    entity_attribute_id integer,
    february integer NOT NULL,
    march integer NOT NULL,
    april integer NOT NULL,
    june integer NOT NULL,
    july integer NOT NULL,
    september integer NOT NULL,
    october integer NOT NULL,
    country text NOT NULL,
    may integer NOT NULL,
    august integer NOT NULL,
    november integer NOT NULL,
    december integer NOT NULL,
    january integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1 OWNER TO postgres;

--
-- Name: attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_id_seq OWNER TO postgres;

--
-- Name: attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_id_seq OWNED BY public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1.id;


--
-- Name: attr_cat_333e54f020_db905fd311_2022_cat_333e54f020; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020 (
    id integer NOT NULL,
    entity_attribute_id integer,
    port text NOT NULL,
    arrivals integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020 OWNER TO postgres;

--
-- Name: attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_id_seq OWNER TO postgres;

--
-- Name: attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_id_seq OWNED BY public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020.id;


--
-- Name: attr_cat_382785f270_f19d1a303a_2022_cat_382785f270; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270 (
    id integer NOT NULL,
    entity_attribute_id integer,
    purpose text NOT NULL,
    percentage double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270 OWNER TO postgres;

--
-- Name: attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_id_seq OWNER TO postgres;

--
-- Name: attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_id_seq OWNED BY public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270.id;


--
-- Name: attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387 (
    id integer NOT NULL,
    entity_attribute_id integer,
    title text NOT NULL,
    date text NOT NULL,
    link text NOT NULL,
    summary text NOT NULL,
    category text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387 OWNER TO postgres;

--
-- Name: attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_id_seq OWNER TO postgres;

--
-- Name: attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_id_seq OWNED BY public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387.id;


--
-- Name: attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f (
    id integer NOT NULL,
    entity_attribute_id integer,
    professional_female integer NOT NULL,
    semi_skilled_domestic_housekeeping_assistant_female integer NOT NULL,
    skilled_female integer NOT NULL,
    middle_level_female integer NOT NULL,
    middle_level_male integer NOT NULL,
    total integer NOT NULL,
    clerical___related_female integer NOT NULL,
    clerical___related_male integer NOT NULL,
    low_skilled_female integer NOT NULL,
    low_skilled_male integer NOT NULL,
    age_group text NOT NULL,
    professional_male integer NOT NULL,
    skilled_male integer NOT NULL,
    semi_skilled_other_female integer NOT NULL,
    semi_skilled_other_male integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f OWNER TO postgres;

--
-- Name: attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_id_seq OWNER TO postgres;

--
-- Name: attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_id_seq OWNED BY public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f.id;


--
-- Name: attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369 (
    id integer NOT NULL,
    entity_attribute_id integer,
    month text NOT NULL,
    number_of_tourist_arrivals integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369 OWNER TO postgres;

--
-- Name: attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_id_seq OWNER TO postgres;

--
-- Name: attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_id_seq OWNED BY public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369.id;


--
-- Name: attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6 (
    id integer NOT NULL,
    entity_attribute_id integer,
    professional_male integer NOT NULL,
    semi_skilled_others_male integer NOT NULL,
    low_skilled_female integer NOT NULL,
    low_skilled_male integer NOT NULL,
    semi_skilled_others_female integer NOT NULL,
    skilled_male integer NOT NULL,
    semi_skilled_domestic_housekeeping_assistants_female integer NOT NULL,
    middle_level_male integer NOT NULL,
    clerical___related_female integer NOT NULL,
    clerical___related_male integer NOT NULL,
    total integer NOT NULL,
    country text NOT NULL,
    professional_female integer NOT NULL,
    skilled_female integer NOT NULL,
    middle_level_female integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6 OWNER TO postgres;

--
-- Name: attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_id_seq OWNER TO postgres;

--
-- Name: attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_id_seq OWNED BY public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6.id;


--
-- Name: attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932 (
    id integer NOT NULL,
    entity_attribute_id integer,
    district text NOT NULL,
    number_of_rooms integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932 OWNER TO postgres;

--
-- Name: attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_id_seq OWNER TO postgres;

--
-- Name: attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_id_seq OWNED BY public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932.id;


--
-- Name: attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0 (
    id integer NOT NULL,
    entity_attribute_id integer,
    arrivals integer NOT NULL,
    country_of_residence text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0 OWNER TO postgres;

--
-- Name: attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_id_seq OWNER TO postgres;

--
-- Name: attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_id_seq OWNED BY public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0.id;


--
-- Name: attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8 (
    id integer NOT NULL,
    entity_attribute_id integer,
    middle_level double precision NOT NULL,
    skilled double precision NOT NULL,
    clerical___related double precision NOT NULL,
    semi_skilled_domestic_housekeeping_assistants integer NOT NULL,
    semi_skilled_others double precision NOT NULL,
    total integer NOT NULL,
    year integer NOT NULL,
    professional_level double precision NOT NULL,
    low_skilled double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8 OWNER TO postgres;

--
-- Name: attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_id_seq OWNER TO postgres;

--
-- Name: attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_id_seq OWNED BY public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8.id;


--
-- Name: attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f (
    id integer NOT NULL,
    entity_attribute_id integer,
    age_group text NOT NULL,
    male integer NOT NULL,
    female integer NOT NULL,
    total integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f OWNER TO postgres;

--
-- Name: attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_id_seq OWNER TO postgres;

--
-- Name: attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_id_seq OWNED BY public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f.id;


--
-- Name: attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee (
    id integer NOT NULL,
    entity_attribute_id integer,
    middle_level_male integer NOT NULL,
    skilled_male integer NOT NULL,
    semi_skilled_domestic_housekeeping_assistants integer NOT NULL,
    middle_level_female integer NOT NULL,
    low_skilled_female integer NOT NULL,
    total integer NOT NULL,
    professional_female integer NOT NULL,
    professional_male integer NOT NULL,
    skilled_female integer NOT NULL,
    semi_skilled_others_female integer NOT NULL,
    clerical___related_female integer NOT NULL,
    low_skilled_male integer NOT NULL,
    district text NOT NULL,
    semi_skilled_others_male integer NOT NULL,
    clerical___related_male integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee OWNER TO postgres;

--
-- Name: attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_id_seq OWNER TO postgres;

--
-- Name: attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_id_seq OWNED BY public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee.id;


--
-- Name: attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8 (
    id integer NOT NULL,
    entity_attribute_id integer,
    province text NOT NULL,
    number_of_rooms integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8 OWNER TO postgres;

--
-- Name: attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_id_seq OWNER TO postgres;

--
-- Name: attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_id_seq OWNED BY public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8.id;


--
-- Name: attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb (
    id integer NOT NULL,
    entity_attribute_id integer,
    link text NOT NULL,
    summary text NOT NULL,
    category text NOT NULL,
    title text NOT NULL,
    date text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb OWNER TO postgres;

--
-- Name: attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_id_seq OWNER TO postgres;

--
-- Name: attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_id_seq OWNED BY public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb.id;


--
-- Name: attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289 (
    id integer NOT NULL,
    entity_attribute_id integer,
    number integer NOT NULL,
    percentage___ double precision NOT NULL,
    country text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289 OWNER TO postgres;

--
-- Name: attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_id_seq OWNER TO postgres;

--
-- Name: attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_id_seq OWNED BY public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289.id;


--
-- Name: attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c (
    id integer NOT NULL,
    entity_attribute_id integer,
    airline text NOT NULL,
    number_of_passengers integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c OWNER TO postgres;

--
-- Name: attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_id_seq OWNER TO postgres;

--
-- Name: attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_id_seq OWNED BY public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c.id;


--
-- Name: attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047 (
    id integer NOT NULL,
    entity_attribute_id integer,
    year text NOT NULL,
    male__number_ integer NOT NULL,
    male____ double precision NOT NULL,
    female__number_ integer NOT NULL,
    female____ double precision NOT NULL,
    total integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047 OWNER TO postgres;

--
-- Name: attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_id_seq OWNER TO postgres;

--
-- Name: attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_id_seq OWNED BY public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047.id;


--
-- Name: attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d (
    id integer NOT NULL,
    entity_attribute_id integer,
    professional_male integer NOT NULL,
    semi_skilled_other_male integer NOT NULL,
    middle_level_female integer NOT NULL,
    clerical___related_female integer NOT NULL,
    skilled_female integer NOT NULL,
    clerical___related_male integer NOT NULL,
    low_skilled_male integer NOT NULL,
    professional_female integer NOT NULL,
    skilled_male integer NOT NULL,
    domestic_housekeeping_assistant_female integer NOT NULL,
    low_skilled_female integer NOT NULL,
    semi_skilled_other_female integer NOT NULL,
    middle_level_male integer NOT NULL,
    total integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d OWNER TO postgres;

--
-- Name: attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_id_seq OWNER TO postgres;

--
-- Name: attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_id_seq OWNED BY public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d.id;


--
-- Name: attribute_schemas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attribute_schemas (
    id integer NOT NULL,
    table_name character varying(255) NOT NULL,
    schema_version integer NOT NULL,
    schema_definition jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attribute_schemas OWNER TO postgres;

--
-- Name: attribute_schemas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attribute_schemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attribute_schemas_id_seq OWNER TO postgres;

--
-- Name: attribute_schemas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attribute_schemas_id_seq OWNED BY public.attribute_schemas.id;


--
-- Name: entity_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entity_attributes (
    id integer NOT NULL,
    entity_id character varying(255) NOT NULL,
    attribute_name character varying(255) NOT NULL,
    table_name character varying(255) NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.entity_attributes OWNER TO postgres;

--
-- Name: entity_attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.entity_attributes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.entity_attributes_id_seq OWNER TO postgres;

--
-- Name: entity_attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.entity_attributes_id_seq OWNED BY public.entity_attributes.id;


--
-- Name: attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_id_seq'::regclass);


--
-- Name: attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440 ALTER COLUMN id SET DEFAULT nextval('public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_id_seq'::regclass);


--
-- Name: attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2 ALTER COLUMN id SET DEFAULT nextval('public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_id_seq'::regclass);


--
-- Name: attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_id_seq'::regclass);


--
-- Name: attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_id_seq'::regclass);


--
-- Name: attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_id_seq'::regclass);


--
-- Name: attr_cat_333e54f020_db905fd311_2022_cat_333e54f020 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_id_seq'::regclass);


--
-- Name: attr_cat_382785f270_f19d1a303a_2022_cat_382785f270 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_id_seq'::regclass);


--
-- Name: attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_id_seq'::regclass);


--
-- Name: attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_id_seq'::regclass);


--
-- Name: attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_id_seq'::regclass);


--
-- Name: attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_id_seq'::regclass);


--
-- Name: attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_id_seq'::regclass);


--
-- Name: attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_id_seq'::regclass);


--
-- Name: attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_id_seq'::regclass);


--
-- Name: attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_id_seq'::regclass);


--
-- Name: attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_id_seq'::regclass);


--
-- Name: attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_id_seq'::regclass);


--
-- Name: attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_id_seq'::regclass);


--
-- Name: attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_id_seq'::regclass);


--
-- Name: attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_id_seq'::regclass);


--
-- Name: attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047 ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_id_seq'::regclass);


--
-- Name: attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d ALTER COLUMN id SET DEFAULT nextval('public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_id_seq'::regclass);


--
-- Name: attribute_schemas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attribute_schemas ALTER COLUMN id SET DEFAULT nextval('public.attribute_schemas_id_seq'::regclass);


--
-- Name: entity_attributes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_attributes ALTER COLUMN id SET DEFAULT nextval('public.entity_attributes_id_seq'::regclass);


--
-- Data for Name: attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165 (id, entity_attribute_id, year, number_of_raids_conducted, number_of_successful_raids, created_at) FROM stdin;
1	17	2022	27	27	2025-09-28 09:13:36.939735
\.


--
-- Data for Name: attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165 (id, entity_attribute_id, middle_east_as_a___of_total_remittance, year, remittances_middle_east__rs__million_, remittances_middle_east__us__million_, remittances_total__rs__million_, remittances_total__us__million_, created_at) FROM stdin;
1	15	65.8	2022	824491	2493	1252504	3789	2025-09-28 09:13:36.383754
\.


--
-- Data for Name: attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165 (id, entity_attribute_id, month, number_of_arrivals, created_at) FROM stdin;
1	13	January	62254	2025-09-28 09:13:35.819242
2	13	February	56199	2025-09-28 09:13:35.819242
3	13	March	73595	2025-09-28 09:13:35.819242
4	13	April	75631	2025-09-28 09:13:35.819242
5	13	May	63305	2025-09-28 09:13:35.819242
6	13	June	77467	2025-09-28 09:13:35.819242
7	13	July	84407	2025-09-28 09:13:35.819242
8	13	August	71683	2025-09-28 09:13:35.819242
9	13	September	68412	2025-09-28 09:13:35.819242
10	13	October	77158	2025-09-28 09:13:35.819242
11	13	November	82985	2025-09-28 09:13:35.819242
12	13	December	101907	2025-09-28 09:13:35.819242
\.


--
-- Data for Name: attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165 (id, entity_attribute_id, year, complaints_resolved, created_at) FROM stdin;
1	14	2022	4557	2025-09-28 09:13:36.074465
\.


--
-- Data for Name: attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165 (id, entity_attribute_id, ref__no_, division_activities, _rs_, created_at) FROM stdin;
1	16	1	Recovery by Litigation	1590000	2025-09-28 09:13:36.671942
2	16	2	Fines Imposed for cases filed	1640000	2025-09-28 09:13:36.671942
3	16	3	Remittances to the SLBFE (75% WWF) from fines imposed	1346250	2025-09-28 09:13:36.671942
4	16	4	Recovery from Korean runaway Cases	11470797	2025-09-28 09:13:36.671942
\.


--
-- Data for Name: attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165 (id, entity_attribute_id, month, earning__rs__million_, created_at) FROM stdin;
1	11	January	52224.2	2025-09-28 09:13:35.023814
2	11	February	41340.8	2025-09-28 09:13:35.023814
3	11	March	81449.3	2025-09-28 09:13:35.023814
4	11	April	79522.4	2025-09-28 09:13:35.023814
5	11	May	109167.3	2025-09-28 09:13:35.023814
6	11	June	98815.2	2025-09-28 09:13:35.023814
7	11	July	100854.2	2025-09-28 09:13:35.023814
8	11	August	117453.4	2025-09-28 09:13:35.023814
9	11	September	130214.7	2025-09-28 09:13:35.023814
10	11	October	129046.6	2025-09-28 09:13:35.023814
11	11	November	139690.8	2025-09-28 09:13:35.023814
12	11	December	172725.2	2025-09-28 09:13:35.023814
\.


--
-- Data for Name: attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165 (id, entity_attribute_id, year, complaints_received, created_at) FROM stdin;
1	10	2022	4500	2025-09-28 09:13:34.685353
\.


--
-- Data for Name: attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165 (id, entity_attribute_id, month, number_of_persons, created_at) FROM stdin;
1	12	January	70803	2025-09-28 09:13:35.541553
2	12	February	72425	2025-09-28 09:13:35.541553
3	12	March	89684	2025-09-28 09:13:35.541553
4	12	April	83562	2025-09-28 09:13:35.541553
5	12	May	85715	2025-09-28 09:13:35.541553
6	12	June	92523	2025-09-28 09:13:35.541553
7	12	July	93244	2025-09-28 09:13:35.541553
8	12	August	107835	2025-09-28 09:13:35.541553
9	12	September	116436	2025-09-28 09:13:35.541553
10	12	October	109010	2025-09-28 09:13:35.541553
11	12	November	100119	2025-09-28 09:13:35.541553
12	12	December	106405	2025-09-28 09:13:35.541553
\.


--
-- Data for Name: attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20 (id, entity_attribute_id, nationality, number_of_foreigners_with_refused_entry, created_at) FROM stdin;
1	22	Pakistani	84	2025-09-28 09:13:40.466278
2	22	Indian	70	2025-09-28 09:13:40.466278
3	22	Chinese	7	2025-09-28 09:13:40.466278
4	22	Sudanese	6	2025-09-28 09:13:40.466278
5	22	British	5	2025-09-28 09:13:40.466278
6	22	Maldivian	5	2025-09-28 09:13:40.466278
7	22	Thai	5	2025-09-28 09:13:40.466278
8	22	Uzbek	5	2025-09-28 09:13:40.466278
9	22	Tanzanian	3	2025-09-28 09:13:40.466278
10	22	German	2	2025-09-28 09:13:40.466278
11	22	Australians	2	2025-09-28 09:13:40.466278
12	22	Canadian	2	2025-09-28 09:13:40.466278
13	22	Malaysians	2	2025-09-28 09:13:40.466278
14	22	Yemenis	2	2025-09-28 09:13:40.466278
15	22	Kyrgyz	2	2025-09-28 09:13:40.466278
16	22	South Africans	2	2025-09-28 09:13:40.466278
17	22	American	1	2025-09-28 09:13:40.466278
18	22	Bangladeshi	1	2025-09-28 09:13:40.466278
19	22	Iranian	1	2025-09-28 09:13:40.466278
20	22	Afghans	1	2025-09-28 09:13:40.466278
21	22	Russian	1	2025-09-28 09:13:40.466278
22	22	French	1	2025-09-28 09:13:40.466278
23	22	Nigerians	1	2025-09-28 09:13:40.466278
24	22	Iraqian	1	2025-09-28 09:13:40.466278
25	22	Syrian	1	2025-09-28 09:13:40.466278
26	22	Filipinos	1	2025-09-28 09:13:40.466278
27	22	Israeli	1	2025-09-28 09:13:40.466278
28	22	Colombians	1	2025-09-28 09:13:40.466278
29	22	Moroccans	1	2025-09-28 09:13:40.466278
30	22	Austrian	1	2025-09-28 09:13:40.466278
31	22	Nepalese	1	2025-09-28 09:13:40.466278
32	22	Tajiks	1	2025-09-28 09:13:40.466278
33	22	South Koreans	1	2025-09-28 09:13:40.466278
34	22	Ethiopians	1	2025-09-28 09:13:40.466278
35	22	Rwandan	1	2025-09-28 09:13:40.466278
\.


--
-- Data for Name: attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20 (id, entity_attribute_id, nationality, no__of_persons, created_at) FROM stdin;
1	25	Pakistani	196	2025-09-28 09:13:41.996478
2	25	Nigerian	4	2025-09-28 09:13:41.996478
3	25	Indian	4	2025-09-28 09:13:41.996478
4	25	Iraqi	4	2025-09-28 09:13:41.996478
5	25	Belarusian	3	2025-09-28 09:13:41.996478
6	25	Iranian	3	2025-09-28 09:13:41.996478
7	25	Burmese	2	2025-09-28 09:13:41.996478
8	25	Maldivian	2	2025-09-28 09:13:41.996478
9	25	Palestinian	1	2025-09-28 09:13:41.996478
\.


--
-- Data for Name: attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20 (id, entity_attribute_id, nationality, no__entered, no__removed, created_at) FROM stdin;
1	23	Indian Fishermen	311	311	2025-09-28 09:13:41.35627
2	23	Indian	12	11	2025-09-28 09:13:41.35627
3	23	Iranian	4	4	2025-09-28 09:13:41.35627
4	23	Pakistani	3	3	2025-09-28 09:13:41.35627
5	23	Maldivian	2	2	2025-09-28 09:13:41.35627
6	23	Nigerian	8	1	2025-09-28 09:13:41.35627
7	23	Australian	1	1	2025-09-28 09:13:41.35627
8	23	Chinese	3	1	2025-09-28 09:13:41.35627
9	23	German	1	1	2025-09-28 09:13:41.35627
10	23	Nepalese	1	1	2025-09-28 09:13:41.35627
11	23	Somali	1	1	2025-09-28 09:13:41.35627
12	23	Turkish	1	1	2025-09-28 09:13:41.35627
13	23	Burmese	104	0	2025-09-28 09:13:41.35627
14	23	Bangladeshi	1	0	2025-09-28 09:13:41.35627
15	23	Belgian	1	0	2025-09-28 09:13:41.35627
16	23	Ivorian	1	0	2025-09-28 09:13:41.35627
17	23	Syrian	1	0	2025-09-28 09:13:41.35627
\.


--
-- Data for Name: attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20 (id, entity_attribute_id, nationality, no__of_persons, created_at) FROM stdin;
1	24	Pakistani	347	2025-09-28 09:13:41.697022
2	24	Afghans	87	2025-09-28 09:13:41.697022
3	24	Burmese	36	2025-09-28 09:13:41.697022
4	24	Iranian	12	2025-09-28 09:13:41.697022
5	24	Sudanese	9	2025-09-28 09:13:41.697022
6	24	Yemeni	8	2025-09-28 09:13:41.697022
7	24	Palestinian	5	2025-09-28 09:13:41.697022
8	24	Nigerian	2	2025-09-28 09:13:41.697022
9	24	Syrian	2	2025-09-28 09:13:41.697022
10	24	Maldivian	2	2025-09-28 09:13:41.697022
11	24	Bangladeshi	1	2025-09-28 09:13:41.697022
12	24	Somali	1	2025-09-28 09:13:41.697022
\.


--
-- Data for Name: attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440 (id, entity_attribute_id, country, arrivals, share, created_at) FROM stdin;
1	29	India	123004	17.1	2025-09-28 09:13:43.532401
2	29	Russian Federation	91272	12.7	2025-09-28 09:13:43.532401
3	29	United Kingdom	85187	11.8	2025-09-28 09:13:43.532401
4	29	Germany	55542	7.7	2025-09-28 09:13:43.532401
5	29	France	35482	4.9	2025-09-28 09:13:43.532401
6	29	Australia	30924	4.3	2025-09-28 09:13:43.532401
7	29	Canada	26845	3.7	2025-09-28 09:13:43.532401
8	29	United States	22230	3.1	2025-09-28 09:13:43.532401
9	29	Maldives	18880	2.6	2025-09-28 09:13:43.532401
10	29	Poland	18107	2.1	2025-09-28 09:13:43.532401
\.


--
-- Data for Name: attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440 (id, entity_attribute_id, year, value_in_rupees_mn_, value_in_usd_mn_, created_at) FROM stdin;
1	28	2022	362426	1136.3	2025-09-28 09:13:43.253397
\.


--
-- Data for Name: attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2 (id, entity_attribute_id, category, staff_type, approved_cadre, existing, vacancy_excess_count, vacancy_excess_type, created_at) FROM stdin;
1	21	Senior	Staff of the Ministry (Colombo)	104	93	11	vacancies	2025-09-28 09:13:40.234293
2	21	Tertiary 	Staff of the Ministry (Colombo)	11	1	10	vacancies	2025-09-28 09:13:40.234293
3	21	Secondary	Staff of the Ministry (Colombo)	370	397	27	excess	2025-09-28 09:13:40.234293
4	21	Primary 	Staff of the Ministry (Colombo)	126	129	3	excess	2025-09-28 09:13:40.234293
5	21	Senior/Tertiary (Home Based)	Staff of the Missions	258	175	83	vacancies	2025-09-28 09:13:40.234293
6	21	Secondary (Home Based)	Staff of the Missions	263	189	74	vacancies	2025-09-28 09:13:40.234293
7	21	Primary (Home Based)	Staff of the Missions	7	6	1	vacancies	2025-09-28 09:13:40.234293
8	21	Secondary (Locally Recruited)	Staff of the Missions	255	165	90	vacancies	2025-09-28 09:13:40.234293
9	21	Primary (Locally Recruited)	Staff of the Missions	327	238	89	vacancies	2025-09-28 09:13:40.234293
\.


--
-- Data for Name: attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30 (id, entity_attribute_id, title, date, link, summary, category, created_at) FROM stdin;
1	19	Another donation of urgent medicine worth USD 7.2 million from  Heart to heart international in the United States to the people of Sri Lanka	30.12.2022	https://mfa.gov.lk/en/another-donation-of-urgent-medicine-worth-usd-7-2-million-from-heart-to-heart-international-in-the-united-states-to-the-people-of-sri-lanka/	Heart to Heart International in the United States has donated urgent medicine worth USD 7.2 million to the people of Sri Lanka. The donation was made under the guidance of His Excellency Ambassador Mahinda Samarasinghe, according to a joint press release by the Embassy of Sri Lanka, Washington D.C., and Heart to Heart International.	Mission News	2025-09-28 09:13:38.752259
2	19	Sri Lanka participates at the OTOP City-2022 in Thailand for the first time	30.12.2022	https://mfa.gov.lk/en/sri-lanka-participates-at-the-otop-city-2022-in-thailand-for-the-first-time/	For the first time, Sri Lanka participated in the OTOP City-2022 event in Thailand, organized by the Embassy and Permanent Mission of Sri Lanka in Bangkok in collaboration with the Community Development Department of the Ministry of Interior of Thailand. The event aimed to showcase Sri Lankan products and promote cultural exchange between the two countries.	Mission News	2025-09-28 09:13:38.752259
3	19	Sri Lanka High Commission in Singapore celebrates Christmas	30.12.2022	https://mfa.gov.lk/en/sri-lanka-high-commission-in-singapore-celebrates-christmas-2/	The Sri Lanka High Commission in Singapore celebrated Christmas on 28 December 2022 with prayers, carols, and entertainment. The event began with a welcome address by the High Commissioner, marking a festive evening of joy and celebration.	Mission News	2025-09-28 09:13:38.752259
4	19	Embassy in Kuwait Celebrates Christmas with the Sri Lankan Community	29.12.2022	https://mfa.gov.lk/en/embassy-in-kuwait-celebrates-christmas-with-the-sri-lankan-community/	The Embassy of Sri Lanka in Kuwait, along with the Sri Lankan community, celebrated Christmas on December 22, 2022, at the Embassy premises, fostering unity and harmony during the festivities. The event brought together members of the community to mark the holiday season.	Mission News	2025-09-28 09:13:38.752259
5	19	Ambassador of Sri Lanka to Türkiye  Hasanthi Dissanayake, Presents Credentials in Ankara	29.12.2022	https://mfa.gov.lk/en/ambassador-of-sri-lanka-to-turkiye-hasanthi-dissanayake-presents-credentials-in-ankara/	Saranya Hasanthi Urugodawatte Dissanayake, the new Ambassador of Sri Lanka to Türkiye, presented her credentials to President Recep Tayyip Erdoğan on 27 December 2021 in Ankara.	Mission News	2025-09-28 09:13:38.752259
6	19	Sri Lanka joins “Reinvigoration of Ayutthaya’s Foreign Relations” conducted by the National Assembly of   the Kingdom of Thailand	28.12.2022	https://mfa.gov.lk/en/sri-lanka-joins-reinvigoration-of-ayutthayas-foreign-relations-conducted-by-the-national-assembly-of-the-kingdom-of-thailand/	Sri Lanka has joined the "Reinvigoration of Ayutthaya’s Foreign Relations" initiative led by the National Assembly of the Kingdom of Thailand. The Ambassador and Pe were invited by the Chairman of the Senate Committee on Upholding the Monarchy and the Senate Standing Committee on Foreign Affairs.	Mission News	2025-09-28 09:13:38.752259
7	19	Sri Lanka shines at “3rd International Thai Silk Fashion Week”   in Bangkok	28.12.2022	https://mfa.gov.lk/en/sri-lanka-shines-at-3rd-international-thai-silk-fashion-week-in-bangkok-2/	Sri Lanka showcased its talent at the "3rd International Thai Silk Fashion Week" in Bangkok with the participation of Creative Director Darshi Keerthisena from Buddhi Batiks, coordinated by the Embassy and Permanent Mission of Sri Lanka in Bangkok. The event was held at Royal Paragon Hall.	Mission News	2025-09-28 09:13:38.752259
8	19	Embassy of Sri Lanka in Brazil networks with Brazilian media  to promote Sri Lankan Tourism, Cuisine and Ceylon Tea	27.12.2022	https://mfa.gov.lk/en/embassy-of-sri-lanka-in-brazil-networks-with-brazilian-media-to-promote-sri-lankan-tourism-cuisine-and-ceylon-tea/	The Embassy of Sri Lanka in Brazil recently held a networking session with journalists from Brasilia-based printed and electronic media to promote Sri Lankan tourism, cuisine, and Ceylon tea. This initiative is part of the embassy's efforts to boost trade and tourism promotion between the two countries.	Mission News	2025-09-28 09:13:38.752259
9	19	Sri Lanka and Cambodia Exempt Visa for holders of Diplomatic and Official Passports with effect from 24 December 2022	27.12.2022	https://mfa.gov.lk/en/sri-lanka-and-cambodia-exempt-visa-for-holders-of-diplomatic-and-official-passports-with-effect-from-24-december-2022/	Sri Lanka and Cambodia have agreed to exempt visa requirements for holders of Diplomatic and Official Passports starting from 24 December 2022. The agreement was signed on 10 May 2022 at the Ministry of Foreign Affairs and International Cooperation. This initiative aims to facilitate easier travel for diplomatic and official passport holders between the two countries.	Mission News	2025-09-28 09:13:38.752259
10	19	Sri Lankan Ambassador calls on the Kuwait Parliament Speaker	23.12.2022	https://mfa.gov.lk/en/sri-lankan-ambassador-calls-on-the-kuwait-parliament-speaker/	Sri Lanka’s Ambassador to Kuwait, U. L. Mohammed Jauhar, recently met with Kuwait's Parliament Speaker, Ahmad Abdulaziz Al-Saadoun, who has been appointed to the position for the fourth time. The meeting was a courtesy call to strengthen diplomatic ties between the two nations.	Mission News	2025-09-28 09:13:38.752259
11	19	False information on Pirith Chanting Ceremony held at the Embassy premises reported in Sri Lankan Media	22.12.2022	https://mfa.gov.lk/en/false-information-on-pirith-chanting-ceremony-held-at-the-embassy-premises-reported-in-sri-lankan-media/	The Embassy of Sri Lanka in Oman refutes false information reported by several Television Channels regarding a Pirith Chanting Ceremony held at the Embassy premises on 16 December 2022.	Mission News	2025-09-28 09:13:38.752259
12	19	South Indian investors are invited to invest in Sri Lanka	22.12.2022	https://mfa.gov.lk/en/south-indian-investors-are-invited-to-invest-in-sri-lanka/	South Indian investors are invited to explore trade and investment opportunities in Sri Lanka by the Deputy High Commission of Sri Lanka in Chennai in collaboration with the Southern India Chamber of Commerce & Industry (SICCI). This initiative aims to enhance awareness and foster economic partnerships between the two regions.	Mission News	2025-09-28 09:13:38.752259
13	19	High Commissioner Navaratne reiterates   that Sri Lanka  stands  for a healthy and sustainable planet at COP-15 in Montreal, Canada	21.12.2022	https://mfa.gov.lk/en/high-commissioner-navaratne-reiterates-that-sri-lanka-stands-for-a-healthy-and-sustainable-planet-at-cop-15-in-montreal-canada/	High Commissioner Harsh Kumara Navaratne reiterated Sri Lanka's commitment to a healthy and sustainable planet at COP-15 in Montreal, Canada. He stated that Sri Lanka is always ready to stand with the international community in achieving this goal.	Mission News	2025-09-28 09:13:38.752259
14	19	The Deputy High Commission of Sri Lanka in Chennai celebrates Christmas	21.12.2022	https://mfa.gov.lk/en/the-deputy-high-commission-of-sri-lanka-in-chennai-celebrates-christmas/	The Deputy High Commission of Sri Lanka in Chennai celebrated Christmas on December 16, 2022, at the Chancery premises. Rev. V. S. Vijayakumar delivered the Christmas message and bestowed blessings during the event. It was a festive celebration marking the holiday season.	Mission News	2025-09-28 09:13:38.752259
15	19	65th Anniversary of diplomatic relations between Sri Lanka and Nepal celebrated in   Kathmandu	21.12.2022	https://mfa.gov.lk/en/65th-anniversary-of-diplomatic-relations-between-sri-lanka-and-nepal-celebrated-in-kathmandu/	In Kathmandu, a dialogue titled "Nepal-Sri Lanka Friendship: From Ancient Links to the Present" was held on December 19, 2022, to celebrate the 65th anniversary of diplomatic relations between Sri Lanka and Nepal. The event was organized by the Embassy of Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
16	19	Deputy High Commission of Sri Lanka for Southern India conducts  the 20th special consular camp	20.12.2022	https://mfa.gov.lk/en/deputy-high-commission-of-sri-lanka-for-southern-india-conducts-the-20th-special-consular-camp/	The Deputy High Commission of Sri Lanka for Southern India held its 20th special consular camp on December 14, 2022, at the Chancery premises. The event was attended by State Minister of Fisheries Piyal Nishantha De Silva.	Mission News	2025-09-28 09:13:38.752259
17	19	Appointment of Honorary Consul of Sri Lanka in Mindanao	16.12.2022	https://mfa.gov.lk/en/appointment-of-honorary-consul-of-sri-lanka-in-mindanao/	The Democratic Socialist Republic of Sri Lanka, in agreement with the Republic of the Philippines, has appointed William Chen as the Honorary Consul of Sri Lanka in Mindanao. He will have consular jurisdiction over the Davao region.	Mission News	2025-09-28 09:13:38.752259
18	19	The Consulate General of Sri Lanka inaugurates   ‘Tourism Promotional Window’	16.12.2022	https://mfa.gov.lk/en/the-consulate-general-of-sri-lanka-inaugurates-tourism-promotional-window/	The Consulate General of Sri Lanka in Jeddah, Falah Mowlana Alhabshi, officially inaugurated the 'Tourism Promotional Window' with the support of the Sri Lanka Tourism Promotion Bureau and guidance from the Ministry of Foreign Affairs. This initiative aims to promote tourism in Sri Lanka effectively.	Mission News	2025-09-28 09:13:38.752259
19	19	Sri Lankan Film “The Newspaper” screened in Riyadh	16.12.2022	https://mfa.gov.lk/en/sri-lankan-film-the-newspaper-screened-in-riyadh/	The Sri Lankan film "The Newspaper," directed by Sartah Kothalawala and Kumara Thirimadura, was screened in Riyadh, Saudi Arabia as part of the "Ambassador's Choice: Film Festival" organized by the Embassy of India.	Mission News	2025-09-28 09:13:38.752259
20	19	Sri Lanka promotes business ties with the UAE	16.12.2022	https://mfa.gov.lk/en/sri-lanka-promotes-business-ties-with-the-uae/	Sri Lanka's Consulate General in Dubai, along with the National Chamber of Exporters, facilitated a visit by a 12-member business delegation from Sri Lanka to the UAE from December 5 to 9. The delegation aimed to strengthen business ties between the two countries.	Mission News	2025-09-28 09:13:38.752259
21	19	Ambassador Wishwanath Aponsu presents Letter of Credence to Chairperson of Mejlis of Turkmenistan Gülşat Mämmedowa	15.12.2022	https://mfa.gov.lk/en/ambassador-wishwanath-aponsu-presents-letter-of-credence-to-chairperson-of-mejlis-of-turkmenistan-gulsat-mammedowa/	Ambassador G.M.V. Wishwanath Aponsu presented his Letter of Credence to Gülşat Mämmedowa, the Chairperson of the Mejlis of Turkmenistan, on December 8, 2022, at the Mejlis Complex in Ashgabat.	Mission News	2025-09-28 09:13:38.752259
22	19	Consul General-designate of the Consulate General of Sri Lanka in Melbourne assumes duties	15.12.2022	https://mfa.gov.lk/en/consul-general-designate-of-the-consulate-general-of-sri-lanka-in-melbourne-assumes-duties/	Sandith Samarasinghe, the Consul General-designate of Sri Lanka to Victoria, South Australia, and Tasmania, assumed duties at the Consulate General of Sri Lanka in Melbourne on December 12, 2022. He officially started his role at the consulate, addressing the responsibilities and tasks ahead.	Mission News	2025-09-28 09:13:38.752259
23	19	Ambassador of Sri Lanka to the Philippines pays a farewell call on the Secretary (Minister) of Foreign Affairs of the Philippines	13.12.2022	https://mfa.gov.lk/en/ambassador-of-sri-lanka-to-the-philippines-pays-a-farewell-call-on-the-secretary-minister-of-foreign-affairs-of-the-philippines/	Sri Lankan Ambassador to the Philippines, Shobini Gunasekera, bid farewell to Philippine Foreign Affairs Secretary Enrique A. Manalo as she concluded her assignment. The ambassador paid a courtesy visit to Secretary Manalo to mark the end of her tenure.	Mission News	2025-09-28 09:13:38.752259
24	19	High Commissioner Moragoda meets Chief Coordinator for  India’s G20 Presidency to discuss engagement opportunities for  Sri Lanka	13.12.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-meets-chief-coordinator-for-indias-g20-presidency-to-discuss-engagement-opportunities-for-sri-lanka/	Sri Lanka’s High Commissioner to India, Milinda Moragoda, met with Harsh Vardhan Shringla, the Chief Coordinator for India’s G20 Presidency for 2023, in New Delhi on December 12, 2022. The meeting aimed to discuss engagement opportunities for Sri Lanka in the context of India's G20 Presidency.	Mission News	2025-09-28 09:13:38.752259
25	19	High Commissioner Moragoda discusses ways to enhance cooperation at parliamentary level with Chairman of the Committee on External Affairs of the Indian Parliament	13.12.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-discusses-ways-to-enhance-cooperation-at-parliamentary-level-with-chairman-of-the-committee-on-external-affairs-of-the-indian-parliament/	Sri Lanka's High Commissioner to India, Milinda Moragoda, discussed enhancing cooperation at the parliamentary level with the Chairman of the Committee on External Affairs of the Indian Parliament. Both countries explored ways to strengthen collaboration during the meeting.	Mission News	2025-09-28 09:13:38.752259
26	19	Appointment of a new Honorary Consul in Tyrol	13.12.2022	https://mfa.gov.lk/en/appointment-of-a-new-honorary-consul-in-tyrol/	Dr. Christian Steppan has been appointed as the new Honorary Consul of Sri Lanka in Tyrol, with the approval of both the Government of Sri Lanka and the Government of the Republic of Austria. The official ceremony for the appointment has taken place.	Mission News	2025-09-28 09:13:38.752259
27	19	The Embassy of Sri Lanka in Viet Nam participates in  International Food Festival 2022	12.12.2022	https://mfa.gov.lk/en/the-embassy-of-sri-lanka-in-viet-nam-participates-in-international-food-festival-2022/	The Embassy of Sri Lanka in Ha Noi, Viet Nam took part in the 2022 International Food Festival organized by the Ministry of Foreign Affairs of Viet Nam on December 11.	Mission News	2025-09-28 09:13:38.752259
28	19	High Commissioner Moragoda invited to address the Economic Advisory Council to the Prime Minister of India	08.12.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-invited-to-address-the-economic-advisory-council-to-the-prime-minister-of-india/	Sri Lanka’s High Commissioner to India, Milinda Moragoda, was invited to address the Economic Advisory Council to the Prime Minister of India. He met with the Chairman of the EAC-PM, Dr. Bibek Debroy, on December 8, 2022, at the latter’s office in New Delhi.	Mission News	2025-09-28 09:13:38.752259
29	19	Transit visit of State Minister of Foreign Affairs to Singapore	07.12.2022	https://mfa.gov.lk/en/transit-visit-smfa-singapore/	State Minister of Foreign Affairs Tharaka Balasuriya made a brief transit visit to Singapore on December 7, 2022. During the visit, he met with the Senior Minister of State from the Ministry of Foreign Affairs and Ministry of N.	Mission News	2025-09-28 09:13:38.752259
30	19	Sri Lanka showcases handicraft, Ceylon tea and cuisine at UNWG International Charity Bazaar 2022	06.12.2022	https://mfa.gov.lk/en/sri-lanka-showcases-handicraft-ceylon-tea-and-cuisine-at-unwg-international-charity-bazaar-2022/	Sri Lanka, along with other embassies, showcased its handicrafts, Ceylon tea, and cuisine at the UNWG International Charity Bazaar 2022 organized by the United Nations Women’s Guild. The Embassy and Permanent Mission of Sri Lanka actively participated in the event, highlighting the country's cultural offerings to support charity initiatives.	Mission News	2025-09-28 09:13:38.752259
31	19	High Commissioner Moragoda meets Finance Minister of India to review the status of bilateral economic cooperation	06.12.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-meets-finance-minister-of-india-to-review-the-status-of-bilateral-economic-cooperation/	Sri Lankan High Commissioner to India, Milinda Moragoda, met with India's Finance and Corporate Affairs Minister, Nirmala Sitharaman, on December 6, 2022, at her office in North Block, New Delhi. The meeting aimed to review the status of bilateral economic cooperation between the two countries.	Mission News	2025-09-28 09:13:38.752259
32	19	Sri Lankan businesses participate in the Viet Nam Expo for the first time	06.12.2022	https://mfa.gov.lk/en/sri-lankan-businesses-participate-in-the-viet-nam-expo-for-the-first-time/	Sri Lankan businesses participated in the Viet Nam Expo for the first time, organized by the Embassy of Sri Lanka in collaboration with the Export Development Board (EDB). The event took place from 01 to 03 December 2022 at Sai, marking a significant milestone in bilateral trade relations.	Mission News	2025-09-28 09:13:38.752259
33	19	Sri Lanka signs the Second Additional Protocol to the Convention on Cybercrime on enhanced co-operation and disclosure of electronic evidence of the Council of Europe	06.12.2022	https://mfa.gov.lk/en/sri-lanka-signs-the-second-additional-protocol-to-the-convention-on-cybercrime-on-enhanced-co-operation-and-disclosure-of-electronic-evidence-of-the-council-of-europe/	Ambassador Grace Asirwatham signed the Second Additional Protocol to the Convention on Cybercrime on Enhanced Cooperation and Disclosure of Electronic Evidence on behalf of the Government of Sri Lanka. This protocol aims to enhance cooperation and facilitate the disclosure of electronic evidence, aligning with the Council of Europe's objectives in combating cybercrime.	Mission News	2025-09-28 09:13:38.752259
34	19	Fostering goodwill and solidarity through charity:  Donation of medical supplies to Sri Lanka from the Philippines	05.12.2022	https://mfa.gov.lk/en/fostering-goodwill-and-solidarity-through-charity-donation-of-medical-supplies-to-sri-lanka-from-the-philippines/	The Embassy of Sri Lanka in Manila facilitated a donation of 5,000 units of peritoneal dialysis solutions from Michael Chen T., Chairman of the Philippines-Sri Lanka Business Council, to Sri Lanka, fostering goodwill and solidarity through charity.	Mission News	2025-09-28 09:13:38.752259
35	19	High Commissioner Moragoda interacts with envoys from Middle East, Central Asia and the Southeast Asian countries concurrently accredited to Sri Lanka	05.12.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-interacts-with-envoys-from-middle-east-central-asia-and-the-southeast-asian-countries-concurrently-accredited-to-sri-lanka/	Sri Lanka's High Commissioner to India, Milinda Moragoda, engaged with envoys from Middle East, Central Asia, and Southeast Asian countries concurrently accredited to Sri Lanka in New Delhi. This interaction is part of the High Commission's efforts to strengthen engagement with diplomatic missions.	Mission News	2025-09-28 09:13:38.752259
36	19	High Commissioner of Sri Lanka in Pakistan makes an official  visit to Karachi	05.12.2022	https://mfa.gov.lk/en/high-commissioner-of-sri-lanka-in-pakistan-makes-an-official-visit-to-karachi/	The High Commissioner of Sri Lanka in Pakistan, Vice Admiral Mohan Wijewickrama, visited Karachi from 26 to 29 November 2022. During his visit, he engaged with business communities and participated in promotional activities, strengthening bilateral ties between the two countries.	Mission News	2025-09-28 09:13:38.752259
37	19	Foreign Minister Ali Sabry Meets U.S. Secretary of State Antony Blinken in Washington D.C.	03.12.2022	https://mfa.gov.lk/en/fmsl-us-sec-2022/	Foreign Minister Ali Sabry visited Washington D.C. from November 30 to December 2, 2022, to meet with U.S. Secretary of State Antony Blinken. The two officials held discussions during the visit.	Mission News	2025-09-28 09:13:38.752259
38	19	​Sinopec to Import and Market Sri Lanka Products at 27,000 Outlets	02.12.2022	https://mfa.gov.lk/en/%e2%80%8bsinopec-to-import-and-market-sri-lanka-products-at-27000-outlets/	Sinopec, a major oil company with 27,000 service stations in China, has partnered with Beijing Sri Road Connection Trade Company Limited at the Shanghai CIIE to import and market products from Sri Lanka. The agreement will enable the distribution of Sri Lankan products through Sinopec's extensive network of outlets.	Mission News	2025-09-28 09:13:38.752259
39	19	Honorary Consul in Belgium, felicitated for 25 years of service to Sri Lanka	01.12.2022	https://mfa.gov.lk/en/honorary-consul-in-belgium-felicitated-for-25-years-of-service-to-sri-lanka/	The Embassy of Sri Lanka in Brussels honored Monique De Decker-Deprez for her 25 years of service as Sri Lanka's Honorary Consul in Antwerp, Belgium on November 22, 2022. The event celebrated her long-standing dedication to fostering relations between the two countries.	Mission News	2025-09-28 09:13:38.752259
40	19	The former President of China, Jiang Zemin will be long remembered	01.12.2022	https://mfa.gov.lk/en/the-former-president-of-china-jiang-zemin-will-be-long-remembered/	The Embassy of Sri Lanka to China expresses deep sadness over the passing of former Chinese President Jiang Zemin, who was widely regarded as an outstanding leader and greatly respected by his people. Jiang Zemin will be long remembered for his leadership and the sincere love he received from the Chinese population.	Mission News	2025-09-28 09:13:38.752259
41	19	Showcasing Sri Lanka’s finest products: Ceylon Tea, Spices, and Coffee at the International Bazaar 2022	29.11.2022	https://mfa.gov.lk/en/showcasing-sri-lankas-finest-products-ceylon-tea-spices-and-coffee-at-the-international-bazaar-2022/	The Embassy of Sri Lanka in Manila showcased the country's finest products, including Ceylon Tea, Spices, and Coffee, at the International Bazaar 2022 in Pasay City, Philippines on November 20, 2022. The event featured participation from local distributors of these renowned Sri Lankan products, held at the World Trade Center.	Mission News	2025-09-28 09:13:38.752259
42	19	Foreign Minister Ali Sabry calls on Prime Minister Sheikh Hasina of Bangladesh	26.11.2022	https://mfa.gov.lk/en/foreign-minister-ali-sabry-calls-on-prime-minister-sheikh-hasina-of-bangladesh/	Foreign Minister Ali Sabry visited Prime Minister Sheikh Hasina at her Official Residence in Dhaka, Bangladesh on 25 November 2022. During the meeting, they discussed longstanding diplomatic relations between their countries.	Mission News	2025-09-28 09:13:38.752259
43	19	Chinese cruise ships to visit Sri Lanka after travel restrictions are relaxed	25.11.2022	https://mfa.gov.lk/en/chinese-cruise-ships-to-visit-sri-lanka-after-travel-restrictions-are-relaxed/	Chinese cruise ships and yachts will soon visit Sri Lanka as travel restrictions are eased. The Sri Lanka Embassy in Beijing is working to attract more Chinese tourists, exploring opportunities for increased tourism. Ambassador Dr. Pa is actively involved in these efforts to enhance tourism between the two countries.	Mission News	2025-09-28 09:13:38.752259
44	19	Sri Lankan Embassy in Jakarta explores opportunities for Sri Lankan companies to enter the Indonesian market through Shopee– Ecommerce platform	25.11.2022	https://mfa.gov.lk/en/sri-lankan-embassy-in-jakarta-explores-opportunities-for-sri-lankan-companies-to-enter-the-indonesian-market-through-shopee-ecommerce-platform/	The Sri Lankan Embassy in Jakarta is exploring opportunities for Sri Lankan companies to enter the Indonesian market through Shopee, a leading e-commerce platform. Shopee, a Singapore-based multinational tech company, is the largest e-commerce platform in South East Asia with 343 million monthly visitors, serving consumers and businesses.	Mission News	2025-09-28 09:13:38.752259
45	19	Foreign Minister Sabry meets Sri Lankan business community in Bangladesh	25.11.2022	https://mfa.gov.lk/en/foreign-minister-sabry-meets-sri-lankan-business-community-in-bangladesh/	Foreign Minister Ali Sabry met with the Sri Lankan business community in Bangladesh, as well as Bangladesh business professionals, at a reception hosted at the official residence of Sri Lanka’s High Commissioner Prof. Sudharshan. The meeting aimed to strengthen economic ties and foster collaboration between the two countries.	Mission News	2025-09-28 09:13:38.752259
46	19	Foreign Minister Sabry discusses key areas of collaboration in shipping sector with Bangladesh	24.11.2022	https://mfa.gov.lk/en/foreign-minister-sabry-discusses-key-areas-of-collaboration-in-shipping-sector-with-bangladesh/	Foreign Minister Ali Sabry discussed collaboration in the shipping sector with Bangladesh's State Minister of Shipping, Khalid Mahmud Chowdhury on November 23. The meeting aimed to strengthen cooperation between the two countries in key areas of the shipping industry.	Mission News	2025-09-28 09:13:38.752259
47	19	Foreign Minister Sabry meets Foreign Minister of Bangladesh	24.11.2022	https://mfa.gov.lk/en/foreign-minister-sabry-meets-foreign-minister-of-bangladesh/	Foreign Minister Ali Sabry met with his counterpart, Foreign Minister Dr. A.K. Abdul Momen of Bangladesh, in Dhaka on 23 November. The meeting took place during Sabry's visit to Bangladesh to attend the Indian Ocean conference.	Mission News	2025-09-28 09:13:38.752259
48	19	New Ambassador to Japan assumes duties	23.11.2022	https://mfa.gov.lk/en/new-ambassador-to-japan-assumes-duties/	The newly appointed Ambassador of Sri Lanka to Japan, E. Rodney M. Perera, assumed duties on 27 October 2022 at the Sri Lanka Embassy in Tokyo. He is the eighteenth Sri Lankan Ambassador to Japan in the last 70 years.	Mission News	2025-09-28 09:13:38.752259
49	19	Bilateral collaboration in developing the migrant workers sector: Preliminary discussion between the Ministry of Labour and Foreign Employment and the Department of Migrant Workers-Philippines	23.11.2022	https://mfa.gov.lk/en/bilateral-collaboration-in-developing-the-migrant-workers-sector-preliminary-discussion-between-the-ministry-of-labour-and-foreign-employment-and-the-department-of-migrant-workers-philippines/	The Embassy of Sri Lanka in Manila organized a virtual meeting between the Ministry of Labour and Foreign Employment and the Department of Migrant Workers-Philippines to discuss bilateral collaboration in developing the migrant workers sector. The meeting served as a preliminary discussion on Sri Lanka's interest in conducting joint initiatives with the Philippines.	Mission News	2025-09-28 09:13:38.752259
50	19	The Government of Myanmar donates Medicines and Medical Supplies worth over USD 1.48 Million to Sri Lanka	22.11.2022	https://mfa.gov.lk/en/the-government-of-myanmar-donates-medicines-and-medical-supplies-worth-over-usd-1-48-million-to-sri-lanka/	The Government of Myanmar donated essential medicines and medical supplies valued at over USD 1.48 million to Sri Lanka on November 21, 2022. The donation aimed to address urgent medical needs in Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
51	19	Sri Lanka proposes to set up a group of Eminent Persons to galvanize greater political will to combat terrorist financing	21.11.2022	https://mfa.gov.lk/en/sri-lanka-proposes-to-set-up-a-group-of-eminent-persons-to-galvanize-greater-political-will-to-combat-terrorist-financing/	Sri Lanka has proposed establishing a group of Eminent Persons to boost political will and raise global awareness on combating terrorist financing. This initiative aims to enhance international cooperation and strengthen efforts to combat terrorism.	Mission News	2025-09-28 09:13:38.752259
52	19	Visit Sri Lanka – The Irresistible Tourist Hotspot in  the Middle of the Indian Ocean	21.11.2022	https://mfa.gov.lk/en/visit-sri-lanka-the-irresistible-tourist-hotspot-in-the-middle-of-the-indian-ocean/	Ambassador Dr. Palitha Kohona highlighted Sri Lanka's top-quality agricultural exports, with black tea being a major import. His remarks were made at the Wenzhou International Import Expo, showcasing Sri Lanka as an attractive tourist destination in the Indian Ocean.	Mission News	2025-09-28 09:13:38.752259
53	19	Sri Lanka Ambassador to the Philippines pays courtesy call on the Secretary (Minister) of Labor of the Philippines	21.11.2022	https://mfa.gov.lk/en/sri-lanka-ambassador-to-the-philippines-pays-courtesy-call-on-the-secretary-minister-of-labor-of-the-philippines/	Sri Lanka's Ambassador to the Philippines, Shobini Gunasekera, recently visited the Secretary of the Department of Labor and Employment (DOLE) of the Philippines, Bienvenido E. Lague, for a courtesy call. The meeting aimed to strengthen diplomatic ties between the two countries.	Mission News	2025-09-28 09:13:38.752259
54	19	Sri Lankans found in UAE	18.11.2022	https://mfa.gov.lk/en/sri-lankans-found-in-uae/	The Sri Lanka Embassy in Abu Dhabi is aware of media reports about 17 Sri Lankan nationals who entered Abu Dhabi on visit visas expecting job opportunities.	Mission News	2025-09-28 09:13:38.752259
55	19	Sri Lanka monitors welfare of crew aboard vessel detained by Nigeria	18.11.2022	https://mfa.gov.lk/en/sri-lanka-monitors-welfare-of-crew-aboard-vessel-detained-by-nigeria/	The High Commission of Sri Lanka in Kenya, also accredited to Nigeria, is overseeing the welfare of eight Sri Lankan crew members on the vessel M/T Heroic IDUN detained by Nigerian authorities. They are ensuring the crew's well-being during this situation.	Mission News	2025-09-28 09:13:38.752259
56	19	Sri Lanka will be the First Tourism Destination for “Spring Travel”	18.11.2022	https://mfa.gov.lk/en/sri-lanka-will-be-the-first-tourism-destination-for-spring-travel/	The Sri Lanka Embassy in Beijing is actively promoting Sri Lankan tourism in the Chinese market, aiming to attract one million Chinese tourists after the lifting of travel restrictions from China. Sri Lanka is set to become the first tourism destination for "Spring Travel.	Mission News	2025-09-28 09:13:38.752259
57	19	The Singapore -Sri Lanka Business Association (SLBA) donates medical supplies to the Ministry of Health of Sri Lanka	18.11.2022	https://mfa.gov.lk/en/the-singapore-sri-lanka-business-association-slba-donates-medical-supplies-to-the-ministry-of-health-of-sri-lanka/	The Singapore-Sri Lanka Business Association (SLBA) donated medical supplies worth 38,983.85 SGD (approximately 10 million LKR) to address a shortage in Sri Lanka. The supplies were given to the Ministry of Health of Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
199	19	Promotion of Sri Lanka Tourism in France	23.06.2022	https://mfa.gov.lk/en/promotion-of-sri-lanka-tourism-in-france/	The Embassy of Sri Lanka in Paris, in collaboration with Sri Lankan Airlines, organized a meeting between Sri Lanka's Minister of Tourism and Lands, Harin Fernando, and French travel agents to promote Sri Lanka tourism in France.	Mission News	2025-09-28 09:13:38.752259
58	19	Stranded Sri Lankan Female Domestic Workers in Oman	17.11.2022	https://mfa.gov.lk/en/stranded-sri-lankan-female-domestic-workers-in-oman/	Sri Lankan female domestic workers in Oman are stranded, with the Embassy of Sri Lanka in Muscat receiving numerous daily complaints. Many workers arrived in Oman on visit or tourist visas, facing challenges due to the current situation. The embassy is working to assist these workers and address their concerns effectively.	Mission News	2025-09-28 09:13:38.752259
59	19	Sri Lanka successfully takes part in the 5th CIIE	17.11.2022	https://mfa.gov.lk/en/sri-lanka-successfully-takes-part-in-the-5th-ciie/	Sri Lanka participated in the 5th CIIE in Shanghai, China, showcasing its Food and Beverages and Gems and Jewellery sectors. The expo concluded on November 11, 2022, with Sri Lankan exhibitors actively engaging with international visitors and businesses.	Mission News	2025-09-28 09:13:38.752259
60	19	Sri Lanka excels at the 4th Asian Under 18 Athletics Championship in Kuwait	16.11.2022	https://mfa.gov.lk/en/sri-lanka-excels-at-the-4th-asian-under-18-athletics-championship-in-kuwait/	Sri Lanka performed exceptionally at the 4th Asian Under 18 Athletics Championship 2022 in Kuwait City. The biennial competition featured Asian athletes aged 15 to 17 and took place at the Ahmed Al Rashdan Track and Field Stadium from 13 to 15.	Mission News	2025-09-28 09:13:38.752259
61	19	Deputy High Commissioner of Sri Lanka in Chennai hosts a dinner for Heads of the Mission in Chennai	16.11.2022	https://mfa.gov.lk/en/deputy-high-commissioner-of-sri-lanka-in-chennai-hosts-a-dinner-for-heads-of-the-mission-in-chennai/	The Deputy High Commissioner of Sri Lanka in Chennai, Dr. D. Venkateshwaran, hosted a dinner at his official residence on November 11, 2022, for the Heads of Mission in Chennai. The event aimed to facilitate networking and collaboration among diplomats in the region.	Mission News	2025-09-28 09:13:38.752259
62	19	Sri Lanka Embassy in Jakarta organizes a programme for Indonesian Immigration Polytechnic	15.11.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-jakarta-organizes-a-programme-for-indonesian-immigration-polytechnic/	The Sri Lanka Embassy in Jakarta organized a successful interactive event with the Indonesian Immigration Polytechnic (POLTEKIM) on November 11, 2022, at the Embassy premises. The programme aimed to foster collaboration and exchange between the two institutions.	Mission News	2025-09-28 09:13:38.752259
63	19	“Come Visit the Sapphire Capital of the World”- Ambassador Dr. Palitha Kohona at the CIIE International Jewellery Summit, Shanghai	15.11.2022	https://mfa.gov.lk/en/come-visit-the-sapphire-capital-of-the-world-ambassador-dr-palitha-kohona-at-the-ciie-international-jewellery-summit-shanghai/	Ambassador Dr. Palitha Kohona, keynote speaker at the CIIE International Jewellery Summit on November 10, 2022, encouraged attendees to visit Sri Lanka, known as the Sapphire Capital of the World. He highlighted the country's allure for fulfilling their dreams of exploring exquisite gemstones and jewelry.	Mission News	2025-09-28 09:13:38.752259
64	19	Ambassador C.A. Chaminda I. Colonne presents Letters of Credence  to President Thongloun Sisoulith of the Lao People’s Democratic Republic at Vientiane	15.11.2022	https://mfa.gov.lk/en/ambassador-c-a-chaminda-i-colonne-presents-letters-of-credence-to-president-thongloun-sisoulith-of-the-lao-peoples-democratic-republic-at-vientiane/	Ambassador C.A. Chaminda I. Colonne presented his Letters of Credence to President Thongloun Sisoulith of the Lao People’s Democratic Republic in Vientiane. Colonne serves as the Ambassador of Sri Lanka to the Kingdom of Thailand and Permanent Representative to the UNESCAP.	Mission News	2025-09-28 09:13:38.752259
65	19	Launch of the France- Sri Lanka Friendship Association	11.11.2022	https://mfa.gov.lk/en/launch-of-the-france-sri-lanka-friendship-association/	The France-Sri Lanka Friendship Association was launched during a meeting at the Embassy of Sri Lanka in Paris on November 3, 2022. The event was attended by well-wishers from different segments, marking the beginning of this new association.	Mission News	2025-09-28 09:13:38.752259
66	19	Sri Lanka successfully participates at the 53rd Annual WIC Charity Bazaar	11.11.2022	https://mfa.gov.lk/en/sri-lanka-successfully-participates-at-the-53rd-annual-wic-charity-bazaar/	Sri Lanka's Embassy in Jakarta took part in the 53rd Annual Charity Bazaar organized by the Women’s International Club (WIC) at the Grand Sahid Jaya Hotel on October 20, 2022. The event was a success, showcasing Sri Lankan culture and products to attendees.	Mission News	2025-09-28 09:13:38.752259
67	19	High Commission of Sri Lanka in New Delhi celebrates Diwali   felicitating long-serving staff members	10.11.2022	https://mfa.gov.lk/en/high-commission-of-sri-lanka-in-new-delhi-celebrates-diwali-felicitating-long-serving-staff-members/	The High Commission of Sri Lanka in New Delhi celebrated Diwali by honoring its long-serving Indian staff members. The event included a family get-together with the participation of both home-based staff and their family members.	Mission News	2025-09-28 09:13:38.752259
68	19	Ambassador Dr. Palitha Kohona Promotes Sri Lanka’s Tourist Attractions at the Shanghai CIIE	10.11.2022	https://mfa.gov.lk/en/ambassador-dr-palitha-kohona-promotes-sri-lankas-tourist-attractions-at-the-shanghai-ciie/	Ambassador Dr. Palitha Kohona promoted Sri Lanka's tourist attractions at the Shanghai CIIE by inviting dinner guests to consider it as their next travel option during the 5th China International Import Expo (CIIE) Culture, Tourism, and Health Summit Forum in Shanghai.	Mission News	2025-09-28 09:13:38.752259
69	19	“Visit to the Amazing Sri Lanka in NOWRUZ Season-2023”  A Tourism Promotion Programme held in Tehran	10.11.2022	https://mfa.gov.lk/en/visit-to-the-amazing-sri-lanka-in-nowruz-season-2023-a-tourism-promotion-programme-held-in-tehran/	The Embassy of Sri Lanka in Tehran, along with the Sri Lanka Tourism Promotion Bureau and the Association of Air Transport and Tourist Agencies in Iran, organized a Tourism Promotion Programme titled "Visit to the Amazing Sri Lanka in NOWRUZ Season-2023." The event aimed to promote tourism to Sri Lanka during the NOWRUZ Season of 2023.	Mission News	2025-09-28 09:13:38.752259
70	19	Embassy participated in Annual Katina Ceremony in Vienna, Austria	10.11.2022	https://mfa.gov.lk/en/embassy-participated-in-annual-katina-ceremony-in-vienna-austria/	The Embassy and the Permanent Mission of Sri Lanka in Vienna, Austria participated in the Annual Katina Ceremony by offering Heel Danaya to 12 members of the Maha Sangha on October 26, 2022. The almsgiving was a significant part of the ceremony.	Mission News	2025-09-28 09:13:38.752259
71	19	Mobile Consular Services Conducted in Batupahat, Malaysia	10.11.2022	https://mfa.gov.lk/en/mobile-consular-services-conducted-in-batupahat-malaysia/	The Sri Lanka High Commission in Malaysia conducted Mobile Consular Services in Batupahat, Johor, Malaysia on Sunday, November 6, 2022. Batupahat is located about 250 km from Kuala Lumpur, making it accessible for residents in the area to access consular services. This initiative aimed to provide convenient consular assistance to Sri Lankan nationals living in the region.	Mission News	2025-09-28 09:13:38.752259
214	19	Donation of Medicine	16.06.2022	https://mfa.gov.lk/en/donation-of-medicine/	Dato Anjela Nagoo Lai Choo, Chairperson of the Global Federation of Chinese Business Women, donated medicine worth MYR 29,900 to Sri Lanka. The donation was received by the High Commissioner of Sri Lanka to Malaysia, Air Chief Marshal (Retd) Sumangal.	Mission News	2025-09-28 09:13:38.752259
72	19	Sri Lanka Tourism showcased at World Travel Market in London	08.11.2022	https://mfa.gov.lk/en/sri-lanka-tourism-showcased-at-world-travel-market-in-london/	Sri Lanka Tourism Promotion Bureau (SLTPB) and 57 travel trade partners were showcased at the World Travel Market in London, facilitated by the Sri Lanka High Commission. The event took place at the ExCeL London, highlighting Sri Lanka's tourism offerings to a global audience.	Mission News	2025-09-28 09:13:38.752259
73	19	The Consulate General of Sri Lanka in Toronto constructively engages with the Sri Lankan Canadian Tamil Community in Ontario	08.11.2022	https://mfa.gov.lk/en/the-consulate-general-of-sri-lanka-in-toronto-constructively-engages-with-the-sri-lankan-canadian-tamil-community-in-ontario/	The Consulate General of Sri Lanka in Toronto, represented by Consul General Thushara Rodrigo, actively engaged with the Sri Lankan Canadian Tamil Community in Ontario by attending the Annual Festivals of the Murugan Kovil in Scarborough on October 30, 2022, at the invitation of the temple's Chief Priest. This event facilitated constructive interactions between the Consulate General and the community, fostering cultural and religious connections.	Mission News	2025-09-28 09:13:38.752259
74	19	Sri Lanka Consulate General in Karachi promotes collaboration in the field of yarn materials through the Pakistan Yarn Merchants Association	08.11.2022	https://mfa.gov.lk/en/sri-lanka-consulate-general-in-karachi-promotes-collaboration-in-the-field-of-yarn-materials-through-the-pakistan-yarn-merchants-association/	The Consul General of Sri Lanka in Karachi, Jagath Abeywarna, met with the newly elected Senior Vice-Chairman Sohail Nisar and members of the Pakistan Yarn Merchants Association on November 2, 2022, at their head office to promote collaboration in the field of yarn materials. The meeting aimed to strengthen ties and explore opportunities for cooperation between Sri Lanka and Pakistan in the yarn industry.	Mission News	2025-09-28 09:13:38.752259
75	19	President Ranil Wickremesinghe Addresses the CIIE	08.11.2022	https://mfa.gov.lk/en/president-ranil-wickremesinghe-addresses-the-ciie/	President Ranil Wickremesinghe was the first speaker after President Xi Jinping to address the 5th China International Import Expo (CIIE) and the Hongqiao Economic Forum virtually. The event was well-attended and highly prestigious.	Mission News	2025-09-28 09:13:38.752259
76	19	Sri Lankan Fashion, Food and Product showcase in Singapore	08.11.2022	https://mfa.gov.lk/en/sri-lankan-fashion-food-and-product-showcase-in-singapore/	Sri Lankan designers Sonali Dharmawardhane and Sarita Rajendran showcased their work in Singapore at an Afternoon Tea event hosted at the Sri Lanka Residence on October 29, 2022. The showcase featured unique fashion, food, and products, highlighting the creativity and talent of Sri Lankan artisans.	Mission News	2025-09-28 09:13:38.752259
77	19	Tourism Promotion Event in Paris	04.11.2022	https://mfa.gov.lk/en/tourism-promotion-event-in-paris/	The Embassy of Sri Lanka in France participated in a tourism promotion event in Paris on October 4 from 7.00 pm to 9.00 pm. The event was organized by PONANT, a French cruise ship operating company, to raise awareness about Sri Lanka's tourism offerings.	Mission News	2025-09-28 09:13:38.752259
78	19	The Islamic Republic of Iran Donates a Consignment of Essential Medicine and Medical Supplies to Sri Lanka	04.11.2022	https://mfa.gov.lk/en/the-islamic-republic-of-iran-donates-a-consignment-of-essential-medicine-and-medical-supplies-to-sri-lanka/	The Islamic Republic of Iran, in collaboration with the Iranian Red Crescent, donated a much-needed consignment of essential medicines and medical supplies to Sri Lanka. The donation was presented at a ceremony held in Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
79	19	UNESCAP successfully concludes the National Training for Women Entrepreneurs on Promoting Business through E-Commerce and Digital Marketing, at Suhurupaya, Sri Lanka	04.11.2022	https://mfa.gov.lk/en/unescap-successfully-concludes-the-national-training-for-women-entrepreneurs-on-promoting-business-through-e-commerce-and-digital-marketing-at-suhurupaya-sri-lanka/	UNESCAP successfully concluded the National Training for Women Entrepreneurs on Promoting Business through E-Commerce and Digital Marketing in Suhurupaya, Sri Lanka. The training was initiated by the Sri Lanka Embassy and Permanent Mission to UNESCAP in Thailand, and jointly organized to support women entrepreneurs in leveraging e-commerce and digital marketing for their businesses.	Mission News	2025-09-28 09:13:38.752259
80	19	Ambassador of Sri Lanka symbolically receives donations from Minister of Foreign Affairs of Thailand	04.11.2022	https://mfa.gov.lk/en/ambassador-of-sri-lanka-symbolically-receives-donations-from-minister-of-foreign-affairs-of-thailand/	At the Second handing over Ceremony at the Ministry of Foreign Affairs of Thailand, Deputy Prime Minister and Minister of Foreign Affairs Don Pramudwinai symbolically presented a cash donation of 14,000,000 T to the Ambassador of Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
81	19	Presentation of Open Copy of Letter of Credence – Ambassador (designate) of Sri Lanka to Türkiye	04.11.2022	https://mfa.gov.lk/en/presentation-of-open-copy-of-letter-of-credence-ambassador-designate-of-sri-lanka-to-turkiye/	Ambassador (designate) of Sri Lanka to Türkiye, S. Hasanthi Urugodawatte Dissanayake, presented open copies of her Letter of Credence to the Director General of Protocol at the Ministry of Foreign Affairs. This formal presentation marks her official appointment as the Ambassador of Sri Lanka to Türkiye.	Mission News	2025-09-28 09:13:38.752259
82	19	Public Security Minister Tiran Alles undertakes official visit to Singapore	04.11.2022	https://mfa.gov.lk/en/public-security-minister-tiran-alles-undertakes-official-visit-to-singapore/	Public Security Minister Tiran Alles visited Singapore from October 25-29, 2022, at the invitation of Singapore's Minister for Home Affairs and Minister for Law, K Shanmugam. The visit aimed to strengthen bilateral cooperation between the two countries.	Mission News	2025-09-28 09:13:38.752259
83	19	High Commission in Canberra hosts the first ‘Wes Mangallaya Ceremony’	03.11.2022	https://mfa.gov.lk/en/high-commission-in-canberra-hosts-the-first-wes-mangallaya-ceremony/	The Sri Lanka High Commission in Canberra hosted the first 'Wes Mangallaya Ceremony' organized by the Bhagya School of Dance on October 15, 2022. The event took place at the High Commission premises, featuring ten students from the dance school.	Mission News	2025-09-28 09:13:38.752259
84	19	Ceylon Tea and Tourism featured at the Courtney International Day in Pretoria, South Africa	03.11.2022	https://mfa.gov.lk/en/ceylon-tea-and-tourism-featured-at-the-courtney-international-day-in-pretoria-south-africa/	The Sri Lanka High Commission in South Africa showcased Ceylon Tea and Tourism at the Courtney International Day in Pretoria on October 29, 2022. The event featured participation from international organizations like PEN Charity and missions from various countries. It aimed to promote cultural exchange and cooperation among nations.	Mission News	2025-09-28 09:13:38.752259
113	19	The Governor of the Province of Namur in Belgium Inaugurates Sri Lanka Tourism Promotion Workshop	06.10.2022	https://mfa.gov.lk/en/the-governor-of-the-province-of-namur-in-belgium-inaugurates-sri-lanka-tourism-promotion-workshop/	The Governor of the Namur Province in Belgium, Denis Mathen, inaugurated a Sri Lanka Tourism Promotion Workshop organized by the Embassy of Sri Lanka in Brussels on October 4, 2022. Mathen expressed support for the promotion efforts during the event.	Mission News	2025-09-28 09:13:38.752259
85	19	Port of call and goodwill visit to Singapore by Sri Lanka Navy OPV P627	03.11.2022	https://mfa.gov.lk/en/port-of-call-and-goodwill-visit-to-singapore-by-sri-lanka-navy-opv-p627/	Sri Lanka Navy's recently acquired Offshore Patrol Vessel (OPV) P627, formerly known as USCG Douglas Munro, visited Singapore on a goodwill mission from October 22 to 26, 2022, after departing from Seattle, USA on September 3. The vessel made a port of call and engaged in diplomatic activities during its stay in Singapore.	Mission News	2025-09-28 09:13:38.752259
86	19	Donation of Medical Supplies by the Government of Malaysia	01.11.2022	https://mfa.gov.lk/en/donation-of-medical-supplies-by-the-government-of-malaysia/	The High Commission of Sri Lanka in Kuala Lumpur requested the Government of Malaysia for medical supplies following a request from the Ministry of Health of Sri Lanka. Malaysia responded by donating the required medical supplies to assist Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
87	19	Sri Lanka Deputy High Commission in Chennai Celebrates Diwali	01.11.2022	https://mfa.gov.lk/en/sri-lanka-deputy-high-commission-in-chennai-celebrates-diwali/	The Sri Lanka Deputy High Commission in Chennai celebrated Diwali, also known as the 'Festival of Lights', which is observed by Hindu, Jain, and Sikh communities in India and globally. The festival involves decorating homes, temples, and workspaces with lights and celebrating with family and friends.	Mission News	2025-09-28 09:13:38.752259
88	19	Ambassador Samarasinghe presents credentials to the Organization of American States	31.10.2022	https://mfa.gov.lk/en/ambassador-samarasinghe-presents-credentials-to-the-organization-of-american-states/	Ambassador Mahinda Samarasinghe of Sri Lanka, also accredited to Mexico and Trinidad and Tobago, presented his credentials to the Secretary-General of the Organization of American States (OAS), Ambassador Luis Almagro. This meeting signifies Samarasinghe's official recognition by the OAS.	Mission News	2025-09-28 09:13:38.752259
89	19	SLASSCOM ties up with INT@J in Jordan	31.10.2022	https://mfa.gov.lk/en/slasscom-ties-up-with-intj-in-jordan/	SLASSCOM and INT@J signed an MoU on October 27, 2022, under the Embassy of Sri Lanka in Jordan. The virtual signing was conducted by Chairman Ashique M. Ali on behalf of Sri Lanka, fostering collaboration between the two organizations.	Mission News	2025-09-28 09:13:38.752259
90	19	Sri Lanka successfully participates at the  18th International Seminar and Exhibition –  “The World of Tea” in Tehran	28.10.2022	https://mfa.gov.lk/en/sri-lanka-successfully-participates-at-the-18th-international-seminar-and-exhibition-the-world-of-tea-in-tehran/	Sri Lanka successfully participated in the 18th International Seminar and Exhibition "The World of Tea" in Tehran from October 24-26. The event was a collaboration between the Sri Lanka Embassy in Iran and the Sri Lanka Tea Board, held at the Parsian Esteghlal Hotel. Sri Lanka showcased its tea industry's excellence at the prestigious event.	Mission News	2025-09-28 09:13:38.752259
91	19	‘Friends of Sri Lanka Group’ re-launched in the European Parliament	28.10.2022	https://mfa.gov.lk/en/friends-of-sri-lanka-group-re-launched-in-the-european-parliament/	The Friends of Sri Lanka Group was re-launched at the Sri Lanka Residence in Brussels on October 25, 2022, with the announcement made by the Ambassador of Sri Lanka to the European Union, Grace Asirwatham.	Mission News	2025-09-28 09:13:38.752259
92	19	“Sri Lanka is open for business “– Visit of a Sri Lankan Business Delegation to the Philippines for the 48th PCCI Philippine Business Conference and Expo	28.10.2022	https://mfa.gov.lk/en/sri-lanka-is-open-for-business-visit-of-a-sri-lankan-business-delegation-to-the-philippines-for-the-48th-pcci-philippine-business-conference-and-expo/	A 30-member business delegation from Sri Lanka visited the 48th PCCI Philippine Business Conference and Expo in Manila from October 18-20, 2022, facilitated by the Sri Lankan Embassy. The delegation's presence highlighted Sri Lanka's interest in fostering business ties with the Philippines, showcasing opportunities for collaboration.	Mission News	2025-09-28 09:13:38.752259
93	19	Hambantota participates in Photography Exhibition of Sister/ Friendship Cities of Guangzhou, China	27.10.2022	https://mfa.gov.lk/en/hambantota-participates-in-photography-exhibition-of-sister-friendship-cities-of-guangzhou-china/	Hambantota recently took part in a photography exhibition organized by the Foreign Affairs Office of the Guangzhou Municipal People’s Government. The exhibition aimed to celebrate milestone anniversaries of sister/friendship cities worldwide, showcasing images from various participating cities.	Mission News	2025-09-28 09:13:38.752259
94	19	Annual Kathina Ceremony 2022, hosted by the Embassy of  Sri Lanka in Yangon	26.10.2022	https://mfa.gov.lk/en/annual-kathina-ceremony-2022-hosted-by-the-embassy-of-sri-lanka-in-yangon/	The Embassy of Sri Lanka in Yangon successfully hosted the Annual Kathina Ceremony of Pa Thein Monastery in Myanmar on Saturday, 22 October 2022. The event was attended by a large gathering, including Ven. S.	Mission News	2025-09-28 09:13:38.752259
95	19	Sri Lanka Ambassador to the Philippines pays courtesy call on the Secretary (Minister) of the Department of Migrant Workers of the Philippines	25.10.2022	https://mfa.gov.lk/en/sri-lanka-ambassador-to-the-philippines-pays-courtesy-call-on-the-secretary-minister-of-the-department-of-migrant-workers-of-the-philippines/	Sri Lanka's Ambassador to the Philippines, Shobini Gunasekera, recently visited the Secretary of the Department of Migrant Workers of the Philippines, Susan V. Ople, for a courtesy call. The meeting aimed to explore potential collaborations and initiatives between the two countries.	Mission News	2025-09-28 09:13:38.752259
96	19	Sri Lanka participates at the 11th Meeting of the Advisory Council of IORA Regional Centre for Science and Technology Transfer (RCSTT) in Tehran and highlights its interest in Enhancing Cooperation	25.10.2022	https://mfa.gov.lk/en/sri-lanka-participates-at-the-11th-meeting-of-the-advisory-council-of-iora-regional-centre-for-science-and-technology-transfer-rcstt-in-tehran-and-highlights-its-interest-in-enhancing-cooperation/	Sri Lanka participated in the 11th Meeting of the Advisory Council of IORA Regional Centre for Science and Technology Transfer (RCSTT) in Tehran on October 23, 2022. During the meeting, Sri Lanka highlighted its interest in enhancing cooperation within the organization.	Mission News	2025-09-28 09:13:38.752259
97	19	Laxmi Pooja and Diwali Celebration at Sri Lanka Consulate General in Mumbai	25.10.2022	https://mfa.gov.lk/en/laxmi-pooja-and-diwali-celebration-at-sri-lanka-consulate-general-in-mumbai/	The Consulate General of Sri Lanka in Mumbai organized a Laxmi Pooja at the chancery premises to celebrate Diwali on October 21, 2022. The event was attended by over 80 participants, including dignitaries.	Mission News	2025-09-28 09:13:38.752259
98	19	Port of call and goodwill visit in Manila by Sri Lanka Navy OPV P627	23.10.2022	https://mfa.gov.lk/en/port-of-call-and-goodwill-visit-in-manila-by-sri-lanka-navy-opv-p627/	Sri Lanka Navy's recently acquired Offshore Patrol Vessel (OPV) P627, formerly known as USCG Douglas Munro, visited Manila for a goodwill visit from October 12 to 16, 2022. The visit aimed to strengthen naval diplomacy between the two countries.	Mission News	2025-09-28 09:13:38.752259
99	19	Ambassador Mahinda Samarasinghe presents copies of his letter of credence as the Ambassador of Sri Lanka to Mexico	21.10.2022	https://mfa.gov.lk/en/ambassador-mahinda-samarasinghe-presents-copies-of-his-letter-of-credence-as-the-ambassador-of-sri-lanka-to-mexico/	Ambassador Mahinda Samarasinghe presented copies of his letter of credence as the Ambassador of Sri Lanka to Mexico at a formal ceremony on 19 October 2022 at the Mexican Cultural Centre in Washington D.C. The credentials were presented to the Ambassador of Mexico to the US, Esteban Moctez, during the event.	Mission News	2025-09-28 09:13:38.752259
100	19	Ceylon Cinnamon EU-PGI status promoted in Belgium	21.10.2022	https://mfa.gov.lk/en/ceylon-cinnamon-eu-pgi-status-promoted-in-belgium/	The Embassy of Sri Lanka in Belgium hosted an event on October 18, 2022, to promote the EU Protected Geographical Indication (PGI) status awarded to Ceylon Cinnamon, focusing on Ceylon Cinnamon quills. This status highlights the unique quality and origin of Ceylon Cinnamon in the European market.	Mission News	2025-09-28 09:13:38.752259
101	19	His Majesty Sultan of Oman receives Credentials of Ambassador of Sri Lanka	20.10.2022	https://mfa.gov.lk/en/his-majesty-sultan-of-oman-receives-credentials-of-ambassador-of-sri-lanka/	The newly appointed Ambassador of Sri Lanka to Oman, A.L Sabarullah Khan, presented his Letter of Credence to His Majesty Sultan Haitham bin Tarik. Sultan Haitham officially received the credentials during the ceremony.	Mission News	2025-09-28 09:13:38.752259
102	19	Buddhist Associations in Indonesia donate medicines  And medical devices to Sri Lanka	20.10.2022	https://mfa.gov.lk/en/buddhist-associations-in-indonesia-donate-medicines-and-medical-devices-to-sri-lanka/	Buddhist Associations in Indonesia, including WALUBI, MAGABUDHI, WANDANI, and Theravada You, have donated medicines and medical devices to Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
103	19	Courtesy call by Ambassador Shobini Gunasekera on the Secretary (Minister) of Foreign Affairs of the Philippines	18.10.2022	https://mfa.gov.lk/en/courtesy-call-by-ambassador-shobini-gunasekera-on-the-secretary-minister-of-foreign-affairs-of-the-philippines/	Sri Lanka's Ambassador to the Philippines, Shobini Gunasekera, recently visited the Secretary of Foreign Affairs of the Philippines, Enrique A. Manalo, at the Department of Foreign Affairs office for a courtesy call.	Mission News	2025-09-28 09:13:38.752259
104	19	Visit of the President of Sri Lanka Ranil Wickremesinghe to the Philippines for the 55th Annual Meeting of the Asian Development Bank Board of Governors	14.10.2022	https://mfa.gov.lk/en/visit-of-the-president-of-sri-lanka-ranil-wickremesinghe-to-the-philippines-for-the-55th-annual-meeting-of-the-asian-development-bank-board-of-governors/	President Ranil Wickremesinghe visited the Philippines from 28-30 September 2022 to chair the Governor’s Business Session at the 55th Annual Meeting of the Asian Development Bank (ADB) Board of Governors. His visit was in connection with the ADB's annual meeting.	Mission News	2025-09-28 09:13:38.752259
105	19	State Minister of Foreign Affairs Tharaka Balasuriya holds wide ranging discussions with the Sri Lankan Business Council in Dubai and the Northern Emirates	13.10.2022	https://mfa.gov.lk/en/state-minister-of-foreign-affairs-tharaka-balasuriya-holds-wide-ranging-discussions-with-the-sri-lankan-business-council-in-dubai-and-the-northern-emirates/	State Minister of Foreign Affairs Tharaka Balasuriya engaged in extensive discussions with the Chairman and Board of Directors of the Sri Lankan Business Council (SLBC) in Dubai and the Northern Emirates during a transit visit on October 11. The meeting aimed to strengthen ties and explore collaboration opportunities between Sri Lanka and the business community in the region.	Mission News	2025-09-28 09:13:38.752259
106	19	State Minister Tharaka Balasuriya meets the staff of the Consulate General of Sri Lanka in Dubai	13.10.2022	https://mfa.gov.lk/en/state-minister-tharaka-balasuriya-meets-the-staff-of-the-consulate-general-of-sri-lanka-in-dubai/	State Minister of Foreign Affairs Tharaka Balasuriya visited the Consulate General of Sri Lanka in Dubai on 11 October 2022 during a short transit visit. He met with the staff during his visit.	Mission News	2025-09-28 09:13:38.752259
107	19	Sri Lanka Consulate General promotes export of construction related materials through the Association of Builders and Developers (ABAD) in Pakistan	13.10.2022	https://mfa.gov.lk/en/sri-lanka-consulate-general-promotes-export-of-construction-related-materials-through-the-association-of-builders-and-developers-abad-in-pakistan/	The Consul General of Sri Lanka in Karachi met with the newly elected Chairman Altaf Tai and members of ABAD at the ABAD house to promote Sri Lankan construction materials. The CEO of Swissteck was also present during the meeting to discuss potential collaborations.	Mission News	2025-09-28 09:13:38.752259
108	19	A series of webinars for the promotion of coconut related products in Pakistan	13.10.2022	https://mfa.gov.lk/en/a-series-of-webinars-for-the-promotion-of-coconut-related-products-in-pakistan/	The Consulate General of Sri Lanka in Karachi and the Coconut Development Authority in Sri Lanka are collaborating to organize a series of webinars aimed at promoting coconut-related products in Pakistan. The goal is to enhance awareness and market opportunities for Sri Lankan coconut products in Pakistan.	Mission News	2025-09-28 09:13:38.752259
109	19	Ambassador Savitri Panabokke presents credentials to  President of the Republic of Korea	13.10.2022	https://mfa.gov.lk/en/ambassador-savitri-panabokke-presents-credentials-to-president-of-the-republic-of-korea/	Ambassador Savitri I. Panabokke of Sri Lanka presented her Letters of Credence to President Yoon Suk-yeol of the Republic of Korea at a ceremony in the President’s Office on October 11. This formal event marked the official beginning of her role as Sri Lanka's Ambassador to Korea.	Mission News	2025-09-28 09:13:38.752259
110	19	Sri Lanka successfully participates  at the 67th YWCA Diplomatic Charity Bazaar 2022 in Bangkok	10.10.2022	https://mfa.gov.lk/en/sri-lanka-successfully-participates-at-the-67th-ywca-diplomatic-charity-bazaar-2022-in-bangkok/	Sri Lanka successfully participated in the 67th YWCA Diplomatic Charity Bazaar 2022 in Bangkok. The Embassy and Permanent Mission of Sri Lanka in Bangkok collaborated with the Spices and Allied Products Marketing Board, National Crafts Council, Sri Lanka Export Development Board, and Industrial Development Board for the event.	Mission News	2025-09-28 09:13:38.752259
111	19	“Discover the Tropical Island Paradise of Sri Lanka”: an event to promote Sri Lanka Tourism in Washington D.C., USA	07.10.2022	https://mfa.gov.lk/en/discover-the-tropical-island-paradise-of-sri-lanka-an-event-to-promote-sri-lanka-tourism-in-washington-d-c-usa/	The Embassy of Sri Lanka to the United States, in partnership with the International Club of DC, organized an evening reception on September 30, 2022, in Washington D.C. to showcase Sri Lanka as a tropical island paradise, aiming to promote tourism in the country.	Mission News	2025-09-28 09:13:38.752259
112	19	Sri Lanka participates in UN International Charity Luncheon	07.10.2022	https://mfa.gov.lk/en/sri-lanka-participates-in-un-international-charity-luncheon/	Sri Lanka joined other countries in attending the United Nations International Charity Luncheon hosted by the United Nations Women’s Guild Vienna (UNWG) on September 22, 2022. The event aimed to support charitable causes and promote global cooperation.	Mission News	2025-09-28 09:13:38.752259
114	19	Travellers from Bangladesh keen to visit Sri Lanka	04.10.2022	https://mfa.gov.lk/en/travellers-from-bangladesh-keen-to-visit-sri-lanka/	Travellers from Bangladesh are eager to visit Sri Lanka, as shown by their interest at the 9th Asian Tourism Fair. The High Commission of Sri Lanka in Bangladesh and Sri Lankan Airlines collaborated at the event held from September 29 to October 1, 2022, at the International Convention Center.	Mission News	2025-09-28 09:13:38.752259
115	19	Sri Lankan Embassy in Washington DC Facilitates over USD 12 million in Medical Aid	03.10.2022	https://mfa.gov.lk/en/sri-lankan-embassy-in-washington-dc-facilitates-over-usd-12-million-in-medical-aid/	The Sri Lankan Embassy in Washington DC has facilitated over USD 12 million in medical aid through collaboration with American humanitarian donor organizations. This milestone includes the provision of free medicines and medical supplies, benefiting those in need.	Mission News	2025-09-28 09:13:38.752259
116	19	Permanent Representative of Sri Lanka to the United Nations in New York, Ambassador Mohan Pieris appointed as the Chair of the United Nations First Committee	30.09.2022	https://mfa.gov.lk/en/permanent-representative-of-sri-lanka-to-the-united-nations-in-new-york-ambassador-mohan-pieris-appointed-as-the-chair-of-the-united-nations-first-committee/	Sri Lanka's Ambassador and Permanent Representative to the United Nations in New York, Mohan Pieris, has been appointed as the Chair of the United Nations First Committee, which focuses on disarmament and international security matters.	Mission News	2025-09-28 09:13:38.752259
117	19	Minister of Foreign Affairs Ali Sabry engages with multiple stakeholders at the 77th Session of the United Nations General Assembly in New York	29.09.2022	https://mfa.gov.lk/en/minister-of-foreign-affairs-ali-sabry-engages-with-multiple-stakeholders-at-the-77th-session-of-the-united-nations-general-assembly-in-new-york/	Minister of Foreign Affairs Ali Sabry has returned to the country after engaging with multiple stakeholders at the 77th Session of the United Nations General Assembly in New York. During the General Debate, Minister Sabry addressed key issues and represented the country's interests on the global stage.	Mission News	2025-09-28 09:13:38.752259
118	19	Educational and Cultural Exchange Awareness Programme in Iran	29.09.2022	https://mfa.gov.lk/en/educational-and-cultural-exchange-awareness-programme-in-iran/	The Embassy of Sri Lanka in Iran, in collaboration with the General Sir John Kotelawala Defence University, hosted an educational and cultural exchange awareness programme at the Chancery premises in Tehran on 21 Sep. The event aimed to promote mutual understanding and cooperation between the two countries.	Mission News	2025-09-28 09:13:38.752259
119	19	President Ranil Wickremesinghe attends the State Funeral of   former Japanese Prime Minister Shinzo Abe	29.09.2022	https://mfa.gov.lk/en/president-ranil-wickremesinghe-attends-the-state-funeral-of-former-japanese-prime-minister-shinzo-abe/	President Ranil Wickremesinghe of Sri Lanka visited Japan on September 27-28, 2022, to attend the State Funeral of former Japanese Prime Minister Shinzo Abe.	Mission News	2025-09-28 09:13:38.752259
120	19	​HOPE worldwide makes a generous in-kind donation to Sri Lanka	28.09.2022	https://mfa.gov.lk/en/%e2%80%8bhope-worldwide-makes-a-generous-in-kind-donation-to-sri-lanka/	HOPE worldwide has generously donated in-kind assistance to Sri Lanka in response to a request from the Sri Lankan Embassy in Washington, D.C. The donation was made under the guidance of His Excellency the Ambassador, strengthening ties between the two nations.	Mission News	2025-09-28 09:13:38.752259
121	19	Sri Lanka Ambassador’s Trophy – 2022 Cricket Tournament in Lebanon	28.09.2022	https://mfa.gov.lk/en/sri-lanka-ambassadors-trophy-2022-cricket-tournament-in-lebanon/	The Embassy of Sri Lanka to Lebanon and Syria, in collaboration with the St. Joseph Cricket Club in Achrafieh, organized a six-a-side softball cricket tournament as part of their Community outreach program. The event, known as the Sri Lanka Ambassador’s Trophy, took place in Lebanon in 2022.	Mission News	2025-09-28 09:13:38.752259
122	19	Sri Lanka participates at the IFTM TOP RESA, International and French Travel Market 2022	27.09.2022	https://mfa.gov.lk/en/sri-lanka-participates-at-the-iftm-top-resa-international-and-french-travel-market-2022/	Sri Lanka Association of Inbound Tour Operators (SLAITO) successfully participated in the IFTM TOP RESA, International and French Travel Market 2022 from September 20 to 22, 2022. The event was coordinated by SLAITO, showcasing Sri Lanka's tourism offerings to an international audience.	Mission News	2025-09-28 09:13:38.752259
123	19	Sri Lanka promotes commercial relations with the State of Goiás in Brazil	27.09.2022	https://mfa.gov.lk/en/sri-lanka-promotes-commercial-relations-with-the-state-of-goias-in-brazil/	Sri Lanka's Ambassador to Brazil, Sumith Dassanayake, visited the State of Goiás on September 19, 2022, as part of an initiative to strengthen commercial ties. The visit aimed to promote trade and economic relations between Sri Lanka and Goiás, Brazil.	Mission News	2025-09-28 09:13:38.752259
124	19	“Celebration of Ceylon Spices”: an event to promote Ceylon Spices in Washington D.C., USA	27.09.2022	https://mfa.gov.lk/en/celebration-of-ceylon-spices-an-event-to-promote-ceylon-spices-in-washington-d-c-usa/	The Embassy of Sri Lanka in the United States, along with the American Spice Trade Association (ASTA), organized the "Celebration of Ceylon Spices" event in Washington D.C. on September 13, 2022. The event aimed to promote Ceylon Spices and featured a vibrant evening reception at the Embassy premises.	Mission News	2025-09-28 09:13:38.752259
125	19	Sri Lanka donates Ceylon Tea to the flood victims in Pakistan	27.09.2022	https://mfa.gov.lk/en/sri-lanka-donates-ceylon-tea-to-the-flood-victims-in-pakistan/	Sri Lanka's Government donated Ceylon Tea to flood victims in Pakistan at a ceremony on September 21, 2022, at Jinnah International Airport. The Sri Lanka Tea Board collaborated on the donation, providing support to those affected by the floods.	Mission News	2025-09-28 09:13:38.752259
126	19	Sri Lankan design techniques get exposure in Jordan	23.09.2022	https://mfa.gov.lk/en/sri-lankan-design-techniques-get-exposure-in-jordan/	The Embassy of Sri Lanka in Jordan collaborated with the Academy of Design (AOD) to host a virtual workshop, highlighting innovative design and marketing techniques from the Academy. The workshop aimed to showcase Sri Lankan design expertise to a Jordanian audience, fostering cultural exchange and knowledge sharing.	Mission News	2025-09-28 09:13:38.752259
127	19	Sri Lankan companies make successful contacts with Maldivian firms at the inaugural ITE Maldives 2022	23.09.2022	https://mfa.gov.lk/en/sri-lankan-companies-make-successful-contacts-with-maldivian-firms-at-the-inaugural-ite-maldives-2022/	Sri Lankan companies achieved successful business connections with Maldivian firms at the inaugural ITE Maldives 2022. The event served as a productive Business-to-Business meeting platform in Male, facilitating valuable interactions between participants.	Mission News	2025-09-28 09:13:38.752259
170	19	Jordan donates essential medicines to Sri Lanka	25.07.2022	https://mfa.gov.lk/en/jordan-donates-essential-medicines-to-sri-lanka/	The Embassy of Sri Lanka in Jordan facilitated a donation of essential medicines to Sri Lanka following a request from the Ministry of Health. The consignment was successfully sent on 19 July, supporting Sri Lanka's healthcare efforts.	Mission News	2025-09-28 09:13:38.752259
128	19	High Commissioner Milinda Moragoda interacts with Indian Women’s Press Corps and IAAN School of Mass Communication	22.09.2022	https://mfa.gov.lk/en/high-commissioner-milinda-moragoda-interacts-with-indian-womens-press-corps-and-iaan-school-of-mass-communication/	Sri Lankan High Commissioner to India, Milinda Moragoda, engaged with the Indian Women’s Press Corps (IWPC) and students from the IAAN School of Mass Communication on September 19. The interactions aimed to foster dialogue and collaboration between the parties.	Mission News	2025-09-28 09:13:38.752259
129	19	President Ranil Wickremesinghe attends the State Funeral Service of Her Majesty Queen Elizabeth II	21.09.2022	https://mfa.gov.lk/en/president-ranil-wickremesinghe-attends-the-state-funeral-service-of-her-majesty-queen-elizabeth-ii/	President Ranil Wickremesinghe visited the United Kingdom from 17-20 September 2022 to attend the State Funeral Service of the late Queen Elizabeth II. On Sunday, 18 September, the President accompanied the dignitaries at the funeral service.	Mission News	2025-09-28 09:13:38.752259
130	19	High Commissioner Moragoda interacts with a second group of African  envoys concurrently accredited to Sri Lanka	21.09.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-interacts-with-a-second-group-of-african-envoys-concurrently-accredited-to-sri-lanka/	High Commissioner of Sri Lanka to India, Milinda Moragoda, engaged with a second group of African envoys concurrently accredited to Sri Lanka, as part of ongoing diplomatic engagements with missions from New Delhi.	Mission News	2025-09-28 09:13:38.752259
131	19	Another Donation of Medicines from the U.S.  Americares Donates more than $773,000 USD worth of Urgently Needed Medicines and Medical Supplies to Sri Lanka	20.09.2022	https://mfa.gov.lk/en/another-donation-of-medicines-u-s-americares/	Americares has donated over $773,000 USD worth of urgently needed medicines and medical supplies to Sri Lanka in response to a request from the Embassy of Sri Lanka in Washington D.C. The donation aims to support the country's healthcare system during this critical time.	Mission News	2025-09-28 09:13:38.752259
132	19	High Commission of Sri Lanka in New Delhi opens a High Commissioners’ Gallery	16.09.2022	https://mfa.gov.lk/en/high-commission-of-sri-lanka-in-new-delhi-opens-a-high-commissioners-gallery/	The High Commission of Sri Lanka in New Delhi inaugurated a 'High Commissioners’ Gallery' today, dedicated to all the High Commissioners of Sri Lanka to India. This gallery is located in the chancery building and aims to showcase the contributions of the High Commissioners.	Mission News	2025-09-28 09:13:38.752259
133	19	Sri Lanka joins hands with Bangladesh to boost the electronic and  electrical industry	16.09.2022	https://mfa.gov.lk/en/sri-lanka-joins-hands-with-bangladesh-to-boost-the-electronic-and-electrical-industry/	Sri Lanka has partnered with Bangladesh to enhance the electronic and electrical industry. The High Commission of Sri Lanka in Bangladesh, along with the Sri Lanka Export Development Board (SLEDB) and the Federation of Bangladesh Chamber of Commerce and Industry (FBCCI), organized a virtual B2B session to facilitate this collaboration. This initiative aims to boost trade and cooperation between the two countries in the mentioned industry.	Mission News	2025-09-28 09:13:38.752259
134	19	The Sri Lanka Consulate General in Karachi and the Pakistan Sri Lanka Business Forum jointly organized live screening of Asia Cup final cricket match in Karachi	16.09.2022	https://mfa.gov.lk/en/sri-lanka-consulate-general-in-karachi-and-the-pakistan-sri-lanka-business-forum-jointly-organized-live-screening-of-asia-cup-final-cricket-match-in-karachi/	The Sri Lanka Consulate General in Karachi and the Pakistan Sri Lanka Business Forum collaborated to host a live screening of the Asia Cup final cricket match on September 11, 2022, at the Sri Lanka Consulate General in Karachi. Cricket enthusiasts gathered to watch the exciting match together in a shared viewing experience.	Mission News	2025-09-28 09:13:38.752259
135	19	Donation  of USD 10,000 to Sri Lanka by Sitagu Sayadaw Most. Ven. Dr. Ashin Nyanissara,   The Vice Sangha Raja of Myanmar	15.09.2022	https://mfa.gov.lk/en/donation-of-usd-10000-to-sri-lanka-by-sitagu-sayadaw-most-ven-dr-ashin-nyanissara-the-vice-sangha-raja-of-myanmar/	The Vice Sangha Raja of Myanmar, Sitagu Sayadaw Most Ven. Dr. Ashin Nyanissara, donated USD 10,000 (approximately Sri Lankan Rupees 3,679,200) to the Government of Sri Lanka for purchasing essentials.	Mission News	2025-09-28 09:13:38.752259
136	19	Sri Lanka Embassy in Doha holds “Explore Sri Lanka”- Qatar MENASA 2022, Years of Culture festival	14.09.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-doha-holds-explore-sri-lanka-qatar-menasa-2022-years-of-culture-festival/	The Sri Lanka Embassy in Doha hosted the "Explore Sri Lanka" Cultural Festival as part of Qatar MENASA 2022, Years of Culture on September 9-10, 2022, at Education City in Doha, Qatar. The event showcased Sri Lankan culture and heritage to promote cultural exchange between the two countries.	Mission News	2025-09-28 09:13:38.752259
137	19	Sri Lankans in Zambia Donate Rabies Vaccines to Sri Lanka	12.09.2022	https://mfa.gov.lk/en/sri-lankans-in-zambia-donate-rabies-vaccines-to-sri-lanka/	Sri Lankans residing in Zambia, through the Zambia Sri Lanka Friendship Association, donated 1150 Rabies Vaccines to Sri Lanka's Ministry of Health. The donation was facilitated by the Honorary Consul of Sri Lanka. This act of generosity aims to support rabies prevention efforts in Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
138	19	Sri Lanka Participates in the World Food Istanbul Trade Fair	07.09.2022	https://mfa.gov.lk/en/sri-lanka-participates-in-the-world-food-istanbul-trade-fair/	Sri Lanka participated in the World Food Istanbul Trade Fair from September 1 to 4, 2022, showcasing Pure Ceylon tea. The Sri Lankan stand attracted a large number of visitors, with five companies representing the country.	Mission News	2025-09-28 09:13:38.752259
139	19	The Government of Myanmar donates 1000 metric tonnes of  Rice to Sri Lanka	06.09.2022	https://mfa.gov.lk/en/the-government-of-myanmar-donates-1000-metric-tonnes-of-rice-to-sri-lanka/	The Government of Myanmar donated 1000 metric tonnes of Myanmar White Rice, valued at Sri Lankan Rupees 170 million (approximately USD 463,215), to Sri Lanka on 2 September 2022. The donation was officially made to the Government of Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
140	19	Sri Lanka promotes MICE tourism for potential stakeholders in Dhaka	06.09.2022	https://mfa.gov.lk/en/sri-lanka-promotes-mice-tourism-for-potential-stakeholders-in-dhaka/	Sri Lanka, in collaboration with the Sri Lanka Convention Bureau and SriLankan Airlines, organized a MICE Promotion Evening at the High Commission premises in Dhaka on 1 September. The event aimed to promote MICE tourism to potential stakeholders in Dhaka, facilitated by the High Commission of Sri Lanka in Bangladesh.	Mission News	2025-09-28 09:13:38.752259
141	19	Sri Lanka participates in Indonesia’s biggest exhibition of the Islamic & Halal Industry	05.09.2022	https://mfa.gov.lk/en/sri-lanka-participates-in-indonesias-biggest-exhibition-of-the-islamic-halal-industry/	Sri Lanka participated in Indonesia's largest exhibition of the Islamic and Halal Industry, with three companies showcasing their products and services at a stall organized by the Sri Lankan Embassy in Jakarta. The companies included PT Expo Freight-EFL, PT Advantis Akaza, and Hayleys Aventura (Pvt) Ltd.	Mission News	2025-09-28 09:13:38.752259
142	19	High Commissioner Moragoda participates in ‘Idea Exchange’ programme of the Indian Express	02.09.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-participates-in-idea-exchange-programme-of-the-indian-express/	Sri Lanka's High Commissioner to India, Milinda Moragoda, participated in the 'Idea Exchange' programme hosted by The Indian Express newspaper on September 1, 2022, at the newspaper's headquarters in Noida. The event provided a platform for exchanging ideas and fostering dialogue between the two countries.	Mission News	2025-09-28 09:13:38.752259
143	19	Book on “Sri Lanka – Oman Relations” launched	02.09.2022	https://mfa.gov.lk/en/book-on-sri-lanka-oman-relations-launched/	A book titled "Sri Lanka – Oman Relations; Past, Present and Future" authored by O. L. Ameer Ajwad, Sri Lankan Ambassador to Oman, was launched at the Diplomatic Institute of the Foreign Ministry. The book explores the historical and future aspects of the relationship between Sri Lanka and Oman.	Mission News	2025-09-28 09:13:38.752259
144	19	Sri Lanka National Pavilion on Douyin (TikTok) to promote Sri Lanka Products in China attracts over One Million Viewers	02.09.2022	https://mfa.gov.lk/en/sri-lanka-national-pavilion-on-douyin-tiktok-to-promote-sri-lanka-products-in-china-attracts-over-one-million-viewers/	The Sri Lanka Embassy in Beijing, along with the China-Sri Lanka Association for Trade and Economic Cooperation, launched the Sri Lanka National Pavilion on Douyin (TikTok) to promote Sri Lankan products in China. The pavilion has attracted over one million viewers since its launch on August 30.	Mission News	2025-09-28 09:13:38.752259
145	19	Speaker unveils a portrait of Sir D.B. Jayatilaka at the  High Commission of Sri Lanka in New Delhi	01.09.2022	https://mfa.gov.lk/en/speaker-unveils-a-portrait-of-sir-d-b-jayatilaka-at-the-high-commission-of-sri-lanka-in-new-delhi/	The Speaker of the Sri Lanka Parliament, Mahinda Yapa Abeywardena, unveiled a portrait of Sir D.B. Jayatilaka, Sri Lanka's first representative to India, at the High Commission of Sri Lanka in New Delhi on the 28th. The event marked a significant tribute to Sir D.B. Jayatilaka's historical role in Sri Lanka-India relations.	Mission News	2025-09-28 09:13:38.752259
146	19	Ambassador Dr.Palitha Kohona Highlights the Imperative of Feeding 8 Billion Humans While Protecting the Quality of Food We Consume and the Environment	31.08.2022	https://mfa.gov.lk/en/ambassador-dr-palitha-kohona-highlights-the-imperative-of-feeding-8-billion-humans-while-protecting-the-quality-of-food-we-consume-and-the-environment/	Ambassador Dr. Palitha Kohona emphasized at the Jilin Green Agriculture Forum the importance of addressing the environmental impact of industrial agricultural practices while ensuring food quality for the world's 8 billion population. He urged policymakers to prioritize sustainable practices to protect both the environment and the quality of food consumed.	Mission News	2025-09-28 09:13:38.752259
147	19	Heart to Heart International United States donates USD 8 Million worth of urgent medicines to the people of Sri Lanka	30.08.2022	https://mfa.gov.lk/en/heart-to-heart-us-donates/	Heart to Heart International United States has donated USD 8 million worth of urgent medicines to the people of Sri Lanka. The donation was announced in a joint press release by the Embassy of Sri Lanka in Washington D.C. and Heart to Heart International, a well-known global humanitarian organization. This significant contribution aims to provide essential medical support to the people in need.	Mission News	2025-09-28 09:13:38.752259
148	19	The Honorary Consulate of Sri Lanka in Gaziantep officially opens	29.08.2022	https://mfa.gov.lk/en/the-honorary-consulate-of-sri-lanka-in-gaziantep-officially-opens/	The Honorary Consulate of Sri Lanka in Gaziantep, Turkey officially opened on 22 August 2022. The opening ceremony was attended by Ambassador M. Rizvi Hassen, Gaziantep-based parliamentarians, and government officials.	Mission News	2025-09-28 09:13:38.752259
149	19	Promoting Sri Lanka tourism in Tamil Nadu	29.08.2022	https://mfa.gov.lk/en/promoting-sri-lanka-tourism-in-tamil-nadu/	Deputy High Commissioner of Sri Lanka in Chennai, Dr. D. Venkateshwaran, met with Tourism Minister of Tamil Nadu, Dr. M. A. Mathiventhan, on August 19, 2022, to discuss strategies for boosting tourism between Sri Lanka and Tamil Nadu.	Mission News	2025-09-28 09:13:38.752259
150	19	Ambassador Dr.Palitha Kohona calls for the revival of  Global Tourism	25.08.2022	https://mfa.gov.lk/en/ambassador-dr-palitha-kohona-calls-for-the-revival-of-global-tourism/	Ambassador Dr. Palitha Kohona advocated for the revival of global tourism at the sixth summit of the Asian Mountain Tourism Alliance in Guiyang, Guizhou, China on 17-18 August 2022. The summit highlighted various products, particularly handicrafts from the province, and attracted high-level attendees.	Mission News	2025-09-28 09:13:38.752259
151	19	Sri Lankan apparel exporters successfully participate in world’s largest fashion market place – Magic Las Vegas, USA	24.08.2022	https://mfa.gov.lk/en/sri-lankan-apparel-exporters-successfully-participate-in-worlds-largest-fashion-market-place-magic-las-vegas-usa/	Nine Sri Lankan apparel exporting companies successfully participated in the apparel sourcing trade fair, 'Magic Las Vegas,' held at the Convention Center of Las Vegas, USA from 7 - 10 August 2022. The companies showcased their products at the world's largest fashion marketplace, enhancing their global presence and networking opportunities.	Mission News	2025-09-28 09:13:38.752259
152	19	High Commissioner Moragoda interacts with African envoys concurrently accredited to Sri Lanka	24.08.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-interacts-with-african-envoys-concurrently-accredited-to-sri-lanka/	High Commissioner of Sri Lanka to India, Milinda Moragoda, engaged with a group of African Heads of Missions concurrently accredited to Sri Lanka, as part of ongoing interactions with Diplomatic Missions from New Delhi. The meeting aimed to strengthen ties between Sri Lanka and African countries.	Mission News	2025-09-28 09:13:38.752259
153	19	Two Sri Lankan origin Canadians among Top 25 Canadian Immigrants of 2022	22.08.2022	https://mfa.gov.lk/en/two-sri-lankan-origin-canadians-among-top-25-canadian-immigrants-of-2022/	Two Sri Lankan origin Canadians were named among the Top 25 Canadian Immigrants of 2022. The High Commissioner of Sri Lanka to Canada attended the Annual Award Ceremony of the Canadian Immigrant Magazine in Toronto on August 11, 2022.	Mission News	2025-09-28 09:13:38.752259
154	19	Turkiye Donates Emergency Medicine and Medical Supplies to the Government of Sri Lanka	22.08.2022	https://mfa.gov.lk/en/turkiye-donates-emergency-medicine-and-medical-supplies-to-the-government-of-sri-lanka/	Turkey has donated emergency medicines and medical supplies worth USD one million to the Government of Sri Lanka. The donation includes urgently needed items for hospitals, with the first consignment containing Filgasstrin injections.	Mission News	2025-09-28 09:13:38.752259
155	19	The Government of Austria donates a consignment of essential medicines to Sri Lanka	19.08.2022	https://mfa.gov.lk/en/the-government-of-austria-donates-a-consignment-of-essential-medicines-to-sri-lanka/	The Government of Austria donated essential medicines worth four million Sri Lankan Rupees to Sri Lanka on August 16, 2022. The consignment included 27 essential medicines urgently needed by the country. This donation aims to support Sri Lanka's healthcare system during challenging times.	Mission News	2025-09-28 09:13:38.752259
156	19	Sri Lankan Embassy in Jordan Conducts Awareness Session on  Remittances for Migrant Workers	16.08.2022	https://mfa.gov.lk/en/sri-lankan-embassy-in-jordan-conducts-awareness-session-on-remittances-for-migrant-workers/	The Sri Lankan Embassy in Jordan conducted an awareness session on remittances for migrant workers to boost inflows to Sri Lanka. The session, held via Zoom technology on August 12, 2022, featured an interactive discussion with the Peoples Bank of Sri Lanka. This initiative aimed to provide valuable information and support to Sri Lankan migrants regarding remittance processes.	Mission News	2025-09-28 09:13:38.752259
157	19	Consulate General of Sri Lanka in Mumbai Celebrates Raksha Bandhan with the Sisters from Brahma Kumaris	16.08.2022	https://mfa.gov.lk/en/consulate-general-of-sri-lanka-in-mumbai-celebrates-raksha-bandhan-with-the-sisters-from-brahma-kumaris/	The Consulate General of Sri Lanka in Mumbai celebrated Raksha Bandhan with the Brahma Kumaris sisters on August 8, 2022, as part of the Mission’s Cultural Exchange Programme. The event aimed to foster cultural ties and promote harmony between the two communities.	Mission News	2025-09-28 09:13:38.752259
158	19	The Ambassador of Sri Lanka to Lebanon calls on the Head of Mission and Force Commander of UNIFIL and visits the Sri Lankan Peace Keeping troops	12.08.2022	https://mfa.gov.lk/en/the-ambassador-of-sri-lanka-to-lebanon-calls-on-the-head-of-mission-and-force-commander-of-unifil-and-visits-the-sri-lankan-peace-keeping-troops/	The Ambassador of Sri Lanka to Lebanon, Shani Calyaneratne Karunaratne, along with Counselor Srimal Kahathuduwa, visited the United Nations Interim Force in Lebanon (UNIFIL). During the visit, they met with the Head of Mission and Force Commander Ma, and also visited the Sri Lankan Peacekeeping troops stationed in the region.	Mission News	2025-09-28 09:13:38.752259
159	19	​Informative Webinar on opportunities in the Israeli Market	09.08.2022	https://mfa.gov.lk/en/%e2%80%8binformative-webinar-on-opportunities-in-the-israeli-market/	The Embassy of Sri Lanka in Tel Aviv and the Sri Lanka Export Development Board (SLEDB) collaborated with the Federation of Israeli Chambers of Commerce to host an informative webinar on opportunities in the Israeli market on August 3, 2022. The webinar aimed to provide valuable insights for businesses looking to explore the Israeli market.	Mission News	2025-09-28 09:13:38.752259
160	19	Sri Lanka organizes its first ever ‘Murugan Trail’ tour from South India	09.08.2022	https://mfa.gov.lk/en/sri-lanka-organizes-its-first-ever-murugan-trail-tour-from-south-india/	Sri Lanka Deputy High Commission in Chennai, in collaboration with Sri Lanka Tourism Promo, organized the first-ever 'Murugan Trail' tour for South Indian media groups. The program aims to promote tourism in Sri Lanka and showcase the cultural significance of the trail.	Mission News	2025-09-28 09:13:38.752259
161	19	Ceremony to Hand over the Sacred Relics from Sri Lanka to  Laos Temple in France	09.08.2022	https://mfa.gov.lk/en/ceremony-to-hand-over-the-sacred-relics-from-sri-lanka-to-laos-temple-in-france/	Buddhist relics from Sri Lanka's Chief Incumbent of Mihinthale Rajamaha Viharaya, Ven. Dhammarathana Nayaka Thero, were handed over to the Veluvanarama Buddhist temple of Laos at Boussy Saint Georges in France during a ceremony.	Mission News	2025-09-28 09:13:38.752259
162	19	High Commissioner Milinda Moragoda meets Tamil Nadu  Parliamentarian Kanimozhi Karunanidhi	08.08.2022	https://mfa.gov.lk/en/high-commissioner-milinda-moragoda-meets-tamil-nadu-parliamentarian-kanimozhi-karunanidhi/	Sri Lanka's High Commissioner to India, Milinda Moragoda, met with Tamil Nadu Parliamentarian Kanimozhi Karunanidhi to strengthen engagement with the state, following a previous meeting with its Chief Minister in early June. This meeting signifies ongoing efforts to enhance relations between Sri Lanka and Tamil Nadu.	Mission News	2025-09-28 09:13:38.752259
163	19	Chinese students to follow the Master of Finance in Economics (MFE) of the University of Colombo soon	08.08.2022	https://mfa.gov.lk/en/chinese-students-to-follow-the-master-of-finance-in-economics-mfe-of-the-university-of-colombo-soon/	The Sri Lanka Embassy hosted a commencement ceremony for Chinese students who will soon begin the Master of Financial Economics Programme (MFE) at the University of Colombo in 2022. The event took place on July 29, 2022, marking the start of this academic endeavor for the students.	Mission News	2025-09-28 09:13:38.752259
164	19	Consular and Labour Mobile Service in Thilafushi Island in Maldives	03.08.2022	https://mfa.gov.lk/en/consular-and-labour-mobile-service-in-thilafushi-island-in-maldives/	The High Commission of Sri Lanka in Maldives conducted a mobile consular and labour service on Thilafushi Island on July 29, 2022. This was the second mobile service organized by the Mission. The initiative aimed to provide assistance to Sri Lankan citizens residing on the island.	Mission News	2025-09-28 09:13:38.752259
165	19	Dhaka Chamber of Commerce and Industry ready to boost cooperation with Sri Lanka’s National Chamber of Exporters	29.07.2022	https://mfa.gov.lk/en/dhaka-chamber-of-commerce-and-industry-ready-to-boost-cooperation-with-sri-lankas-national-chamber-of-exporters/	The High Commission of Sri Lanka in Dhaka recently hosted a webinar on July 27, 2022, bringing together the National Chamber of Exporters (NCE) from Sri Lanka and the Dhaka Chamber of Commerce and Industry (DCCI). The event aimed to enhance cooperation between the two chambers for mutual benefit and economic growth.	Mission News	2025-09-28 09:13:38.752259
166	19	Toronto Sri Varasiththi Vinaayagar Hindu Temple Annual Chariot Festival	28.07.2022	https://mfa.gov.lk/en/toronto-sri-varasiththi-vinaayagar-hindu-temple-annual-chariot-festival/	The Sri Lanka Consulate General in Toronto participated in the Annual Chariot Festival of the Sri Varasiththi Vinaayagar Hindu Temple on July 23, 2022, following an invitation from the Chief Priest and the Board of Trust. The event brought together community members to celebrate and honor the festival traditions.	Mission News	2025-09-28 09:13:38.752259
167	19	Sri Lanka shines at Bedford River Festival 2022	27.07.2022	https://mfa.gov.lk/en/sri-lanka-shines-at-bedford-river-festival-2022/	Sri Lanka showcased its culture and tourism at the Bedford River Festival 2022 through a collaboration between the High Commission of Sri Lanka in London, the Sri Lanka Tourist Promotion Bureau, and other organizations. The event featured the participation of various Sri Lankan entities, including the Sri Lanka Tea Board and the National Craft Council, to promote the country's offerings to attendees.	Mission News	2025-09-28 09:13:38.752259
168	19	Sri Lankan Batiks Promotion in Antalya, Turkey	27.07.2022	https://mfa.gov.lk/en/sri-lankan-batiks-promotion-in-antalya-turkey/	The Embassy of Sri Lanka in Turkey, with the assistance of the Honorary Consul of Sri Lanka to Antalya Ali Kamburoglu, organized the second leg of the Sri Lankan Batiks promotional event on July 20, 2022. The event aimed to showcase and promote Sri Lankan Batiks in Antalya, Turkey.	Mission News	2025-09-28 09:13:38.752259
169	19	High Commissioner Moragoda visits Amul Headquarters in Gujarat; discusses ways and means to enhance dairy sector cooperation	26.07.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-visits-amul-headquarters-in-gujarat-discusses-ways-and-means-to-enhance-dairy-sector-cooperation/	High Commissioner Moragoda visited Amul Headquarters in Gujarat to discuss enhancing dairy sector cooperation. Sri Lanka aims to develop its dairy industry with India's cooperation, as discussed during the official delegation's visit led by the High Commissioner.	Mission News	2025-09-28 09:13:38.752259
171	19	High Commissioner Moragoda interacts with Latin American and Caribbean envoys concurrently accredited to Sri Lanka	21.07.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-interacts-with-latin-american-and-caribbean-envoys-concurrently-accredited-to-sri-lanka/	High Commissioner of Sri Lanka to India, Milinda Moragoda, engaged with Latin American and Caribbean envoys concurrently accredited to Sri Lanka as part of a series of diplomatic engagements. The interactions aimed to strengthen ties between Sri Lanka and these regions.	Mission News	2025-09-28 09:13:38.752259
172	19	Conference on Globally Important Agricultural Heritage Systems, Qintian, Zhejiang	21.07.2022	https://mfa.gov.lk/en/conference-on-globally-important-agricultural-heritage-systems-qintian-zhejiang/	The Conference on Globally Important Agricultural Heritage Systems took place in Qintian, Zhejiang, China on July 18, 2022. The hybrid-mode conference attracted a diverse group of high-level speakers.	Mission News	2025-09-28 09:13:38.752259
173	19	Sri Lankans commemorate Esala Poya in Jordan	21.07.2022	https://mfa.gov.lk/en/sri-lankans-commemorate-esala-poya-in-jordan/	The Sri Lankan Embassy in Jordan celebrated Esala Poya with the local Buddhist community on July 15, 2022, at the Chancery premises. The day-long event concluded with a Dansala organized by the Embassy Staff, bringing the community together in commemoration.	Mission News	2025-09-28 09:13:38.752259
174	19	Technical Level Meeting on Opportunities in the Mozambique Sustainable Energy Sector Concluded	21.07.2022	https://mfa.gov.lk/en/technical-level-meeting-on-opportunities-in-the-mozambique-sustainable-energy-sector-concluded/	The Technical Level Meeting on Opportunities in the Mozambique Sustainable Energy Sector, organized by the Sri Lanka High Commission in Pretoria, South Africa, in collaboration with the Sri Lanka Export Development Board (EDB) and the Mozambique Chamber of Commerce, has concluded successfully.	Mission News	2025-09-28 09:13:38.752259
175	19	Sri Lanka presents its second Voluntary National Review on the achievement of the Sustainable Development Goals (SDGs)	19.07.2022	https://mfa.gov.lk/en/sri-lanka-presents-its-second-voluntary-national-review-on-the-achievement-of-the-sustainable-development-goals-sdgs/	Sri Lanka presented its second Voluntary National Review (VNR) on the achievement of the Sustainable Development Goals (SDGs) at the High Level Political Forum (HLPF) today. The review was convened under the auspices of the United Nations.	Mission News	2025-09-28 09:13:38.752259
176	19	Sri Lanka Deputy High Commission in Chennai organizes a medical camp for Sri Lankans in Tamil Nadu for the first time	19.07.2022	https://mfa.gov.lk/en/sri-lanka-deputy-high-commission-in-chennai-organizes-a-medical-camp-for-sri-lankans-in-tamil-nadu-for-the-first-time/	The Sri Lanka Deputy High Commission in Chennai organized a medical camp for Sri Lankans in Tamil Nadu for the first time. The camp took place at the Chancery premises on 28 June 2022, providing essential healthcare services to the community.	Mission News	2025-09-28 09:13:38.752259
177	19	URGENT MEDICINAL SUPPLIES FROM THE UNITED STATES  TO THE PEOPLE OF SRI LANKA	19.07.2022	https://mfa.gov.lk/en/urgent-medicinal-supplies-from-the-united-states-to-the-people-of-sri-lanka/	The Embassy of Sri Lanka in Washington D.C. and Heart to Heart International in the United States are collaborating to provide urgent medicinal supplies to the people of Sri Lanka. This initiative follows a request from the Sri Lankan Embassy and is being carried out under the guidance of His Excellency.	Mission News	2025-09-28 09:13:38.752259
178	19	Thalassemia Foundation and Siam Bioscience Group of Thailand donates  Triple 5000 blood bags and Filgrastim 750 Bottles to Sri Lanka	13.07.2022	https://mfa.gov.lk/en/thalassemia-foundation-and-siam-bioscience-group-of-thailand-donates-triple-5000-blood-bags-and-filgrastim-750-bottles-to-sri-lanka/	Thalassemia Foundation and Siam Bioscience Group of Thailand donated Triple 5000 blood bags and Filgrastim 750 Bottles to Sri Lanka. Professor Vip Viprakasit, the Director of Thalassemia Research Programme, handed over the donation as a contribution to the country's healthcare system.	Mission News	2025-09-28 09:13:38.752259
179	19	Sri Lankan Handloom fabrics showcased in Jordan	11.07.2022	https://mfa.gov.lk/en/sri-lankan-handloom-fabrics-showcased-in-jordan/	Sri Lankan handloom fabrics were showcased in Jordan by the Embassy of Sri Lanka to raise awareness among Jordanian fabric importers about the export quality of traditional handloom fabrics from Sri Lanka. The event aimed to promote these fabrics manufactured in Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
180	19	Beauty of Sri Lankan Batiks admired in Ankara	11.07.2022	https://mfa.gov.lk/en/beauty-of-sri-lankan-batiks-admired-in-ankara/	Sri Lanka's Ambassador in Turkey, M.R. Hassen, recently hosted an event at the Ambassador's residence in Ankara to showcase the beauty of Sri Lankan Batiks. The event, titled "Discover the Beauty of Sri Lankan Batiks," treated guests to a fashion show highlighting the intricate designs of these traditional textiles.	Mission News	2025-09-28 09:13:38.752259
181	19	Sri Lanka’s Popular Brand “Hemas” is set to enter Omani Market	08.07.2022	https://mfa.gov.lk/en/sri-lankas-popular-brand-hemas-is-set-to-enter-omani-market/	Sri Lanka's leading public company, Hemas Holding PLC, is preparing to enter the Omani market. The Ambassador of Sri Lanka to Oman, Ameer Ajwad, is collaborating with Hemas' Senior Manager for International Expansion on this venture.	Mission News	2025-09-28 09:13:38.752259
182	19	Fostering cooperation in shared advocacies and aspirations:  Sister Club Agreement and Collaboration on IT Education Scholarships Project between the Rotary Club of Colombo-Reconnections and the Rotary Club of Makati-Circle of Friends	08.07.2022	https://mfa.gov.lk/en/fostering-cooperation-in-shared-advocacies-and-aspirations-sister-club-agreement-and-collaboration-on-it-education-scholarships-project-between-the-rotary-club-of-colombo-reconnections-and-the/	The Embassy of Sri Lanka in Manila facilitated the virtual signing of a sister club agreement between the Rotary Club of Colombo-Reconnections (RCCR) and the Rotary Club of Makati Circle of Friends (RCM-CoF) on June 29. The agreement aims to foster cooperation in shared advocacies and aspirations, particularly focusing on the IT Education Scholarships Project.	Mission News	2025-09-28 09:13:38.752259
183	19	Deputy High Commissioner of Sri Lanka in Chennai meets Chief Minister and the Governor of Kerala	08.07.2022	https://mfa.gov.lk/en/deputy-high-commissioner-of-sri-lanka-in-chennai-meets-chief-minister-and-the-governor-of-kerala/	Deputy High Commissioner of Sri Lanka in Chennai, Dr. D. Venkateshwaran, met with Chief Minister Pinarayi Vijayan and Governor Arif Mohammad Khan of Kerala on June 30, 2022, in Thiruvananthapuram. The meetings aimed to discuss bilateral relations and cooperation between Sri Lanka and Kerala.	Mission News	2025-09-28 09:13:38.752259
184	19	New Honorary Consul of Sri Lanka in Salzburg appointed	08.07.2022	https://mfa.gov.lk/en/new-honorary-consul-of-sri-lanka-in-salzburg-appointed/	Ambassador Majintha Jayesinghe appointed Christian Winzer as the new Honorary Consul of Sri Lanka in Salzburg, Austria. Winzer is now responsible for representing Sri Lanka's interests in Salzburg.	Mission News	2025-09-28 09:13:38.752259
185	19	“Hands for Sri Lanka” under the All Nepal Bhikkhu Association donates essential medicines to Sri Lanka	07.07.2022	https://mfa.gov.lk/en/hands-for-sri-lanka-under-the-all-nepal-bhikkhu-association-donates-essential-medicines-to-sri-lanka/	The All Nepal Bhikkhu Association (ANBA) and the "Hands for Sri Lanka" committee donated essential medicines worth over Nepal Rupees 25 lakhs to the Embassy of Sri Lanka. The donation was a gesture of support and solidarity towards Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
186	19	Sri Lankan Food Product Companies Participate in the SAITEX Trade Show  2022 South Africa	06.07.2022	https://mfa.gov.lk/en/sri-lankan-food-product-companies-participate-in-the-saitex-trade-show-2022-south-africa/	Two prominent Sri Lankan food product companies took part in the SAITEX Trade Show 2022 in South Africa, held at the Gallagher Convention Centre in Johannesburg from 19 to 21 June 2022. SAITEX is a multi-sector trade show that provides a platform for companies to showcase their products and explore business opportunities.	Mission News	2025-09-28 09:13:38.752259
187	19	The Kuwait Humanitarian & Friendship Society donates USD 10,000 worth medical items	06.07.2022	https://mfa.gov.lk/en/the-kuwait-humanitarian-friendship-society-donates-usd-10000-worth-medical-items/	The Kuwait Humanitarian & Friendship Society donated medical items worth USD 10,000 to Sri Lanka, as requested by the Embassy of Sri Lanka in Kuwait. The donation aims to assist the Sri Lankan Government in maintaining essential medical supplies.	Mission News	2025-09-28 09:13:38.752259
188	19	Promotional Event on “Golden Paradise Visa Scheme and Other Visa Facilities in Sri Lanka”, held in Tehran	06.07.2022	https://mfa.gov.lk/en/promotional-event-on-golden-paradise-visa-scheme-and-other-visa-facilities-in-sri-lanka-held-in-tehran/	The Sri Lanka Embassy in Tehran, in partnership with the Department of Immigration and Emigration in Sri Lanka, hosted a promotional event on the "Golden Paradise Visa Scheme and Other Visa Facilities in Sri Lanka." The event aimed to showcase and promote these visa programs to interested individuals in Tehran.	Mission News	2025-09-28 09:13:38.752259
189	19	Promotion of Sri Lanka tourism in Indonesia	04.07.2022	https://mfa.gov.lk/en/promotion-of-sri-lanka-tourism-in-indonesia/	The Embassy of Sri Lanka in Indonesia, in partnership with the Sri Lanka Tourism Promotion Bureau, held a tourism promotion event on June 24-25, 2022, at the Bundaran HI MRT Station in Jakarta. The event aimed to showcase Sri Lanka's tourist attractions to the Indonesian audience, boosting tourism between the two countries.	Mission News	2025-09-28 09:13:38.752259
190	19	Sri Lanka Embassy in Japan conducts a successful Mobile Consular Service in Osaka	04.07.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-japan-conducts-a-successful-mobile-consular-service-in-osaka/	The Sri Lanka Embassy in Tokyo successfully conducted a Mobile Consular Service at the Umeda Sky Building in Osaka on Saturday, benefiting over 50 Sri Lankan expatriates. The service provided essential facilities to the expatriates, enhancing their access to consular assistance and support.	Mission News	2025-09-28 09:13:38.752259
191	19	The Embassy of Sri Lanka in Brasilia participates at the INNOVA Summit 2022	04.07.2022	https://mfa.gov.lk/en/the-embassy-of-sri-lanka-in-brasilia-participates-at-the-innova-summit-2022/	The Embassy of Sri Lanka in Brasilia participated in the INNOVA Summit 2022 at the Convention Centre in Brasilia from June 21 to 23, 2022. The INNOVA Summit is a significant Trade and Industrial Promotional event.	Mission News	2025-09-28 09:13:38.752259
192	19	Ceylon Tea Seminar at the Embassy of Sri Lanka in Tokyo	04.07.2022	https://mfa.gov.lk/en/ceylon-tea-seminar-at-the-embassy-of-sri-lanka-in-tokyo/	The Embassy of Sri Lanka in Japan hosted a Ceylon Tea Seminar organized by the Japan Tea Association on June 25, 2022, with over 35 Japanese tea enthusiasts in attendance. The event aimed to promote Ceylon Tea and strengthen cultural ties between the two countries.	Mission News	2025-09-28 09:13:38.752259
193	19	Ambassador inaugurates the Office of Honorary Consulate of Sri Lanka in Tbilisi, Georgia	04.07.2022	https://mfa.gov.lk/en/ambassador-inaugurates-the-office-of-honorary-consulate-of-sri-lanka-in-tbilisi-georgia/	The Office of Honorary Consulate of Sri Lanka in Tbilisi, Georgia was inaugurated with a colorful ceremony on June 20, 2022. The event was attended by the Ambassador of Sri Lanka accredited to Georgia, marking the official launch of the consulate.	Mission News	2025-09-28 09:13:38.752259
194	19	Donation of Medicine to Sri Lanka	29.06.2022	https://mfa.gov.lk/en/donation-of-medicine-to-sri-lanka/	Several Buddhist and religious organizations in Malaysia have donated urgent medicine and medical items to Sri Lanka in response to appeals. The donation was made by Karine Gheong representing Chi Hui Tang - Kuala Lumpur and Siew Nyoke. This gesture aims to support the healthcare needs in Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
195	19	High Commissioner Moragoda discusses urgent energy requirements of  Sri Lanka with the Minister of Petroleum and Natural Gas of India	28.06.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-discusses-urgent-energy-requirements-of-sri-lanka-with-the-minister-of-petroleum-and-natural-gas-of-india/	Sri Lankan High Commissioner to India, Milinda Moragoda, held discussions with Indian Minister of Petroleum and Natural Gas and Housing and Urban Affairs, Hardeep Singh Puri, regarding Sri Lanka's urgent energy needs. The meeting focused on bilateral cooperation in addressing these critical energy requirements.	Mission News	2025-09-28 09:13:38.752259
196	19	Minister of Tourism Harin Fernando meets the UK travel industry	28.06.2022	https://mfa.gov.lk/en/minister-of-tourism-harin-fernando-meets-the-uk-travel-industry/	Minister of Tourism Harin Fernando met with the UK travel industry in London on June 16, 2022, at the High Commission of Sri Lanka. The promotional event was organized by the High Commission to showcase Sri Lanka's tourism offerings and strengthen ties with the UK travel sector.	Mission News	2025-09-28 09:13:38.752259
197	19	Ambassador of Sri Lanka to Lebanon pays courtesy call on Head of Mission and Force Commander of UNIFIL Major General Aroldo Lâzaro and visits Sri Lankan Peace Keeping troops	28.06.2022	https://mfa.gov.lk/en/ambassador-of-sri-lanka-to-lebanon-pays-courtesy-call-on-head-of-mission-and-force-commander-of-unifil-major-general-aroldo-lazaro-and-visits-sri-lankan-peace-keeping-troops/	Ambassador of Sri Lanka to Lebanon, Shani Calyaneratne Karunaratne, visited the Head Quarters of UNIFIL and met with the Head of Mission and Force Commander Major General Aroldo Lâzaro. During the visit, the Ambassador also met with Sri Lankan Peacekeeping troops stationed in Lebanon.	Mission News	2025-09-28 09:13:38.752259
198	19	Sri Lanka Embassy in Paris successfully operates a Consular information service on ‘Sri Lanka Day’	23.06.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-paris-successfully-operates-a-consular-information-service-on-sri-lanka-day/	The Sri Lanka Embassy in Paris operated a consular information desk during the Sri Lanka Day festivities at 'Pagode Grande Bois de Vincennes' on June 19. The event was organized by the 'I. Embassy of Sri Lanka successfully provided consular services to attendees during the celebration.	Mission News	2025-09-28 09:13:38.752259
200	19	High Commissioner Moragoda interacts with a group of fifteen European  envoys concurrently accredited to Sri Lanka	22.06.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-interacts-with-a-group-of-fifteen-european-envoys-concurrently-accredited-to-sri-lanka/	High Commissioner of Sri Lanka to India, Milinda Moragoda, recently engaged with a group of fifteen European envoys concurrently accredited to Sri Lanka. This interaction is part of ongoing diplomatic engagement with 94 missions in Sri Lanka from New Delhi, fostering stronger international relations.	Mission News	2025-09-28 09:13:38.752259
201	19	International Domestic Workers Day – 2022	22.06.2022	https://mfa.gov.lk/en/international-domestic-workers-day-2022/	International Domestic Workers Day 2022 was celebrated on June 19 at the Embassy premises in Beirut by the Lebanon Sri Lanka Women's Association and the Embassy of Sri Lanka. The event was organized to honor and recognize the contributions of domestic migrant workers.	Mission News	2025-09-28 09:13:38.752259
202	19	Finance Minister of India assures her fullest support to the economic recovery process in Sri Lanka	22.06.2022	https://mfa.gov.lk/en/finance-minister-of-india-assures-her-fullest-support-to-the-economic-recovery-process-in-sri-lanka/	India's Finance Minister Nirmala Sitharaman assured Sri Lanka's High Commissioner to India, Milinda Moragoda, of her full support and cooperation in the economic recovery process.	Mission News	2025-09-28 09:13:38.752259
203	19	​High Commissioner Moragoda discusses stabilization and recovery of the  Sri Lankan economy with External Affairs Minister of India	21.06.2022	https://mfa.gov.lk/en/%e2%80%8bhigh-commissioner-moragoda-discusses-stabilization-and-recovery-of-the-sri-lankan-economy-with-external-affairs-minister-of-india/	High Commissioner of Sri Lanka to India, Milinda Moragoda, met with India's Minister of External Affairs, Dr. S. Jaishankar, on June 20, 2022, to discuss the stabilization and recovery of the Sri Lankan economy and the future of Indian assistance in this regard. The meeting focused on collaboration for economic progress between the two countries.	Mission News	2025-09-28 09:13:38.752259
204	19	Sri Lanka Embassy in Bahrain conducts a free Medical Camp for  Sri Lankan migrant workers	20.06.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-bahrain-conducts-a-free-medical-camp-for-sri-lankan-migrant-workers/	The Sri Lanka Embassy in Bahrain, along with the Sri Lanka Engineering Society and the American Mission Hospital, conducted a free Medical Camp and Clinic for Sri Lankan migrant workers on 17 June 2022 at the Embassy premises. This initiative aimed to provide healthcare services and support to the migrant community.	Mission News	2025-09-28 09:13:38.752259
205	19	Geographical Indication (GI) status for Ceylon Cinnamon attracts Turkish market	20.06.2022	https://mfa.gov.lk/en/geographical-indication-gi-status-for-ceylon-cinnamon-attracts-turkish-market/	The Embassy of Sri Lanka in Turkey has launched a program to boost the promotion of Ceylon Cinnamon in Turkey following the acquisition of European Union Geographical Indication status. This move aims to attract the Turkish market and enhance the recognition of Ceylon Cinnamon internationally.	Mission News	2025-09-28 09:13:38.752259
206	19	“Afternoon Tea; Learn about Ceylon Tea”	20.06.2022	https://mfa.gov.lk/en/afternoon-tea-learn-about-ceylon-tea/	The Embassy of Sri Lanka in Tokyo, in collaboration with the Foreign Correspondents Club (FCCJ) of Japan, organized a Ceylon Tea Promotion event titled "Afternoon Tea; Learn about Ceylon Tea" at the FCCJ on June 11, 2022. The event was attended by over 60 participants.	Mission News	2025-09-28 09:13:38.752259
207	19	Sri Lanka Mission in New York co-hosts ‘Facets of Sri Lanka’ tourism promotion event with Turkish Airlines and Jetwing Travels	20.06.2022	https://mfa.gov.lk/en/sri-lanka-mission-in-new-york-co-hosts-facets-of-sri-lanka-tourism-promotion-event-with-turkish-airlines-and-jetwing-travels/	The Sri Lanka Mission in New York, in collaboration with Turkish Airlines and Jetwing Travels, co-hosted the 'Facets of Sri Lanka' tourism promotion event on June 14, 2022. The event showcased the diverse attractions that Sri Lanka offers to visitors at the premises of the Sri Lanka Mission to the United Nations.	Mission News	2025-09-28 09:13:38.752259
208	19	Sri Lanka cooperates with Brazilian Travel Agencies to Promote Tourism	17.06.2022	https://mfa.gov.lk/en/sri-lanka-cooperates-with-brazilian-travel-agencies-to-promote-tourism/	Sri Lanka's Embassy in Brazil partnered with the Brazilian Association for Travel Agencies (ABAV- DF) to host an event promoting Sri Lanka as a tourist destination for Brazilian and South American travelers. The collaboration aims to boost tourism between the two countries.	Mission News	2025-09-28 09:13:38.752259
209	19	Exploring bilateral partnerships between Sri Lanka and the Philippines in Technical and Vocational Education (TVET)	17.06.2022	https://mfa.gov.lk/en/exploring-bilateral-partnerships-between-sri-lanka-and-the-philippines-in-technical-and-vocational-education-tvet/	The Embassy of Sri Lanka in Manila is collaborating with key stakeholders like the Colombo Plan Staff College (CPSC) in Manila and the State Ministry of Skills Development and Vocational Education to explore bilateral partnerships with the Philippines in Technical and Vocational Education (TVET). This initiative aims to enhance cooperation and promote skills development between the two countries.	Mission News	2025-09-28 09:13:38.752259
210	19	The Embassy of Sri Lanka in the United Arab Emirates Celebrates Poson  on 14 June 2022	17.06.2022	https://mfa.gov.lk/en/the-embassy-of-sri-lanka-in-the-united-arab-emirates-celebrates-poson-on-14-june-2022/	The Embassy of Sri Lanka in the United Arab Emirates, along with the Sri Lankan community, celebrated Poson on June 14, 2022, in honor of the day Buddhism was introduced to Sri Lanka by Arahat Mahinda Thero during the Poson Poya.	Mission News	2025-09-28 09:13:38.752259
211	19	The Islamic Republic of Iran Pledges Medical Assistance to Sri Lanka	17.06.2022	https://mfa.gov.lk/en/the-islamic-republic-of-iran-pledges-medical-assistance-to-sri-lanka/	The Islamic Republic of Iran has pledged medical assistance to Sri Lanka. Sri Lanka's Ambassador to Iran, G.M. Vipulatheja Wishwanath Aponsu, met with key dignitaries including Deputy Minister of Health Dr. Mohammed Hossein Niknam to discuss the support.	Mission News	2025-09-28 09:13:38.752259
212	19	Ambassador-designate of the Democratic Socialist Republic of Sri Lanka to the Republic of Korea, assumes duties	16.06.2022	https://mfa.gov.lk/en/ambassador-designate-of-the-democratic-socialist-republic-of-sri-lanka-to-the-republic-of-korea-assumes-duties/	Savitri Indrachapa Panabokke, the Ambassador-designate of Sri Lanka to South Korea, has officially started her duties at the Sri Lankan Embassy in Seoul.	Mission News	2025-09-28 09:13:38.752259
213	19	The Sri Lanka Embassy  in Oman organizes a blood donation programme to   coincide with Vesak	16.06.2022	https://mfa.gov.lk/en/the-sri-lanka-embassy-in-oman-organizes-a-blood-donation-programme-to-coincide-with-vesak/	The Sri Lanka Embassy in Oman, led by Ambassador Ameer Ajwad, organized a blood donation program in conjunction with the Vesak festival. The initiative was supported by the Sri Lankan community in Oman, emphasizing the spirit of giving during this auspicious occasion.	Mission News	2025-09-28 09:13:38.752259
215	19	Minister of Education Susil Premajayantha leads the delegation for the 2nd Asia-Pacific Regional Education Minister’s Conference on SDG4 -Education 2030 (APREMC II) in Bangkok.	16.06.2022	https://mfa.gov.lk/en/minister-of-education-susil-premajayantha-leads-the-delegation-for-the-2nd-asia-pacific-regional-education-ministers-conference-on-sdg4-education-2030-apremc-ii-in-bangkok/	Minister of Education Susil Premajayantha led the Sri Lankan delegation at the 2nd Asia-Pacific Regional Education Minister’s Conference on SDG4 -Education 2030 (APREMC II) in Bangkok from June 5 to 7, 2022. The conference focused on advancing education goals in the region.	Mission News	2025-09-28 09:13:38.752259
216	19	The High Commission of Sri Lanka in Ottawa explores avenues for cooperation with Canadian Universities	16.06.2022	https://mfa.gov.lk/en/the-high-commission-of-sri-lanka-in-ottawa-explores-avenues-for-cooperation-with-canadian-universities/	The High Commission of Sri Lanka in Ottawa is collaborating with Canadian universities, including the University of Calgary and the University Grant Commission of Sri Lanka, to explore opportunities for cooperation. Vice Provost and Associate Vice President (International) Prof. Janaka Ruwanpura is involved in these discussions to enhance partnerships between the institutions.	Mission News	2025-09-28 09:13:38.752259
217	19	Sri Lanka joins the celebration of the 75th Anniversary of the United Nations Economic and Social Commission for Asia and the Pacific (UNESCAP) and the 78th Session in  Bangkok	15.06.2022	https://mfa.gov.lk/en/sri-lanka-joins-the-celebration-of-the-75th-anniversary-of-the-united-nations-economic-and-social-commission-for-asia-and-the-pacific-unescap-and-the-78th-session-in-bangko/	Sri Lanka participated in the 75th Anniversary of the UNESCAP and the 78th session in Bangkok, held from 23-27 May 2022 under the theme "A common agenda to advance sustainable development in Asia and the Pacific." The event took place in a hybrid mode at the U.	Mission News	2025-09-28 09:13:38.752259
218	19	A new software application helps the Sri Lanka Consulate General in Melbourne to deliver efficient services	15.06.2022	https://mfa.gov.lk/en/a-new-software-application-helps-the-sri-lanka-consulate-general-in-melbourne-to-deliver-efficient-services/	A new digital Consular Counter Management System has been implemented by the Sri Lanka Consulate General in Melbourne to efficiently serve the Sri Lankan community in Victoria, Australia. This software application aims to streamline consular services for Sri Lankans residing in the Australian state.	Mission News	2025-09-28 09:13:38.752259
219	19	Religious Harmony among Sri Lankan Buddhist, Christian and Muslim Diaspora in Lebanon.	15.06.2022	https://mfa.gov.lk/en/religious-harmony-among-sri-lankan-buddhist-christian-and-muslim-diaspora-in-lebanon/	The Embassy of Sri Lanka in Lebanon organized a ceremony to baptize a newborn baby to Sri Lankan Catholic parents on June 5, 2022, as part of its cultural and religious outreach program. This event showcased religious harmony among the Sri Lankan Buddhist, Christian, and Muslim diaspora in Lebanon.	Mission News	2025-09-28 09:13:38.752259
220	19	CAEDA Offers to Promote Sri Lanka Products Online and Offline in China	10.06.2022	https://mfa.gov.lk/en/caeda-offers-to-promote-sri-lanka-products-online-and-offline-in-china/	CAEDA.UCC, led by Chairman Lu Hongjun, met with Ambassador Dr. Palitha Kohona on June 2, 2022, to discuss promoting Sri Lankan products in China both online and offline. The delegation aims to explore ways and means to enhance economic cooperation between the two countries.	Mission News	2025-09-28 09:13:38.752259
221	19	Sri Lanka’s Tri Forces participate at the Queen’s Platinum Jubilee pageant	10.06.2022	https://mfa.gov.lk/en/sri-lankas-tri-forces-participate-at-the-queens-platinum-jubilee-pageant/	Sri Lanka's Tri Forces participated in the Queen's Platinum Jubilee pageant at the invitation of the UK Government on Sunday, June 5, 2022. The event celebrated Queen Elizabeth II's reign.	Mission News	2025-09-28 09:13:38.752259
222	19	International Tea Day 2022 Celebration & Ceylon Tea Promotion in South Africa	10.06.2022	https://mfa.gov.lk/en/2022-%e0%b6%a2%e0%b7%8f%e0%b6%ad%e0%b7%8a%e2%80%8d%e0%b6%ba%e0%b6%b1%e0%b7%8a%e0%b6%ad%e0%b6%bb-%e0%b6%ad%e0%b7%9a-%e0%b6%af%e0%b7%92%e0%b6%b1%e0%b6%ba-%e0%b7%83%e0%b7%90%e0%b6%b8%e0%b6%bb/	The Sri Lanka High Commission in Pretoria, South Africa, celebrated International Tea Day 2022 at the World Food Festival. May 21 was designated by the United Nations General Assembly in 2019 to raise awareness about the importance of tea. The event also promoted Ceylon tea in South Africa.	Mission News	2025-09-28 09:13:38.752259
223	19	High Commissioner Milinda Moragoda calls on the Chief Minister of  Tamil Nadu	10.06.2022	https://mfa.gov.lk/en/high-commissioner-milinda-moragoda-calls-on-the-chief-minister-of-tamil-nadu/	Sri Lanka's High Commissioner to India, Milinda Moragoda, visited the Chief Minister of Tamil Nadu, Thiru M.K. Stalin, at his office in Chennai on Saturday morning. The meeting was a courtesy call to strengthen diplomatic ties between the two regions.	Mission News	2025-09-28 09:13:38.752259
224	19	Sri Lanka participates at the 3rd Pakistan Tea Convention in Karachi	10.06.2022	https://mfa.gov.lk/en/sri-lanka-participates-at-the-3rd-pakistan-tea-convention-in-karachi/	Sri Lanka participated in the 3rd Pakistan Tea Convention organized by the Pakistan Tea Association at the Marriot Hotel in Karachi from May 20 to 22, 2022. The event saw the attendance of over 300 leaders from Pakistan's tea industry.	Mission News	2025-09-28 09:13:38.752259
225	19	Sri Lanka Embassy in Beijing promotes Ceylon Black Tea at  International Tea Day 2022	10.06.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-beijing-promotes-ceylon-black-tea-at-international-tea-day-2022/	The Sri Lanka Embassy in Beijing marked International Tea Day on June 7, 2022, by showcasing Ceylon Black Tea. This event was a delayed celebration due to pandemic restrictions. International Tea Day is observed annually on May 21.	Mission News	2025-09-28 09:13:38.752259
226	19	‘Support Sri Lanka’ organised by the Deputy High Commission of Sri Lanka in Chennai.	10.06.2022	https://mfa.gov.lk/en/support-sri-lanka-organised-by-the-deputy-high-commission-of-sri-lanka-in-chennai/	The Deputy High Commission of Sri Lanka in Chennai organized 'Support Sri Lanka' to secure the food and health safety of Sri Lanka through financial support. The program aimed to ensure the well-being of the country's population.	Mission News	2025-09-28 09:13:38.752259
227	19	Ambassador Sanjiv Gunasekara calls on Parliamentary Vice – Minister for Foreign Affairs of Japan, Honda Taro	09.06.2022	https://mfa.gov.lk/en/ambassador-sanjiv-gunasekara-calls-on-parliamentary-vice-minister-for-foreign-affairs-of-japan-honda-taro/	Ambassador Sanjiv Gunasekara met with Japan's Parliamentary Vice-Minister for Foreign Affairs, Honda Taro on June 2, 2022. They discussed Sri Lanka's current economic situation and other relevant matters during their meeting.	Mission News	2025-09-28 09:13:38.752259
243	19	Sri Lanka Consulate General participates at the “My Karachi International Exhibition” in Karachi	18.05.2022	https://mfa.gov.lk/en/sri-lanka-consulate-general-participates-at-the-my-karachi-international-exhibition-in-karachi/	The Consulate General of Sri Lanka in Karachi participated in the 17th My Karachi International Exhibition from May 13 to 15, 2022, at the Karachi Expo Center in Pakistan. The event was sponsored by the Department, and the Sri Lankan representation was successful in showcasing their presence.	Mission News	2025-09-28 09:13:38.752259
228	19	Ambassador C.A. Chaminda I. Colonne presents the Letter of Credence to the His Majesty Preah Bat Samdech Preah Boromneath Norodom Sihamoni, King of the Kingdom of Cambodia	02.06.2022	https://mfa.gov.lk/en/ambassador-c-a-chaminda-i-colonne-presents-the-letter-of-credence-to-the-his-majesty-preah-bat-samdech-preah-boromneath-norodom-sihamoni-king-of-the-kingdom-of-cambodia/	Ambassador C.A. Chaminda I. Colonne of Sri Lanka presented his Letter of Credence to His Majesty Preah Bat Samdech Preah Boromneath Norodom Sihamoni, the King of Cambodia. He currently serves as Sri Lanka's Ambassador to Thailand and Permanent Representative to UNESCAP.	Mission News	2025-09-28 09:13:38.752259
229	19	India-Sri Lanka Foundation holds its 37 Board Meeting in New Delhi	02.06.2022	https://mfa.gov.lk/en/india-sri-lanka-foundation-holds-its-37-board-meeting-in-new-delhi/	The India-Sri Lanka Foundation convened its 37th Board Meeting in New Delhi on the 27th, co-chaired by Sri Lanka's High Commissioner to India, Milinda Moragoda, and the High Commissioner of India to Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
230	19	Sri Lanka Deputy High Commission in Chennai issues 330 citizenship certificates, 31 birth certificates and 9 RRP Passports during two Special Consular Camps	01.06.2022	https://mfa.gov.lk/en/sri-lanka-deputy-high-commission-in-chennai-issues-330-citizenship-certificates-31-birth-certificates-and-9-rrp-passports-during-two-special-consular-camps/	The Sri Lanka Deputy High Commission in Chennai issued 330 citizenship certificates, 31 birth certificates, and 9 RRP Passports during two Special Consular Camps. These camps were organized to facilitate document processing for individuals in need of these official documents.	Mission News	2025-09-28 09:13:38.752259
231	19	Vesak celebrations in Berlin	01.06.2022	https://mfa.gov.lk/en/vesak-celebrations-in-berlin/	The Embassy of Sri Lanka in Berlin celebrated Vesak at the Official Residence on 29 May 2022 with the participation of the members of the Sri Lanka Association in Germany and disciples of Das Buddhistische Haus in Berlin. The event marked a significant cultural and religious celebration in the heart of Berlin.	Mission News	2025-09-28 09:13:38.752259
232	19	Sri Lanka Embassy in Ankara, Turkey celebrates Vesak 2022	27.05.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-ankara-turkey-celebrates-vesak-2022/	The Sri Lanka Embassy in Ankara, Turkey celebrated Vesak 2022 for the first time at the Chancery premises with Buddhist religious activities on 24 May. Venerable Bhante Pannawansa Thero attended the event upon the Embassy's invitation.	Mission News	2025-09-28 09:13:38.752259
233	19	The United Nations General Assembly adopts Sri Lanka sponsored resolution to declare 1 March as ‘World Sea-grass Day’	25.05.2022	https://mfa.gov.lk/en/the-united-nations-general-assembly-adopts-sri-lanka-sponsored-resolution-to-declare-1-march-as-world-sea-grass-day/	The United Nations General Assembly adopted a resolution sponsored by Sri Lanka on May 23, 2022, declaring March 1 as 'World Seagrass Day'. The resolution, co-sponsored by 24 countries, was passed by consensus. This initiative aims to raise awareness about the importance of seagrass ecosystems for marine biodiversity.	Mission News	2025-09-28 09:13:38.752259
234	19	Sri Lankan and Thai Buddhists in South Africa Celebrate Vesak on the theme of Religious Harmony	25.05.2022	https://mfa.gov.lk/en/sri-lankan-and-thai-buddhists-in-south-africa-celebrate-vesak-on-the-theme-of-religious-harmony/	Sri Lankan and Thai Buddhists in South Africa celebrated Vesak on the theme of Religious Harmony. The Sri Lanka Mission staff in Pretoria and Sri Lankans in Johannesburg joined the 2022 Vesak celebrations by special invitation from the Thai Buddhist Temple - Johannesburg Medit. The event highlighted the importance of unity among different Buddhist communities in promoting religious harmony.	Mission News	2025-09-28 09:13:38.752259
235	19	Vesak celebrated in Brussels	25.05.2022	https://mfa.gov.lk/en/vesak-celebrated-in-brussels/	The Embassy of Sri Lanka in Brussels celebrated Vesak at the Official Residence on May 22, 2022, with the participation of the Sri Lankan community in Belgium and Luxembourg. The event also included representatives from the Mahamevnawa Buddhist Monastery in the Netherlands.	Mission News	2025-09-28 09:13:38.752259
236	19	The Vesak Full Moon Poya Day celebrated in Manila	24.05.2022	https://mfa.gov.lk/en/the-vesak-full-moon-poya-day-celebrated-in-manila/	The Embassy of Sri Lanka in Manila and the Universal Wisdom Foundation Inc. (UWFI) celebrated the Vesak Full Moon Poya Day at Wisdom Park. The event was attended by Ambassadors and other diplomatic representatives.	Mission News	2025-09-28 09:13:38.752259
237	19	Sri Lanka’s role in getting due recognition for Vesak Day highlighted at celebrations in Kathmandu	24.05.2022	https://mfa.gov.lk/en/sri-lankas-role-in-getting-due-recognition-for-vesak-day-highlighted-at-celebrations-in-kathmandu/	During the Vesak Day celebration at the Sri Lankan Embassy in Kathmandu on May 18th, Ambassador Himalee Arunatilaka emphasized Sri Lanka's role in securing recognition for Vesak Day as a public holiday in Nepal. She highlighted the efforts made to promote the significance of Vesak internationally.	Mission News	2025-09-28 09:13:38.752259
238	19	Consulate General in Mumbai promotes Cinnamon with ISKCON temple	20.05.2022	https://mfa.gov.lk/en/consulate-general-in-mumbai-promotes-cinnamon-with-iskcon-temple/	The Consulate General of Sri Lanka in Mumbai launched a Ceylon Cinnamon promotion campaign by offering 5kgs of Ceylon Cinnamon to Lord Krishna at the ISKCON temple.	Mission News	2025-09-28 09:13:38.752259
239	19	Embassy of Sri Lanka in Viet Nam holds Vesak Day Blessing Ceremony	19.05.2022	https://mfa.gov.lk/en/embassy-of-sri-lanka-in-viet-nam-holds-vesak-day-blessing-ceremony/	The Embassy of Sri Lanka in Viet Nam held the Vesak Day Blessing Ceremony on May 14, 2022, in partnership with Bai Dinh Pagoda in Ninh Binh Province. The event was also supported by Linea Aqua Viet Nam Co. Ltd.	Mission News	2025-09-28 09:13:38.752259
240	19	Embassy of Sri Lanka in Yangon Commemorates Vesak Day 2022	19.05.2022	https://mfa.gov.lk/en/embassy-of-sri-lanka-in-yangon-commemorates-vesak-day-2022/	The Embassy of Sri Lanka in Yangon, Myanmar organized the commemoration of Vesak Day 2022 on Sunday, 15 May 2022. The event featured Ven. Bandarawela Wimalawansha Thero, a highly respected Sri Lankan Buddhist Bhikku known for his teachings on meditation.	Mission News	2025-09-28 09:13:38.752259
241	19	Indian Buddhists arrive in Sri Lanka under the Buddhist trail promotion organized by the Consulate General of Sri Lanka in Mumbai	19.05.2022	https://mfa.gov.lk/en/indian-buddhists-arrive-in-sri-lanka-under-the-buddhist-trail-promotion-organized-by-the-consulate-general-of-sri-lanka-in-mumbai/	The Consulate General of Sri Lanka in Mumbai organized a Buddhist tourist group of 90 Buddhists from Maharashtra, India, to visit Sri Lanka as part of the Buddhist trail promotion. This marks the first group of Indian Buddhists to visit Sri Lanka under this initiative.	Mission News	2025-09-28 09:13:38.752259
242	19	Vesak Celebrations at the Embassy of Sri Lanka in Tehran	18.05.2022	https://mfa.gov.lk/en/vesak-celebrations-at-the-embassy-of-sri-lanka-in-tehran/	The Embassy of Sri Lanka in Tehran celebrated Vesak on May 15, 2022, at the Chancery premises. The Ambassador, staff members, and the Sri Lankan community gathered at the Embassy for the occasion. The event marked a significant cultural and religious celebration for the Sri Lankan community in Tehran.	Mission News	2025-09-28 09:13:38.752259
244	19	The Consulate General of Sri Lanka in Mumbai celebrates Vesak	18.05.2022	https://mfa.gov.lk/en/the-consulate-general-of-sri-lanka-in-mumbai-celebrates-vesak/	The Consulate General of Sri Lanka in Mumbai celebrated Vesak Day on May 14, 2022, at their premises. The event was attended by staff members and the Sri Lankan community in Mumbai, featuring special festivities. It was a joyous celebration of Vesak.	Mission News	2025-09-28 09:13:38.752259
245	19	Sri Lanka Deputy High Commission in Chennai Celebrates Vesak	18.05.2022	https://mfa.gov.lk/en/sri-lanka-deputy-high-commission-in-chennai-celebrates-vesak/	The Sri Lanka Deputy High Commission in Chennai celebrated Vesak, which commemorates the birth, enlightenment, and passing away of Lord Buddha. Vesak is widely celebrated in South and Southeast Asia among Buddhism followers. The event was held to honor this important occasion.	Mission News	2025-09-28 09:13:38.752259
246	19	Sri Lanka Embassy in Beijing Celebrates Vesak 2022	17.05.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-beijing-celebrates-vesak-2022/	The Sri Lanka Embassy in Beijing celebrated Vesak 2022, honoring the birth, enlightenment, and passing away of Lord Buddha on May 15. The event was low-key, with attendance limited to embassy staff.	Mission News	2025-09-28 09:13:38.752259
247	19	First ever visit of Buddhist and Hindu Priests from Sri Lanka to Saudi Arabia	17.05.2022	https://mfa.gov.lk/en/first-ever-visit-of-buddhist-and-hindu-priests-from-sri-lanka-to-saudi-arabia/	Buddhist and Hindu Priests from Sri Lanka made their first-ever visit to Saudi Arabia upon an invitation from Sheikh Dr. Mohammad bin Abdulkarim Al-Issa, Secretary General of the Muslim World League. The visit was for their participation in a forum titled "Promoting Moderation and Rejecting Extremism.	Mission News	2025-09-28 09:13:38.752259
248	19	Sri Lanka Mission in Maldives organises a blood donation to mark Vesak	17.05.2022	https://mfa.gov.lk/en/sri-lanka-mission-in-maldives-organises-blood-donation-to-mark-vesak/	The Sri Lanka High Commission in Maldives organized a blood donation program on 14 May 2022 to commemorate Vesak. This initiative marked the first-ever blood donation drive undertaken by the Sri Lankan mission in Maldives.	Mission News	2025-09-28 09:13:38.752259
249	19	​Commemoration of the International day of Vesak in New York	16.05.2022	https://mfa.gov.lk/en/%e2%80%8bcommemoration-of-the-international-day-of-vesak-in-new-york/	The Permanent Missions of Sri Lanka and Thailand co-hosted a virtual commemoration of the International Day of Vesak on May 13, 2022, at the United Nations in New York. This event, sponsored by Sri Lanka and Thailand in 1999, celebrated the significance of Vesak internationally.	Mission News	2025-09-28 09:13:38.752259
250	19	Sri Lanka Embassy in Lebanon & Syria celebrates Vesak	16.05.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-lebanon-syria-celebrates-vesak/	The Sri Lanka Embassy in Lebanon & Syria celebrated Vesak on 15 May 2022 with Sri Lankans, Lebanese, and Syrians in attendance. The highlight of the Vesak 2022 celebration was the unveiling of a special event at the Embassy premises.	Mission News	2025-09-28 09:13:38.752259
251	19	Talent Show – 2022 in Lebanon	09.05.2022	https://mfa.gov.lk/en/talent-show-2022-in-lebanon/	The Embassy of Sri Lanka, in collaboration with the Rathnadeepa International Migrant Board, organized a Talent Show and Bazaar in Lebanon for May Day as part of the Public Diplomacy Community welfare program. The event aimed to showcase the talents of Sri Lankan migrants residing in Lebanon.	Mission News	2025-09-28 09:13:38.752259
252	19	Sri Lanka’s Ambassador – designate to Myanmar assumes duties	06.05.2022	https://mfa.gov.lk/en/sri-lankas-ambassador-designate-to-myanmar-assumes-duties/	Sri Lanka's newly appointed Ambassador-designate to Myanmar, J.M. Janaka Priyantha Bandara, assumed duties at the Sri Lanka Embassy in Yangon on May 2, 2022. He addressed the embassy staff upon assuming office.	Mission News	2025-09-28 09:13:38.752259
253	19	Establishment of Diplomatic Relations between the Democratic Socialist Republic of Sri Lanka and the Democratic Republic of Timor-Leste.	06.05.2022	https://mfa.gov.lk/en/establishment-of-diplomatic-relations-between-the-democratic-socialist-republic-of-sri-lanka-and-the-democratic-republic-of-timor-leste/	Today, on May 4, 2022, the Democratic Socialist Republic of Sri Lanka and the Democratic Republic of Timor-Leste officially established diplomatic relations through the signing ceremony of the Joint Communiqué. The event took place at the Pe.	Mission News	2025-09-28 09:13:38.752259
254	19	​Bangladesh donates medical supplies to Sri Lanka	06.05.2022	https://mfa.gov.lk/en/%e2%80%8bbangladesh-donates-medical-supplies-to-sri-lanka/	Bangladesh donated medical supplies to Sri Lanka in response to a request from the Sri Lankan Government. The donation took place at a ceremony held at the State Guest House Padma in Dhaka on May 5, 2022.	Mission News	2025-09-28 09:13:38.752259
255	19	The Government of Indonesia donates medical supplies	05.05.2022	https://mfa.gov.lk/en/the-government-of-indonesia-donates-medical-supplies/	The Indonesian Government donated 11 types of medicines and 8 types of medical devices to Sri Lanka in response to a humanitarian aid request. This donation aims to provide essential medical supplies to the people of Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
256	19	The President of the National Assembly and Speaker of the House of Representatives of the Kingdom of Thailand Chuan Leekpai hands over 700,000 Thai Baht to Sri Lanka	05.05.2022	https://mfa.gov.lk/en/the-president-of-the-national-assembly-and-speaker-of-the-house-of-representatives-of-the-kingdom-of-thailand-chuan-leekpai-hands-over-700000-thai-baht-to-sri-lanka/	Chuan Leekpai, President of the National Assembly and Speaker of the House of Representatives of Thailand, handed over a 700,000 Thai Baht cheque to the Sri Lankan Ambassador in a gesture of support. The donation aims to assist Sri Lanka in addressing its current challenges.	Mission News	2025-09-28 09:13:38.752259
257	19	Assistant High Commissioner (Protection) of UNHCR and the delegation meets the Deputy High Commissioner of Sri Lanka in Chennai	05.05.2022	https://mfa.gov.lk/en/assistant-high-commissioner-protection-of-unhcr-and-the-delegation-meets-the-deputy-high-commissioner-of-sri-lanka-in-chennai/	The Assistant High Commissioner (Protection) of UNHCR, Gillian Triggs, led a delegation that met with Dr. D. Venkateshwaran, the Deputy High Commissioner of Sri Lanka in Chennai.	Mission News	2025-09-28 09:13:38.752259
258	19	Investment Opportunities of the Port City Colombo presented in London	05.05.2022	https://mfa.gov.lk/en/investment-opportunities-of-the-port-city-colombo-presented-in-london-2/	The Sri Lanka High Commission in London, in collaboration with CHEC Port City Colombo (Pvt) Ltd and the Commonwealth Enterprise and Investment Council, hosted a presentation on investment opportunities in education and finance. The event aimed to showcase the potential for investment in the Port City Colombo project.	Mission News	2025-09-28 09:13:38.752259
259	19	Ambassador Dr Palitha Kohona Presents His Letter of Credence to  The President of Mongolia	04.05.2022	https://mfa.gov.lk/en/ambassador-dr-palitha-kohona-presents-his-letter-of-credence-to-the-president-of-mongolia/	Ambassador Dr. Palitha Kohona, who serves as the Ambassador to Mongolia, presented his Letter of Credence to President Khurelsukh Ukhnaa on April 27, 2022. The ceremony marked the official accreditation of Ambassador Kohona to Mongolia.	Mission News	2025-09-28 09:13:38.752259
260	19	The Sri Lanka Embassy in Beirut conducts internship on diplomacy	04.05.2022	https://mfa.gov.lk/en/the-sri-lanka-embassy-in-beirut-conducts-internship-on-diplomacy/	The Sri Lanka Embassy in Beirut conducted an internship focusing on languages, diplomacy, sworn translations, digital citizenship, and dress code. The program aimed to provide valuable insights into the field of diplomacy for participants.	Mission News	2025-09-28 09:13:38.752259
261	19	The first Sri Lanka Tea Shop and Cultural Centre Opened in Beijing	27.04.2022	https://mfa.gov.lk/en/the-first-sri-lanka-tea-shop-and-cultural-centre-opened-in-beijing/	The Embassy of Sri Lanka in Beijing, in partnership with the China Sri Lanka Association for Trade and Economic Cooperation (CSLATE) and the Beijing Wanhongtai Technology Group Co., Ltd., inaugurated the first Sri Lanka Tea Shop and Cultural Centre in Beijing. This initiative aims to promote Sri Lankan tea and culture in China, fostering closer ties between the two nations.	Mission News	2025-09-28 09:13:38.752259
262	19	Air Chief Marshal Sumangala Dias presents Credentials to His Majesty the King of Malaysia	27.04.2022	https://mfa.gov.lk/en/air-chief-marshal-sumangala-dias-presents-credentials-to-his-majesty-the-king-of-malaysia/	Air Chief Marshal Dabare Liyanage Sumangala Dias, the High Commissioner, presented his Credentials to His Majesty the King of Malaysia, Yang di-Pertuan Agong Al-Sultan Abdullah Ri'ayatuddin Al-Mustafa Billah Shah Ibni Almarhum Sultan H. This formal ceremony solidifies the diplomatic relationship between Sri Lanka and Malaysia.	Mission News	2025-09-28 09:13:38.752259
263	19	New Honorary Consul of Sri Lanka in Tyrol appointed	26.04.2022	https://mfa.gov.lk/en/new-honorary-consul-of-sri-lanka-in-tyrol-appointed/	Ambassador Majintha Jayesinghe appointed Dr. Christian Steppan as the new Honorary Consul of Sri Lanka in Tyrol, Austria. Dr. Steppan received the Commission of Appointment for this role.	Mission News	2025-09-28 09:13:38.752259
264	19	Sri Lanka represented at the 4th Asia Pacific Water Summit	26.04.2022	https://mfa.gov.lk/en/sri-lanka-represented-at-the-4th-asia-pacific-water-summit/	Sri Lanka was represented at the 4th Asia Pacific Water Summit, which opened on April 23, 2022, in Kumamoto City. The summit saw the participation of high-level delegations from various Asia-Pacific countries and representatives of international organizations.	Mission News	2025-09-28 09:13:38.752259
265	19	Sri Lanka Coconut kernel products promoted in Belgium	26.04.2022	https://mfa.gov.lk/en/sri-lanka-coconut-kernel-products-promoted-in-belgium/	The Embassy of Sri Lanka in Brussels organized a workshop titled “COCONUT WONDER - Truly Sri Lankan” on April 21, 2022, to boost the export of Sri Lankan coconut kernel products to Belgium. The event aimed to promote these products and enhance trade relations between the two countries.	Mission News	2025-09-28 09:13:38.752259
266	19	Sri Lankan Drama “Love and Lockdown” staged at 23 Sabancı Adana  International Theater Festival	22.04.2022	https://mfa.gov.lk/en/sri-lankan-drama-love-and-lockdown-staged-at-23-sabanci-adana-international-theater-festival/	Sri Lanka's Inter Act Art Theatre Institute performed their monodrama "Love & Lockdown" at the 23rd Sabancı Adana International Theater Festival, following an invitation from the State Theatres Directorate General of Turkey.	Mission News	2025-09-28 09:13:38.752259
267	19	The Embassy of Sri Lanka in Abu Dhabi celebrates Sinhala and Tamil New Year with the Sri Lankan community	22.04.2022	https://mfa.gov.lk/en/the-embassy-of-sri-lanka-in-abu-dhabi-celebrates-sinhala-and-tamil-new-year-with-the-sri-lankan-community/	The Embassy of Sri Lanka in Abu Dhabi, along with the Dhamma School and the Sri Lankan Community, celebrated Sinhala and Tamil New Year with children under the theme of 'හෙළ සූර්ය මංගල'. The event aimed to bring together the Sri Lankan community in Abu Dhabi for a joyous cultural celebration.	Mission News	2025-09-28 09:13:38.752259
268	19	The Embassy of Sri Lanka in Beijing Celebrates the National New Year Day	21.04.2022	https://mfa.gov.lk/en/the-embassy-of-sri-lanka-in-beijing-celebrates-the-national-new-year-day/	The Embassy of Sri Lanka in Beijing celebrated the National New Year on April 17, 2022, following customs and traditions. The event was attended by over 150 invitees, including Ambassadors and representatives from Diplomatic Missions. It was a festive occasion that brought together a diverse group to mark the special day.	Mission News	2025-09-28 09:13:38.752259
269	19	Business contacts and orders for Sri Lankan companies at ANUFOOD Brazil exhibition	20.04.2022	https://mfa.gov.lk/en/business-contacts-and-orders-for-sri-lankan-companies-at-anufood-brazil-exhibition/	Several Sri Lankan tea exporters, including M/S. Imperial Tea (Pvt) Ltd, M/S Maltras International (Pvt) Ltd, M/S Basilure Teas (Pvt) Ltd, and M/S Tea Talk (Pvt) Ltd, participated in the ANUFOOD Brazil 2022 exhibition. They established valuable business contacts and received orders during the event, showcasing the potential for growth in the Sri Lankan tea industry.	Mission News	2025-09-28 09:13:38.752259
270	19	Colombo Plan scholars visit Sri Lanka High Commission in Canberra	20.04.2022	https://mfa.gov.lk/en/colombo-plan-scholars-visit-sri-lanka-high-commission-in-canberra/	Colombo Plan scholars visiting Sri Lanka High Commission in Canberra were welcomed at an event on April 14, 2022. They will pursue studies in Sri Lanka under the New Colombo Plan Programme.	Mission News	2025-09-28 09:13:38.752259
271	19	Prospects for exporting more gems & jewellery from Sri Lanka to Southern China	19.04.2022	https://mfa.gov.lk/en/prospects-for-exporting-more-gems-jewellery-from-sri-lanka-to-southern-china/	The Sri Lanka Export Development Board, in collaboration with the Consulate General of Sri Lanka in Guangzhou, arranged virtual B2B meetings on April 6 and 7, 2022, connecting five prominent Sri Lankan gem and jewelry businesses with potential partners in Southern China. This initiative aims to enhance opportunities for exporting gems and jewelry from Sri Lanka to the Southern Chinese market.	Mission News	2025-09-28 09:13:38.752259
272	19	Bangladesh and Sri Lanka explore new investments and Blue economy potential	19.04.2022	https://mfa.gov.lk/en/bangladesh-and-sri-lanka-explore-new-investments-and-blue-economy-potential/	Bangladesh and Sri Lanka are exploring new investments and the potential of the Blue economy. High Commissioner Professor Sudharshan Seneviratne emphasized the importance of both countries working together to achieve mutual benefits in various investment areas.	Mission News	2025-09-28 09:13:38.752259
273	19	“Ramadan Kareem – Harmony without Boundaries”  The Embassy of Sri Lanka in Abu Dhabi Celebrates Ramadan	19.04.2022	https://mfa.gov.lk/en/ramadan-kareem-harmony-without-boundaries-the-embassy-of-sri-lanka-in-abu-dhabi-celebrates-ramadan/	The Embassy of Sri Lanka in Abu Dhabi, UAE, celebrated Ramadan by hosting an 'Iftar' for Sri Lankan Muslims living in the country. The event aimed to promote harmony and unity among the Sri Lankan community during the holy month.	Mission News	2025-09-28 09:13:38.752259
274	19	Tourism Promotion Partnership Event-2022 held in Iran	19.04.2022	https://mfa.gov.lk/en/tourism-promotion-partnership-event-2022-held-in-iran/	The Embassy of Sri Lanka in Iran recently hosted the Tourism Promotion Partnership Event-2022 at its Chancery premises in Tehran on April 6, 2022. The event, supported by the Sri Lanka Tourism Promotion Bureau and Associations, aimed to boost tourism collaboration between the two countries.	Mission News	2025-09-28 09:13:38.752259
275	19	Sri Lankan New Year Celebrated in Karachi	18.04.2022	https://mfa.gov.lk/en/sri-lankan-new-year-celebrated-in-karachi/	The Sri Lanka Consulate in Karachi and the Sri Lanka Community in Sindh & Balochistan provinces celebrated the Sinhala & Tamil New Year at the IQRA University premises in Karachi on Saturday, April 2. The event marked a joyous celebration of the New Year traditions in Pakistan.	Mission News	2025-09-28 09:13:38.752259
276	19	Sri Lanka Embassy in Jordan organizes an Arabica Coffee Awareness Promotion	11.04.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-jordan-organizes-an-arabica-coffee-awareness-promotion/	The Sri Lanka Embassy in Jordan hosted a workshop to promote high-quality Sri Lankan Arabica coffee among Jordanian coffee importers and shop owners. The event aimed to raise awareness and appreciation for Sri Lankan Arabica coffee in Jordan's market.	Mission News	2025-09-28 09:13:38.752259
277	19	Bangladesh corporate sector ready to expand economic cooperation  with Sri Lanka	06.04.2022	https://mfa.gov.lk/en/bangladesh-corporate-sector-ready-to-expand-economic-cooperation-with-sri-lanka/	The Sri Lanka High Commissioner to Bangladesh highlighted the strong historical and cultural ties between the two countries, emphasizing the need to enhance economic cooperation. Bangladesh's corporate sector is poised to expand collaboration with Sri Lanka, paving the way for increased mutual benefits and growth opportunities.	Mission News	2025-09-28 09:13:38.752259
278	19	Sri Lanka Trade Minister Concludes Fruitful Bilateral Visit to Oman	06.04.2022	https://mfa.gov.lk/en/sri-lanka-trade-minister-concludes-fruitful-bilateral-visit-to-oman/	Sri Lanka's Trade Minister Dr. Bandula Gunawardhana led a five-member delegation on a successful bilateral trade visit to Oman from March 27 to 28, 2022. The visit, organized by the Sri Lanka Embassy in Oman, aimed to strengthen trade relations between the two countries.	Mission News	2025-09-28 09:13:38.752259
279	19	127 Birth Certificates, 315 Citizenship Certificates and 34 Refugee Repatriation Programme (RRP) Passports issued by the Sri Lanka Deputy High Commission in Chennai	04.04.2022	https://mfa.gov.lk/en/127-birth-certificates-315-citizenship-certificates-and-34-refugee-repatriation-programme-rrp-passports-issued-by-the-sri-lanka-deputy-high-commission-in-chennai/	The Sri Lanka Deputy High Commission in Chennai issued 127 Birth Certificates, 315 Citizenship Certificates, and 34 Refugee Repatriation Programme (RRP) Passports at three special consular camps. These documents were provided to individuals during the organized events.	Mission News	2025-09-28 09:13:38.752259
280	19	Enhancing Collaboration between Sri Lanka and the Philippines through Technical Cooperation	04.04.2022	https://mfa.gov.lk/en/enhancing-collaboration-between-sri-lanka-and-the-philippines-through-technical-cooperation/	Sri Lanka and the Philippines are enhancing collaboration through technical cooperation. The Department of Foreign Affairs - Technical Cooperation Council of the Philippines (DFA-TCCP) is working with the Department of Agriculture-Philippine Rice Research Institute (PhilRice) and the Embassy of Sri Lanka to facilitate this partnership.	Mission News	2025-09-28 09:13:38.752259
281	19	“Hello Again” – High Commission of Sri Lanka in Malaysia organizes Sri Lanka Tourism Promotional Event	01.04.2022	https://mfa.gov.lk/en/hello-again-high-commission-of-sri-lanka-in-malaysia-organizes-sri-lanka-tourism-promotional-event/	The High Commission of Sri Lanka in Malaysia recently organized a tourism promotional event to raise awareness among tour operators for the year 2022. Starting from April 1, 2022, Malaysia will be opening its borders to tourists. This event aimed to boost tourism between the two countries.	Mission News	2025-09-28 09:13:38.752259
282	19	The President of the Asian Infrastructure Investment Bank (AIIB), encourages Sri Lanka to consult the IMF on the current economic challenges	01.04.2022	https://mfa.gov.lk/en/the-president-of-the-asian-infrastructure-investment-bank-aiib-encourages-sri-lanka-to-consult-the-imf-on-the-current-economic-challenges/	The President of the Asian Infrastructure Investment Bank (AIIB), Jin Liqun, advised Sri Lanka to seek guidance from the IMF regarding its current economic challenges. He shared this recommendation during a meeting with the Sri Lankan Ambassador.	Mission News	2025-09-28 09:13:38.752259
283	19	China – Sri Lanka Association for Trade & Economic Cooperation (CSLATE) Signs Three MOUs to Promote Business Cooperation	01.04.2022	https://mfa.gov.lk/en/china-sri-lanka-association-for-trade-economic-cooperation-cslate-signs-three-mous-to-promote-business-cooperation/	The China - Sri Lanka Association for Trade & Economic Cooperation (CSLATE) signed three MOUs with the CZK International Investment Group, the Hunan Construction Engineering Group, and the China Light Industry Jewe to promote business cooperation.	Mission News	2025-09-28 09:13:38.752259
284	19	Appointing New Honorary Consul to Ho Chi Minh City, Viet Nam	29.03.2022	https://mfa.gov.lk/en/appointing-new-honorary-consul-to-ho-chi-minh-city-viet-nam/	The Government of Sri Lanka has appointed Shirley Marguerite Hopman-Aluwihare as the Honorary Consul of Sri Lanka in Ho Chi Minh City, Vietnam. She received her Exequatur from the Deputy Director-General of the Department. Shirley Marguerite Hopman-Aluwihare is now the official Honorary Consul representing Sri Lanka in Ho Chi Minh City.	Mission News	2025-09-28 09:13:38.752259
285	19	State Minister of Foreign Employment Promotion and Market Diversification Piyankara Jayaratne concludes a successful visit to the Kingdom of Saudi Arabia	29.03.2022	https://mfa.gov.lk/en/state-minister-of-foreign-employment-promotion-and-market-diversification-piyankara-jayaratne-concludes-a-successful-visit-to-the-kingdom-of-saudi-arabia/	State Minister of Foreign Employment Promotion and Market Diversification Piyankara Jayaratne successfully concluded his official visit to the Kingdom of Saudi Arabia from 19 to 24 March 2022. During the visit, he engaged in discussions and meetings to strengthen bilateral relations between the two countries.	Mission News	2025-09-28 09:13:38.752259
286	19	State Minister for Regional Cooperation Tharaka Balasuriya concludes official visit to KSA	28.03.2022	https://mfa.gov.lk/en/state-minister-for-regional-cooperation-tharaka-balasuriya-concludes-official-visit-to-ksa/	State Minister for Regional Cooperation Tharaka Balasuriya concluded his official visit to the Kingdom of Saudi Arabia from 19 to 21 March 2022. This visit marks the first-ever bilateral visit at the Foreign Ministry level between the two countries.	Mission News	2025-09-28 09:13:38.752259
287	19	New Generation Technology Company iGreenData in Melbourne recruits thirty-two Sri Lankan Software Engineers	28.03.2022	https://mfa.gov.lk/en/new-generation-technology-company-igreendatain-melbourne-recruits-thirty-two-sri-lankan-software-engineers/	iGreenData, a technology company in Melbourne, has recruited thirty-two skilled Software Engineers from Sri Lanka to work in Australia. The engineers recently visited the Consulate General of Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
327	19	Ambassador Majintha Jayesinghe presents Letters of Credence in Hungary	24.02.2022	https://mfa.gov.lk/en/ambassador-majintha-jayesinghe-presents-letters-of-credence-in-hungary/	Ambassador Majintha Jayesinghe presented the Letters of Credence to the President of Hungary, János Áder, at the Sándor Palace in Budapest, officially accrediting as the Ambassador Extraordinary and Plenipotentiary. This ceremony marks the formal beginning of Ambassador Jayesinghe's diplomatic mission in Hungary.	Mission News	2025-09-28 09:13:38.752259
288	19	Ministers Rajapaksa, Jaishankar and Sitharaman witness the signing of the USD 1 billion Indo – Lanka Loan Agreement	24.03.2022	https://mfa.gov.lk/en/ministers-rajapaksa-jaishankar-and-sitharaman-witness-the-signing-of-the-usd-1-billion-indo-lanka-loan-agreem/	Finance Minister Basil Rajapaksa concluded his two-day official visit to New Delhi by witnessing the signing of a USD 1 billion Indo-Lanka Loan Agreement. The agreement pertains to a Short-Term Concessional Loan facility extended during the visit. This marks a significant financial collaboration between the two countries.	Mission News	2025-09-28 09:13:38.752259
289	19	Finance Minister Basil Rajapaksa holds bilateral talks with the External Affairs Minister of India Dr. S. Jaishankar	24.03.2022	https://mfa.gov.lk/en/finance-minister-basil-rajapaksa-holds-bilateral-talks-with-the-external-affairs-minister-of-india-dr-s-jaishankar/	Finance Minister Basil Rajapaksa, during his two-day official visit to New Delhi, held bilateral talks with India's External Affairs Minister Dr. S. Jaishankar on the 16th. The talks took place at the Hyderabad House.	Mission News	2025-09-28 09:13:38.752259
290	19	Finance Minister Basil Rajapaksa calls on Prime Minister Narendra Modi	24.03.2022	https://mfa.gov.lk/en/finance-minister-basil-rajapaksa-calls-on-prime-minister-narendra-modi/	Finance Minister Basil Rajapaksa met with Prime Minister Narendra Modi in New Delhi. During the meeting, PM Modi assured that India will always support Sri Lanka as a close and friendly neighbor.	Mission News	2025-09-28 09:13:38.752259
291	19	Sri Lanka participates at “EnviroteQ|AgriteQ 2022” in Doha	23.03.2022	https://mfa.gov.lk/en/sri-lanka-participates-at-enviroteqagriteq-2022-in-doha-2/	Sri Lanka participated in "EnviroteQ|AgriteQ 2022" in Doha for the first time, showcasing its agricultural products in collaboration with the Export Development Board. The event marked Qatar's 9th International Agriculture Exhibition.	Mission News	2025-09-28 09:13:38.752259
292	19	Ambassador Kananathan presents Credentials in Guinea	23.03.2022	https://mfa.gov.lk/en/ambassador-kananathan-presents-credentials-in-guinea/	Sri Lanka High Commissioner in Kenya Veluppillai Kananathan presented his Letter of Credence appointing him as the Ambassador of Sri Lanka to Guinea to President of Guinea Mamady Doumbouya. He will reside in Kenya while serving in this new role.	Mission News	2025-09-28 09:13:38.752259
293	19	Sri Lanka Ambassador meets the Head of Iran-Sri Lanka Parliamentary Friendship Group	23.03.2022	https://mfa.gov.lk/en/sri-lanka-ambassador-meets-the-head-of-iran-sri-lanka-parliamentary-friendship-group/	Sri Lanka Ambassador G.M. Vipulatheja Wishwanath Aponsu met with Abdolnaser Derakhshan, the Head of Iran-Sri Lanka Parliamentary Friendship Group, on March 13, 2022, at the Parliament.	Mission News	2025-09-28 09:13:38.752259
294	19	Sri Lanka strengthens agriculture ties with Bangladesh and FAO	21.03.2022	https://mfa.gov.lk/en/sri-lanka-strengthens-agriculture-ties-with-bangladesh-and-fao/	Sri Lanka's Minister of Agriculture, Mahindananda Aluthgamage, updated delegates at the Ministerial Session of the 36th FAO Regional Conference for Asia and the Pacific in Dhaka. The discussions focused on strengthening agriculture partnerships between Sri Lanka, Bangladesh, and the FAO.	Mission News	2025-09-28 09:13:38.752259
295	19	Steel Giant Baowu Plans a Billion Dollar Investment in Hambantota	18.03.2022	https://mfa.gov.lk/en/steel-giant-baowu-plans-a-billion-dollar-investment-in-hambantota/	Steel giant Baowu plans to invest billions in Hambantota, as discussed during a meeting between the Ambassador of Sri Lanka to China, Dr. Palitha Kohona, and Baowu Steel's senior management in Ma’anshan, Anhui. The investment potential in Sri Lanka is being explored by Baowu Steel.	Mission News	2025-09-28 09:13:38.752259
296	19	High Commissioner Moragoda meets India’s Minister of Power and  New & Renewable Energy to discuss further cooperation	18.03.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-meets-indias-minister-of-power-and-new-renewable-energy-to-discuss-further-cooperation/	Sri Lanka's High Commissioner to India, Milinda Moragoda, met with India's Minister of Power and New & Renewable Energy to discuss enhancing cooperation in the power and renewable energy sector. The meeting aimed to explore opportunities for collaboration between the two countries in these critical areas.	Mission News	2025-09-28 09:13:38.752259
297	19	​High Level Omani Business Delegation Concludes Productive Visit to Sri Lanka	16.03.2022	https://mfa.gov.lk/en/%e2%80%8bhigh-level-omani-business-delegation-concludes-productive-visit-to-sri-lanka/	A 17-member high-level Omani business delegation from the Oman Chamber of Commerce and Industry (OCCI) recently concluded a productive visit to Sri Lanka. The visit, organized by the Sri Lanka Embassy in Oman from 5 to 9 March 2022, aimed to strengthen economic ties between the two countries.	Mission News	2025-09-28 09:13:38.752259
298	19	​“Ceylon Tea” Showcased at Foodex Japan 2022	16.03.2022	https://mfa.gov.lk/en/%e2%80%8bceylon-tea-showcased-at-foodex-japan-2022/	The Sri Lanka Embassy in Japan, with the support of the Sri Lanka Tea Board, highlighted "Ceylon Tea" at Foodex Japan 2022, the 47th International Food and Beverage Exhibition in Tokyo. The event aimed to promote the renowned Ceylon Tea to a global audience, showcasing its quality and unique flavors.	Mission News	2025-09-28 09:13:38.752259
299	19	Ordination of Rev. Suseela of Austria	15.03.2022	https://mfa.gov.lk/en/ordination-of-rev-suseela-of-austria/	Rev. Suseela became the first Austrian national to be ordained in Austria on March 6, 2022, at the Dhamma-Zentrum Nyanaponika. The ordination ceremony was conducted by Most Ven. Dr. Wijayarajapura Seelawansa Thero, the founder and Chief Incumbent of the center.	Mission News	2025-09-28 09:13:38.752259
300	19	Sri Lanka’s unique traditional products in high demand  at the 55th Diplomatic Red Cross Bazaar in Bangkok, Thailand	15.03.2022	https://mfa.gov.lk/en/sri-lankas-unique-traditional-products-in-high-demand-at-the-55th-diplomatic-red-cross-bazaar-in-bangkok-thailand/	Sri Lanka's unique traditional products were in high demand at the 55th Diplomatic Red Cross Bazaar in Bangkok, Thailand. The Sri Lanka Embassy in Thailand, along with the Export Development Board, Spice and Allied Product Marketing Board, and the National Craft Council, organized the event to showcase these sought-after products.	Mission News	2025-09-28 09:13:38.752259
301	19	High Commissioner Moragoda meets the Minister of Petroleum & Natural Gas and Housing & Urban Affairs of India to discuss bilateral energy cooperation	15.03.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-meets-the-minister-of-petroleum-natural-gas-and-housing-urban-affairs-of-india-to-discuss-bilateral-energy-cooperation/	High Commissioner of Sri Lanka to India, Milinda Moragoda, met with India's Minister of Petroleum & Natural Gas and Housing & Urban Affairs, Shri Hardeep Singh Puri, on March 10 to discuss bilateral energy cooperation. The meeting took place at the Ministry of Urban Affairs, focusing on strengthening ties between the two countries in the energy sector.	Mission News	2025-09-28 09:13:38.752259
328	19	Minister of Justice M U M Ali Sabry concludes successful official visit to Singapore	24.02.2022	https://mfa.gov.lk/en/minister-of-justice-m-u-m-ali-sabry-concludes-successful-official-visit-to-singapore/	Minister of Justice M.U.M. Ali Sabry successfully concluded an official visit to Singapore at the invitation of K. Shanmugam, Minister for Home Affairs and Minister for Law. The visit involved leading a high-level delegation from Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
302	19	Officials of the Sri Lanka Deputy High Commission of Chennai discuss possible Agricultural Collaborations with MSSRF	11.03.2022	https://mfa.gov.lk/en/officials-of-the-sri-lanka-deputy-high-commission-of-chennai-discuss-possible-agricultural-collaborations-with-mssrf/	Officials from the Sri Lanka Deputy High Commission in Chennai, led by Deputy High Commissioner Dr. D. Venkateshwaran, held discussions with Professor M. S. Swaminathan at the M. S. Swaminathan Research Foundation (MSSRF) in Chennai regarding potential agricultural collaborations. The meeting aimed to explore opportunities for cooperation between the two entities in the agricultural sector.	Mission News	2025-09-28 09:13:38.752259
303	19	Ambassador Asirwatham discusses Sri Lanka tourism promotion   in the Walloon region with Governor of Namur in Belgium	11.03.2022	https://mfa.gov.lk/en/ambassador-asirwatham-discusses-sri-lanka-tourism-promotion-in-the-walloon-region-with-governor-of-namur-in-belgium/	Ambassador of Sri Lanka to Belgium, Grace Asirwatham, discussed Sri Lanka's tourism promotion in the Walloon region with Denis Mathen, the Governor of Namur Province in Belgium. The meeting took place on 8th March 2022 at the Governor's Residence in Namur, the capital of the French-speaking Walloon region. This meeting aimed to strengthen ties and explore opportunities for promoting tourism between the two regions.	Mission News	2025-09-28 09:13:38.752259
304	19	Sri Lanka attracts visitors at Travel EXPO Ankara	11.03.2022	https://mfa.gov.lk/en/sri-lanka-attracts-visitors-at-travel-expo-ankara/	The Embassy of Sri Lanka in Ankara, Turkey, along with the Sri Lanka Tourism Promotion Bureau, participated in the 5th edition of Travel EXPO Ankara. The travel trade fair took place from March 3 to 6, attracting visitors interested in exploring Sri Lanka's tourism offerings.	Mission News	2025-09-28 09:13:38.752259
305	19	Assumption of duty of new Consul General of Sri Lanka in Jeddah	11.03.2022	https://mfa.gov.lk/en/assumption-of-duty-of-new-consul-general-of-sri-lanka-in-jeddah/	S.M. Falah Alhabshi Mowlana has officially assumed the role of Consul General of Sri Lanka in Jeddah, Saudi Arabia. The ceremony marking the beginning of his duties took place on March 1, 2022.	Mission News	2025-09-28 09:13:38.752259
306	19	Minister of Higher Education, Science, Research and Innovation of Thailand Prof. Dr. Anek Laothamatas assures Sri Lanka’s envoy to accelerate bilateral cooperation	11.03.2022	https://mfa.gov.lk/en/minister-of-higher-education-science-research-and-innovation-of-thailand-prof-dr-anek-laothamatas-assures-sri-lankas-envoy-to-accelerate-bilateral-cooperation/	Minister of Higher Education, Science, Research and Innovation of Thailand, Prof. Dr. Anek Laothamatas, assured Sri Lanka's envoy of accelerating bilateral cooperation. The Ambassador of Sri Lanka to Thailand, C.A. Chaminda I. Colonne, met with the Minister to discuss enhancing collaboration between the two countries.	Mission News	2025-09-28 09:13:38.752259
307	19	Ambassador Manori Unambuwe Presents Credentials to   President Zoran Milanović of the Republic of Croatia	11.03.2022	https://mfa.gov.lk/en/ambassador-manori-unambuwe-presents-credentials-to-president-zoran-milanovic-of-the-republic-of-croatia/	Ambassador Manori Unambuwe, who serves as the Ambassador of Sri Lanka in Germany and is concurrently accredited as the Ambassador to the Republic of Croatia, presented her credentials to President Zoran Milanović on 3 March 2022 at a ceremony held at the O. This formal event marked the official recognition of her role as the Ambassador to Croatia.	Mission News	2025-09-28 09:13:38.752259
308	19	Consul General of Sri Lanka in Shanghai meets with Deputy Director of the Shanghai Foreign Affairs Office	10.03.2022	https://mfa.gov.lk/en/consul-general-of-sri-lanka-in-shanghai-meets-with-deputy-director-of-the-shanghai-foreign-affairs-office/	Consul General Anura Fernando met with Deputy Director General Fu Jihong at the Shanghai Foreign Affairs Office in China on February 23, 2022. The meeting took place in commemoration of the 65th anniversary of the establishment of diplomatic relations between Sri Lanka and China.	Mission News	2025-09-28 09:13:38.752259
309	19	Sri Lankan Batik promoted in Melbourne coinciding with  International Women’s Day 2022	09.03.2022	https://mfa.gov.lk/en/sri-lankan-batik-promoted-in-melbourne-coinciding-with-international-womens-day-2022/	Sri Lankan Batik was promoted in Melbourne to coincide with International Women’s Day 2022. The Consulate General of Sri Lanka in Melbourne, in collaboration with the Committee for Sri Lanka (CFSL), the South Asian Australia Alliance, and the Australia Sri Lanka Business Council, organized a photo shoot to showcase the traditional craft.	Mission News	2025-09-28 09:13:38.752259
310	19	Sri Lanka Tourism promotional booth at the VFS center, Jeddah	09.03.2022	https://mfa.gov.lk/en/sri-lanka-tourism-promotional-booth-at-the-vfs-center-jeddah/	Ambassador of Sri Lanka to the Kingdom of Saudi Arabia, Pakeer Mohideen Amza, inaugurated a Sri Lanka Tourism promotional booth at the VFS Visa Application Center in Jeddah on March 1, 2022. The booth aims to showcase Sri Lanka's tourism offerings to visitors in Saudi Arabia.	Mission News	2025-09-28 09:13:38.752259
311	19	Sri Lanka extends warm welcome to Maldivians and other foreigners  with easing of travel restrictions	08.03.2022	https://mfa.gov.lk/en/sri-lanka-extends-warm-welcome-to-maldivians-and-other-foreigners-with-easing-of-travel-restrictions/	Sri Lanka has extended a warm welcome to Maldivians and other foreigners by easing travel restrictions, including lifting mandatory PCR tests for travelers. The High Commissioner of Sri Lanka to Maldives, A.M.J. Sadiq, emphasized the convenience of these changes during the reopening of travel.	Mission News	2025-09-28 09:13:38.752259
312	19	Continuing the dialogue with major religions in India, Sri Lanka High Commission in New Delhi presents a Sinhala translation of the Holy Quran to the Jamiat Ulama-i-Hind	08.03.2022	https://mfa.gov.lk/en/continuing-the-dialogue-with-major-religions-in-india-sri-lanka-high-commission-in-new-delhi-presents-a-sinhala-translation-of-the-holy-quran-to-the-jamiat-ulama-i-hind/	In an effort to foster dialogue with major religions in India, the Sri Lanka High Commission in New Delhi recently presented a Sinhala translation of the Holy Quran to the Jamiat Ulama-i-Hind on February 28, 2022. This gesture aims to promote understanding and cultural exchange between communities.	Mission News	2025-09-28 09:13:38.752259
313	19	“Expanding Ceylon Tea Market in Iran and Neighbouring Countries”	07.03.2022	https://mfa.gov.lk/en/expanding-ceylon-tea-market-in-iran-and-neighbouring-countries/	The Sri Lanka Embassy in Tehran, in collaboration with the Tea Association of Iran, Tea Exporters Association of Sri Lanka, and Sri Lanka Tea Board, organized a discussion on expanding the Ceylon tea market in Iran and neighboring countries. This initiative aims to promote Ceylon tea and strengthen its presence in the region, fostering trade relations and market growth.	Mission News	2025-09-28 09:13:38.752259
329	19	Evensong at the Westminster Abbey on the occasion of Sri Lanka’s Independence Day	24.02.2022	https://mfa.gov.lk/en/evensong-at-the-westminster-abbey-on-the-occasion-of-sri-lankas-independence-day/	An Evensong was held at Westminster Abbey on February 10, 2022, to mark the 74th Anniversary of Sri Lanka's Independence. The service was attended by the High Commissioner of Sri Lanka to the United Kingdom.	Mission News	2025-09-28 09:13:38.752259
314	19	​The Embassy of Sri Lanka in Moscow facilitates a meeting between a Business Delegation from Sri Lanka and the Moscow Chamber of Commerce and Industry	07.03.2022	https://mfa.gov.lk/en/%e2%80%8bthe-embassy-of-sri-lanka-in-moscow-facilitates-a-meeting-between-a-business-delegation-from-sri-lanka-and-the-moscow-chamber-of-commerce-and-industry/	The Embassy of Sri Lanka in Moscow organized a meeting on February 9, 2022, between a Sri Lankan business delegation and the Moscow Chamber of Commerce and Industry, as well as members of the Russian business community. The meeting aimed to foster collaboration and strengthen ties between the two countries.	Mission News	2025-09-28 09:13:38.752259
315	19	​Pirith Ceremony to Commemorate the 65th of Anniversary of Diplomatic Relations  between Sri Lanka and China	07.03.2022	https://mfa.gov.lk/en/%e2%80%8bpirith-ceremony-to-commemorate-the-65th-of-anniversary-of-diplomatic-relations-between-sri-lanka-and-china/	To commemorate the 65th anniversary of diplomatic relations between Sri Lanka and China, the Sri Lanka-China Buddhist Friendship Association, in collaboration with the Buddhist Association of China, conducted a Pirith Ceremony.	Mission News	2025-09-28 09:13:38.752259
316	19	​The Embassy of Sri Lanka in Beijing and the Chongqing Huayan Culture and Education Foundational International Exchange Center of China explore avenues to strengthen cooperation	07.03.2022	https://mfa.gov.lk/en/%e2%80%8bthe-embassy-of-sri-lanka-in-beijing-and-the-chongqing-huayan-culture-and-education-foundational-international-exchange-center-of-china-explore-avenues-to-strengthen-cooperation/	The Embassy of Sri Lanka in Beijing and the Chongqing Huayan Culture and Education Foundational International Exchange Center of China are exploring ways to enhance cooperation. This initiative coincides with the 65th anniversary of diplomatic relations and the 70th anniversary of the Rubber-Rice Pact, fostering stronger ties between the two countries.	Mission News	2025-09-28 09:13:38.752259
317	19	Embassy of Sri Lanka in Jakarta organizes a Webinar on Reviving the Legacy of Sri Lanka- Indonesia Historical Relations	07.03.2022	https://mfa.gov.lk/en/embassy-of-sri-lanka-in-jakarta-organizes-a-webinar-on-reviving-the-legacy-of-sri-lanka-indonesia-historical-relations/	The Embassy of Sri Lanka in Indonesia, along with the University of Kelaniya and the University of Indonesia, organized a webinar on reviving the legacy of Sri Lanka-Indonesia historical relations on February 24, 2022. The event aimed to explore and strengthen the historical ties between the two countries.	Mission News	2025-09-28 09:13:38.752259
318	19	Sri Lanka Participates in “Foodex Saudi 2022” Exhibition	07.03.2022	https://mfa.gov.lk/en/sri-lanka-participates-in-foodex-saudi-2022-exhibition/	Sri Lanka participated in the "Foodex Saudi 2022" exhibition, organized by the Embassy of Sri Lanka in Riyadh and the Consulate General of Sri Lanka in Jeddah in collaboration with the Sri Lanka Tea Board (SLTB). The event showcased Sri Lanka's presence in Saudi Arabia's international food and beverage industry.	Mission News	2025-09-28 09:13:38.752259
319	19	​High Commissioner Moragoda meets Head of the RSS	07.03.2022	https://mfa.gov.lk/en/%e2%80%8bhigh-commissioner-moragoda-meets-head-of-the-rss/	Sri Lankan High Commissioner to India, Milinda Moragoda, met with the Chief of the Rashtriya Swayamsevak Sangh (RSS), Shri Mohan Bhagwat, on February 24, 2022, at the RSS Headquarters in Na.	Mission News	2025-09-28 09:13:38.752259
320	19	First-ever High Level Omani Business Delegation set to visit Sri Lanka	04.03.2022	https://mfa.gov.lk/en/first-ever-high-level-omani-business-delegation-set-to-visit-sri-lanka/	The Embassy of Sri Lanka in Oman has arranged the first-ever high-level visit of a 17-member Omani business delegation from the Oman Chamber of Commerce and Industry (OCCI). The delegation is led by Eng. Redha Bin Juma Al Saleh, Chairman of OCCI. This visit aims to strengthen business ties between Oman and Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
321	19	​Ambassador Majintha Jayesinghe presents Letter of Credence in Czech Republic	03.03.2022	https://mfa.gov.lk/en/%e2%80%8bambassador-majintha-jayesinghe-presents-letter-of-credence-in-czech-republic/	Ambassador Majintha Jayesinghe presented the Letter of Credence to President Miloš Zeman of the Czech Republic at Prague Castle, accrediting as the Ambassador Extraordinary and Plenipotentiary of Sri Lanka. This formalized Jayesinghe's role as Sri Lanka's ambassador to the Czech Republic.	Mission News	2025-09-28 09:13:38.752259
322	19	Consul General of Sri Lanka in Mumbai pays a Courtesy Call on the Governor of Maharashtra	28.02.2022	https://mfa.gov.lk/en/consul-general-of-sri-lanka-in-mumbai-pays-a-courtesy-call-on-the-governor-of-maharashtra/	Consul General of Sri Lanka in Mumbai, Dr. Valsan Vethody, along with his wife Anitha Vethody, visited the Governor of Maharashtra, Bhagat Singh Koshyari, at the Raj Bhavan, his official residence. The visit was a courtesy call to strengthen diplomatic ties between Sri Lanka and Maharashtra.	Mission News	2025-09-28 09:13:38.752259
323	19	IMPA holds hands with Sri Lanka in Business & Investment Collaborations	25.02.2022	https://mfa.gov.lk/en/impa-holds-hands-with-sri-lanka-in-business-investment-collaborations/	The International Mudaliar and Pillaimar Association (IMPA), a non-profit organization based in Southern India with over 25,000 members globally, is collaborating with Sri Lanka in business and investment ventures. IMPA comprises respected business owners and aims to strengthen partnerships for mutual growth and development.	Mission News	2025-09-28 09:13:38.752259
324	19	Sri Lanka Mission in Japan Organizes an Online Webinar with United Nations Industrial Development Organization (UNIDO) and the B. O. I.	25.02.2022	https://mfa.gov.lk/en/sri-lanka-mission-in-japan-organizes-an-online-webinar-with-united-nations-industrial-development-organization-unido-and-the-b-o-i/	The Embassy of Sri Lanka in Japan hosted an online webinar with over 80 Japanese companies, featuring the United Nations Industrial Development Organization (UNIDO) and the B.O.I. Ambassador Sanjiv Gunasekara emphasized investment synergies between Sri Lanka and Japan during the event.	Mission News	2025-09-28 09:13:38.752259
325	19	Embassy of Sri Lanka Reaches Out to Brazilian Public to Promote Sri Lankan Trade and Tourism in Brazil	24.02.2022	https://mfa.gov.lk/en/embassy-of-sri-lanka-reaches-out-to-brazilian-public-to-promote-sri-lankan-trade-and-tourism-in-brazil/	The Embassy of Sri Lanka in Brazil partnered with the Pátio Brasil Shopping chain to host a promotional event for Sri Lankan trade and tourism at the Pátio Brasil Shopping Mall in Brasilia. This event aimed to reach out to the Brazilian public and boost awareness about Sri Lanka's offerings in trade and tourism.	Mission News	2025-09-28 09:13:38.752259
326	19	The Ambassador of Sri Lanka to Italy Jagath Wellawatte Presents Credentials to the President of the Italian Republic Sergio Mattarella	24.02.2022	https://mfa.gov.lk/en/the-ambassador-of-sri-lanka-to-italy-jagath-wellawatte-presents-credentials-to-the-president-of-the-italian-republic-sergio-mattarella/	Ambassador Jagath Wellawatte of Sri Lanka presented his Letters of Credence to Italian President Sergio Mattarella at the Palazzo del Quirinale in Rome on February 18, 2022. The ceremony marked the official beginning of Ambassador Wellawatte's diplomatic mission in Italy.	Mission News	2025-09-28 09:13:38.752259
330	19	High Commissioner Saroja Sirisena presents Letters of Credence to the President of Ireland	22.02.2022	https://mfa.gov.lk/en/high-commissioner-saroja-sirisena-presents-letters-of-credence-to-the-president-of-ireland/	High Commissioner Saroja Sirisena presented her Letters of Credence to President Michael D Higgins of Ireland on February 16, 2022, at a ceremonial event at the official residence Áras an Uachtaráin. This formal event marked the official beginning of her diplomatic mission in Ireland.	Mission News	2025-09-28 09:13:38.752259
331	19	Embassy of Sri Lanka Launches an Official TikTok Account for the Embassy	22.02.2022	https://mfa.gov.lk/en/embassy-of-sri-lanka-launches-an-official-tiktok-account-for-the-embassy/	The Embassy of Sri Lanka has launched an official TikTok account to mark the 65th anniversary of diplomatic relations and the 70th anniversary of the Rubber-Rice Pact. The initiative is in collaboration with CITS Overseas Economic Co., providing a new platform for engaging with audiences.	Mission News	2025-09-28 09:13:38.752259
332	19	Food Security in Southern African Countries: An Initiative by the Sri Lanka High Commission in Pretoria to Popularize Jackfruit Cultivation	21.02.2022	https://mfa.gov.lk/en/food-security-in-southern-african-countries-an-initiative-by-the-sri-lanka-high-commission-in-pretoria-to-popularize-jackfruit-cultivation/	The Sri Lanka High Commission in Pretoria has proposed a plan to promote jackfruit cultivation in Southern African countries to address food security issues. The initiative aims to showcase the benefits of growing jackfruit as a solution to hunger, with a concept paper submitted to UNICEF and FAO in South Africa.	Mission News	2025-09-28 09:13:38.752259
333	19	Sri Lanka’s 74th Independence Day celebrated in the Philippines	21.02.2022	https://mfa.gov.lk/en/sri-lankas-74th-independence-day-celebrated-in-the-philippines/	The Embassy of Sri Lanka in Manila celebrated Sri Lanka's 74th Independence Day at the Official Residence with a solemn ceremony. The event began with the hoisting of the national flag and singing of the national anthem. Sri Lanka's Independence Day was commemorated in the Philippines with dignity and respect.	Mission News	2025-09-28 09:13:38.752259
334	19	Links Established between Turkish Aerospace and General Sir John Kotelawala Defense University of Sri Lanka	21.02.2022	https://mfa.gov.lk/en/links-established-between-turkish-aerospace-and-general-sir-john-kotelawala-defense-university-of-sri-lanka/	Turkish Aerospace and General Sir John Kotelawala Defense University of Sri Lanka established links through a productive virtual discussion. The Vice Chancellor of KDU, Maj. Gen Milinda Peiris, engaged with the President of the Turkish Aerospace Industry Academy. This collaboration aims to foster cooperation between the two institutions.	Mission News	2025-09-28 09:13:38.752259
335	19	Sri Lanka Embassy gifts Books authored by Sri Lankan writers to the Abdul Hameed Shoman Public Library	18.02.2022	https://mfa.gov.lk/en/sri-lanka-embassy-gifts-books-authored-by-sri-lankan-writers-to-the-abdul-hameed-shoman-public-library/	The Sri Lanka Embassy in Jordan gifted a collection of ninety-two Children’s Books authored by Sri Lankan writers to the Children’s section of the Abdul Hameed Shoman Public Library as part of their cultural diplomacy initiatives.	Mission News	2025-09-28 09:13:38.752259
336	19	Sri Lanka High Commission in Malaysia celebrates the 74th anniversary of the Independence of Sri Lanka	18.02.2022	https://mfa.gov.lk/en/sri-lanka-high-commission-in-malaysia-celebrates-the-74th-anniversary-of-the-independence-of-sri-lanka/	The Sri Lanka High Commission in Malaysia celebrated the 74th anniversary of Sri Lanka's Independence with a flag hoisting ceremony at the Chancery premises on February 4, 2022. The event was elegant and modest, marking the significant milestone in Sri Lanka's history.	Mission News	2025-09-28 09:13:38.752259
337	19	Sri Lanka Embassy in Iran organizers a Sports Cooperation Event in Tehran	18.02.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-iran-organizers-a-sports-cooperation-event-in-tehran/	The Sri Lanka Embassy in Tehran, in collaboration with the Tennis Federation of Iran, hosted a Sports Cooperation event at its Chancery premises on February 10, 2022. The event aimed to strengthen sports ties between Sri Lanka and Iran.	Mission News	2025-09-28 09:13:38.752259
338	19	Independence Day Celebrations in Singapore	15.02.2022	https://mfa.gov.lk/en/independence-day-celebrations-in-singapore/	The 74th anniversary of Sri Lanka's independence was celebrated in Singapore at the High Commission of Sri Lanka with the participation of staff. The event featured a simple ceremony to mark the occasion.	Mission News	2025-09-28 09:13:38.752259
339	19	74th Independance Day celebrations by the Sri Lanka Embassy of Abu Dhabi, UAE	14.02.2022	https://mfa.gov.lk/en/74th-independance-day-celebrations-by-the-sri-lanka-embassy-of-abu-dhabi-uae/	The Sri Lanka Embassy in Abu Dhabi celebrated the 74th Anniversary of Sri Lanka’s Independence with an official ceremony at the Chancery premises on February 4, 2022. The event followed health guidelines to ensure safety.	Mission News	2025-09-28 09:13:38.752259
340	19	Sri Lanka and Belarus enhances bilateral cooperation	14.02.2022	https://mfa.gov.lk/en/sri-lanka-and-belarus-enhances-bilateral-cooperation/	Sri Lanka's Ambassador to Russia, Prof. Janitha A. Liyanage, who is also accredited to Belarus, conducted several meetings with Belarusian authorities during her official visit from February 2-5, 2022. The discussions aimed to enhance bilateral cooperation between Sri Lanka and Belarus.	Mission News	2025-09-28 09:13:38.752259
341	19	High Commissioner Moragoda meets Finance Minister of India; Extends appreciation for support to Sri Lanka	14.02.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-meets-finance-minister-of-india-extends-appreciation-for-support-to-sri-lanka/	High Commissioner of Sri Lanka to India, Milinda Moragoda, met with India's Finance and Corporate Affairs Minister, Smt. Nirmala Sitharaman, in New Delhi on February 11. During the meeting, High Commissioner Moragoda expressed appreciation for India's support to Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
342	19	Commemorating the 74th Anniversary of Sri Lanka’s Independence, Ambassador Chaminda Colonne highlights Citizens’ National Responsibility to Work Together to Build their Motherland	14.02.2022	https://mfa.gov.lk/en/commemorating-the-74th-anniversary-of-sri-lankas-independence-ambassador-chaminda-colonne-highlights-citizens-national-responsibility-to-work-together-to-build-their-mothe/	Ambassador Chaminda Colonne, Sri Lanka's Ambassador to Thailand and Permanent Representative to UNESCAP, highlighted citizens' national responsibility to work together in commemorating the 74th Anniversary of Sri Lanka's Independence. The Ambassador, along with his spouse and Embassy staff, proudly celebrated the occasion.	Mission News	2025-09-28 09:13:38.752259
343	19	​Sri Lanka Embassy in Ethiopia Celebrates 74th Anniversary of Independence	14.02.2022	https://mfa.gov.lk/en/%e2%80%8bsri-lanka-embassy-in-ethiopia-celebrates-74th-anniversary-of-independence/	The Sri Lanka Embassy in Ethiopia celebrated the 74th anniversary of Sri Lanka's independence on February 4, 2022, with the participation of mission staff and their families at the Embassy premises. The event marked a significant milestone in honoring Sri Lanka's independence.	Mission News	2025-09-28 09:13:38.752259
344	19	World Growth Forum Magazine Selects Ambassador of Sri Lanka to Oman Ameer Ajwad as “Person of the Year 2021” for Diplomacy and Bilateral Relations	14.02.2022	https://mfa.gov.lk/en/world-growth-forum-magazine-selects-ambassador-of-sri-lanka-to-oman-ameer-ajwad-as-person-of-the-year-2021-for-diplomacy-and-bilateral-relations/	Ambassador Ameer Ajwad of Sri Lanka to Oman has been named "Person of the Year 2021" by World Growth Forum Magazine for his contributions to diplomacy and bilateral relations. The prestigious recognition highlights his significant achievements in fostering international cooperation.	Mission News	2025-09-28 09:13:38.752259
345	19	74th Anniversary of Independence Day Celebration 2022 Embassy of Sri Lanka in Paris, France	12.02.2022	https://mfa.gov.lk/en/74th-anniversary-of-independence-day-celebration-2022-embassy-of-sri-lanka-in-paris-france/	The Embassy of Sri Lanka in Paris celebrated the 74th Anniversary of Independence Day of the Democratic Socialist Republic of Sri Lanka with a ceremony at the Embassy premises. The event was attended by various dignitaries and officials.	Mission News	2025-09-28 09:13:38.752259
346	19	High Commissioner- designate of Sri Lanka to Malaysia presents the open copy of the letter of credentials	11.02.2022	https://mfa.gov.lk/en/high-commissioner-designate-of-sri-lanka-to-malaysia-presents-the-open-copy-of-the-letter-of-credentials/	On February 7, 2022, Sri Lanka's High Commissioner-designate to Malaysia, Air Chief Marshal Sumangala Dias, presented the open copy of his letter of credentials to Chief of Protocol Datuk Wan Zaidi Bin Ab. This formal exchange signifies the official recognition of his diplomatic role in Malaysia.	Mission News	2025-09-28 09:13:38.752259
347	19	74th Independence Day of Sri Lanka commemorated in Dhaka	11.02.2022	https://mfa.gov.lk/en/74th-independence-day-of-sri-lanka-commemorated-in-dhaka/	The 74th Independence Day of Sri Lanka was celebrated on February 4, 2022, at the Sri Lanka High Commission in Dhaka, Bangladesh, with the High Commissioner and Mission staff in attendance. The event marked a significant commemoration of Sri Lanka's independence.	Mission News	2025-09-28 09:13:38.752259
348	19	Ambassador Amza meets Secretary  General of GCC	11.02.2022	https://mfa.gov.lk/en/ambassador-amza-meets-secretary-general-of-gcc/	Ambassador of Sri Lanka to Saudi Arabia, P.M. Amza, met with the Secretary General of the Gulf Cooperation Council (GCC), Dr. Nayef Falah M. Al Hajraf, at the Council Headquarters in Riyadh on February 8, 2022. The meeting aimed to discuss bilateral relations and cooperation between Sri Lanka and the GCC.	Mission News	2025-09-28 09:13:38.752259
349	19	Ambassador Ameer Ajwad Plants Sri Lankan Fruit Sapling in Muscat to mark the 74th Independence Day of Sri Lanka	11.02.2022	https://mfa.gov.lk/en/ambassador-ameer-ajwad-plants-sri-lankan-fruit-sapling-in-muscat-to-mark-the-74th-independence-day-of-sri-lanka/	Ambassador Ameer Ajwad of Sri Lanka planted a "wood apple fruit" sapling in Muscat to celebrate Sri Lanka's 74th Independence Day. The sapling was planted at the Directorate General of Agricultural and Animal Research in Rumais, Barka.	Mission News	2025-09-28 09:13:38.752259
350	19	Sri Lanka and Nepal continue collaborations in the construction sector	10.02.2022	https://mfa.gov.lk/en/sri-lanka-and-nepal-continue-collaborations-in-the-construction-sector/	Sri Lanka Embassy in Nepal and the Export Development Board of Sri Lanka organized a virtual meeting for Sri Lankan Construction Companies to engage with the Nepal Ministry of Physical Infrastructure. The collaboration aims to strengthen ties and explore opportunities in the construction sector between the two countries.	Mission News	2025-09-28 09:13:38.752259
351	19	Ceremony to Mark the 74th Independence Day of Sri Lanka in Toronto	10.02.2022	https://mfa.gov.lk/en/ceremony-to-mark-the-74th-independence-day-of-sri-lanka-in-toronto/	The Consulate General of Sri Lanka in Toronto organized a small ceremony at the Consulate premises on 4 February, 2022, to mark the 74th Independence Day of Sri Lanka. The event was attended by staff members to commemorate the occasion.	Mission News	2025-09-28 09:13:38.752259
352	19	High Commissioner Navaratne invites Sri Lankan Canadians interested in Peace and Reconciliation for a dialogue on the occasion of 74th Independence Day of Sri Lanka	09.02.2022	https://mfa.gov.lk/en/high-commissioner-navaratne-invites-sri-lankan-canadians-interested-in-peace-and-reconciliation-for-a-dialogue-on-the-occasion-of-74th-independence-day-of-sri-lanka/	High Commissioner Navaratne of Sri Lanka invited Sri Lankan Canadians interested in Peace and Reconciliation for a dialogue on the 74th Independence Day of Sri Lanka. The celebration took place virtually in Ottawa, Canada on February 4, 2022, with the participation of the Diplomatic Corps, Sri Lankan expatriates, and staff.	Mission News	2025-09-28 09:13:38.752259
353	19	Sri Lanka Deputy High Commission in Chennai Celebrates the 74th Independence Day of Sri Lanka	09.02.2022	https://mfa.gov.lk/en/sri-lanka-deputy-high-commission-in-chennai-celebrates-the-74th-independence-day-of-sri-lanka/	The Sri Lanka Deputy High Commission in Chennai celebrated the 74th Independence Day of Sri Lanka on February 4, 2022, at the Chancery premises. The event took place amidst the ongoing pandemic situation in the region.	Mission News	2025-09-28 09:13:38.752259
354	19	The Embassy of Sri Lanka in Doha celebrates the 74th Anniversary of Independence of Sri Lanka	09.02.2022	https://mfa.gov.lk/en/the-embassy-of-sri-lanka-in-doha-celebrates-the-74th-anniversary-of-independence-of-sri-lanka/	The Embassy of Sri Lanka in Doha, Qatar celebrated the 74th Anniversary of Sri Lanka's Independence on February 4, 2022, with the participation of embassy staff at the embassy premises. The event marked a significant milestone in honoring Sri Lanka's independence.	Mission News	2025-09-28 09:13:38.752259
355	19	Ambassador–designate of Sri Lanka to Italy presents the open copy of the Letter of Credentials to the Foreign Ministry in Rome	09.02.2022	https://mfa.gov.lk/en/ambassador-designate-of-sri-lanka-to-italy-presents-the-open-copy-of-the-letter-of-credentials-to-the-foreign-ministry-in-rome/	Ambassador-designate of Sri Lanka to Italy, Jagath Wellawatte, presented the open copy of his Letter of Credentials to Chief of Protocol Ambassador Inigo Lambertini at the Foreign Ministry in Rome. This formalizes his appointment and marks the beginning of his diplomatic mission in Italy.	Mission News	2025-09-28 09:13:38.752259
356	19	Consulate General in Jeddah Celebrates the 74th Independence Day of Sri Lanka	08.02.2022	https://mfa.gov.lk/en/consulate-general-in-jeddah-celebrates-the-74th-independence-day-of-sri-lanka/	The Consulate General in Jeddah celebrated Sri Lanka's 74th Independence Day with a flag hoisting ceremony on February 4, 2022. The event was limited to the consulate staff.	Mission News	2025-09-28 09:13:38.752259
357	19	The Permanent Mission of Sri Lanka to the United Nations in New York celebrates the 74th Anniversary of Independence of Sri Lanka	08.02.2022	https://mfa.gov.lk/en/the-permanent-mission-of-sri-lanka-to-the-united-nations-in-new-york-celebrates-the-74th-anniversary-of-independence-of-sri-lanka/	The Permanent Mission of Sri Lanka to the United Nations in New York celebrated the 74th Anniversary of Sri Lanka's Independence virtually due to the COVID-19 pandemic. The event was held in New York City.	Mission News	2025-09-28 09:13:38.752259
358	19	Foreign Minister Prof. G.L. Peiris concludes successful visit to New Delhi	08.02.2022	https://mfa.gov.lk/en/fm-new-delhi/	Foreign Minister of Sri Lanka Prof. G.L. Peiris successfully concluded a two-day official visit to New Delhi on February 6-8, 2022. This visit marked his first trip to India since taking office.	Mission News	2025-09-28 09:13:38.752259
359	19	Sri Lanka continues as Vice Chair of the Board of Trustees (BOT) of Asian Disaster Preparedness Centre (ADPC)	07.02.2022	https://mfa.gov.lk/en/sri-lanka-continues-as-vice-chair-of-the-board-of-trustees-bot-of-asian-disaster-preparedness-centre-adpc/	Sri Lanka's Ambassador to Thailand, C. A. Chaminda I. Colonne, has been re-elected as Vice Chair of the Board of Trustees of the Asian Disaster Preparedness Centre (ADPC). This marks his continued role in overseeing disaster preparedness initiatives at the organization.	Mission News	2025-09-28 09:13:38.752259
360	19	​Refuting the allegation of “Tamil Genocide” in the final phase of the conflict in Sri Lanka	07.02.2022	https://mfa.gov.lk/en/tamil-genocide-sl/	The term genocide is used to describe one of the gravest crimes against humanity, involving specific acts committed with the intent to destroy a national, ethnical, racial, or religious group. Refuting the allegation of "Tamil Genocide" in the final phase of the conflict in Sri Lanka is crucial for addressing historical and political narratives accurately.	Mission News	2025-09-28 09:13:38.752259
361	19	Sri Lanka assures enhanced partnership with the Asian Institute of Technology (AIT)	04.02.2022	https://mfa.gov.lk/en/sri-lanka-assures-enhanced-partnership-with-the-asian-institute-of-technology-ait/	Sri Lanka's Ambassador to Thailand, C.A. Chaminda I. Colonne, has been elected as Co-Chairperson of the Student Relations Committee at the Asian Institute of Technology's Board of Trustees Meeting. This appointment signifies Sri Lanka's commitment to enhancing its partnership with AIT.	Mission News	2025-09-28 09:13:38.752259
362	19	​Appointment of High Commissioner of the Islamic Republic of Pakistan to Sri Lanka	03.02.2022	https://mfa.gov.lk/en/pakistan-sl/	The Government of Pakistan, with the approval of Sri Lanka, has named Maj. Gen. (Rtd) Umar Farooq Burki as the new High Commissioner of Pakistan to Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
363	19	High Commissioner-designate of Sri Lanka to Malaysia assumes duties	03.02.2022	https://mfa.gov.lk/en/high-commissioner-designate-of-sri-lanka-to-malaysia-assumes-duties/	Air Chief Marshal Sumangala Dias, the newly appointed High Commissioner-designate of Sri Lanka to Malaysia, assumed duties at the Sri Lanka High Commission in Kuala Lumpur on 27 January 2022. He officially began his role at the High Commission, representing Sri Lanka in Malaysia.	Mission News	2025-09-28 09:13:38.752259
364	19	Sri Lanka’s Envoy to Maldives presents credentials to President Solih	03.02.2022	https://mfa.gov.lk/en/sri-lankas-envoy-to-maldives-presents-credentials-to-president-solih/	Sri Lanka's High Commissioner-designate to Maldives, A.M.J. Sadiq, presented his credentials to Maldives President Ibrahim Mohamed Solih. He handed over his Letter of Credence and the Letter of Recall of his predecessor during the ceremony.	Mission News	2025-09-28 09:13:38.752259
365	19	Sri Lankan State Minister of Batik, Handloom and Local Apparel Products Explores Opportunities in Russia	02.02.2022	https://mfa.gov.lk/en/sri-lankan-state-minister-of-batik-handloom-and-local-apparel-products-explores-opportunities-in-russia/	Sri Lankan State Minister of Batik, Handloom, and Local Apparel Products, along with a delegation led by Ambassador Prof. Janitha Abeywickrema Liyanage, recently explored business opportunities in Russia on January 24, 2022. The visit aimed to strengthen trade relations between the two countries in the textile and apparel sector.	Mission News	2025-09-28 09:13:38.752259
366	19	Embassy of Sri Lanka in Japan Organizes Live Sri Lankan Cuisine Competition for Japanese People	02.02.2022	https://mfa.gov.lk/en/embassy-of-sri-lanka-in-japan-organizes-live-sri-lankan-cuisine-competition-for-japanese-people/	The Embassy of Sri Lanka in Japan, along with two award-winning Sri Lankan chefs, hosted a Sri Lankan cuisine competition for the Japanese community. The event attracted over 140 applications and featured a live video broadcast. It aimed to promote Sri Lankan culinary culture among the Japanese audience.	Mission News	2025-09-28 09:13:38.752259
367	19	High Commissioner Moragoda stresses the importance of developing eight thrust areas to elevate Sri Lanka- India economic relations to a strategic level	31.01.2022	https://mfa.gov.lk/en/high-commissioner-moragoda-stresses-the-importance-of-developing-eight-thrust-areas-to-elevate-sri-lanka-india-economic-relations-to-a-strategic-level/	Sri Lanka's High Commissioner to India, Milinda Moragoda, emphasized the need to focus on eight key areas to enhance Sri Lanka-India economic relations to a strategic level. This shift aims to move the relationship beyond a transactional phase towards a more strategic partnership.	Mission News	2025-09-28 09:13:38.752259
368	19	Ambassador Ameer Ajwad meets the Minister of Agriculture, Fisheries and Water Resource of Oman	31.01.2022	https://mfa.gov.lk/en/ambassador-ameer-ajwad-meets-the-minister-of-agriculture-fisheries-and-water-resource-of-oman/	Ambassador Ameer Ajwad of Sri Lanka met with Dr. Saoud Hamood Ahmed Al Habsi, the Minister of Agriculture, Fisheries, and Water Resources of Oman, to discuss collaboration opportunities. They explored ways to enhance bilateral cooperation in these sectors during their meeting.	Mission News	2025-09-28 09:13:38.752259
369	19	High Commissioner – designate of Sri Lanka to Maldives presents the open copy of the letter of credentials to the Foreign Ministry in Malé	29.01.2022	https://mfa.gov.lk/en/high-commissioner-designate-of-sri-lanka-to-maldives-presents-the-open-copy-of-the-letter-of-credentials-to-the-foreign-ministry-in-male/	The High Commissioner-designate of Sri Lanka to Maldives, A.M.J. Sadiq, presented the open copy of his letter of credentials to the Foreign Ministry in Malé upon his arrival on January 25, 2022. He assumed duties at the High Commission of Sri Lanka in Malé on the same day following a simple ceremony attended by staff.	Mission News	2025-09-28 09:13:38.752259
370	19	Sri Lankas Representative to Palestine meets with Minister of Health of the State of Palestine, Dr. Mai Al-Kailah	28.01.2022	https://mfa.gov.lk/en/sri-lankas-representative-to-palestine-meets-with-minister-of-health-of-the-state-of-palestine-dr-mai-al-kailah/	Sri Lanka's Representative to Palestine, Nawalage Bennet Cooray, met with the Minister of Health of the State of Palestine, Dr. Mai Al-Kailah, in Ramallah on January 20, 2022. They discussed the Covid-19 situations in both Sri Lanka and Palestine during the meeting.	Mission News	2025-09-28 09:13:38.752259
371	19	Ambassador Prof. Kshanika Hirimburegama presented Credentials to the President of the Portuguese Republic Marcelo Rebelo de Sousa	27.01.2022	https://mfa.gov.lk/en/ambassador-prof-kshanika-hirimburegama-presented-credentials-to-the-president-of-the-portuguese-republic-marcelo-rebelo-de-sousa/	Ambassador Prof. Kshanika Hirimburegama presented her credentials to the President of the Portuguese Republic, Marcelo Rebelo de Sousa, at a ceremony on January 17, 2022, at the Ajuda National Palace in Lisbon, Portugal. This formal event marked the official beginning of her diplomatic duties in Portugal.	Mission News	2025-09-28 09:13:38.752259
372	19	State Minister Tharaka Balasuriya, inaugurates the virtual B2B matchmaking session between Sri Lankan and Ukrainian business community	27.01.2022	https://mfa.gov.lk/en/state-minister-tharaka-balasuriya-inaugurates-the-virtual-b2b-matchmaking-session-between-sri-lankan-and-ukrainian-business-community/	State Minister of Regional Cooperation Tharaka Balasuriya inaugurated a virtual B2B matchmaking session between the Sri Lankan and Ukrainian business communities. The session was organized by the Ceylon Chamber of Commerce and the Ukrainian Chamber of Commerce.	Mission News	2025-09-28 09:13:38.752259
373	19	Thai Pongal celebrations at the High Commission of Sri Lanka in Singapore	27.01.2022	https://mfa.gov.lk/en/thai-pongal-celebrations-at-the-high-commission-of-sri-lanka-in-singapore/	The Thai Pongal festival was celebrated at the Sri Lanka High Commission in Singapore on Thursday, 20 January 2022. Representatives from the Singapore Ceylon Tamils Association and the Sri Senpa were in attendance. The event marked a joyous celebration of Thai Pongal at the High Commission premises.	Mission News	2025-09-28 09:13:38.752259
374	19	Sri Lankans living in KSA donate medical equipments	27.01.2022	https://mfa.gov.lk/en/sri-lankans-living-in-ksa-donate-medical-equipments/	Sri Lankans living in KSA donated medical equipment to Sri Lanka through the coordination of the Embassy of Sri Lanka in Riyadh and with the support of Sri Lankan Airlines on January 20, 2022. The donated equipment was contributed by the Sri Lankan community living in KSA.	Mission News	2025-09-28 09:13:38.752259
375	19	Religious Observances held in Milan to Bestow Merit on The Late Consul General Visharada Neela Wickramasinghe	24.01.2022	https://mfa.gov.lk/en/religious-observances-in-milan-for-the-late-consul-general-visharada-neela-wickramasinghe/	Religious observances were conducted at the Casa Funeraria Funeral Home in Milan, Italy on Saturday, January 22, 2022, to honor the late Consul General Visharada Neela Wickramasinghe, who passed away in Italy. The event aimed to bestow merit on the late Consul General for his contributions and service.	Mission News	2025-09-28 09:13:38.752259
376	19	Sri Lankan Sapphires Highlighted at the Sri Lanka Embassy in China	24.01.2022	https://mfa.gov.lk/en/sri-lankan-sapphires-highlighted-at-the-sri-lanka-embassy-in-china/	Sri Lankan gemstones, including blue sapphires, were featured at a prestigious event held at the Sri Lanka Embassy in Beijing on January 17, 2022. The showcase was sponsored by 'LARWINER - Gem Art Jewellery', highlighting the beauty of Sri Lankan sapphires to attendees.	Mission News	2025-09-28 09:13:38.752259
377	19	Ambassador Grace Asirwatham receives State and Government Sector Award at Top 50 Professional & Career Women Awards	20.01.2022	https://mfa.gov.lk/en/ambassador-grace-asirwatham-receives-state-and-government-sector-award-at-top-50-professional-career-women-awards/	Ambassador Grace Asirwatham received the 2021 State and Government Sector Award at the 11th Edition of the Top 50 Professional & Career Women Awards in Sri Lanka and the Maldives on January 18, 2022.	Mission News	2025-09-28 09:13:38.752259
378	19	Omani Business Fraternity invited to the Exhibition of Sri Lanka Export Brands at Dubai Expo in February 2022	20.01.2022	https://mfa.gov.lk/en/omani-business-fraternity-invited-to-the-exhibition-of-sri-lanka-export-brands-at-dubai-expo-in-february-2022/	The Omani business fraternity has been invited to the Exhibition of Sri Lanka Export Brands at Dubai Expo, taking place from 17 to 20 February 2022. The event aims to showcase Sri Lankan exports and foster business connections between the two countries.	Mission News	2025-09-28 09:13:38.752259
379	19	High Commissioner of Sri Lanka to the UK addresses the Conservative Foreign and Commonwealth Council	20.01.2022	https://mfa.gov.lk/en/high-commissioner-of-sri-lanka-to-the-uk-addresses-the-conservative-foreign-and-commonwealth-council/	Saroja Sirisena, the High Commissioner of Sri Lanka to the UK, spoke at the Conservative Foreign and Commonwealth Council at the Carlton Club on January 12, 2022. The theme of her address was 'Sri Lanka, the Commonwealth, and Global Britain.	Mission News	2025-09-28 09:13:38.752259
380	19	Collaboration and partnership in the ICT sector between Sri Lanka and Indonesia	19.01.2022	https://mfa.gov.lk/en/collaboration-and-partnership-in-the-ict-sector-between-sri-lanka-and-indonesia/	The Sri Lanka Embassy in Jakarta facilitated two interactive sessions on January 13, 2022, bringing together authorities from Sri Lanka and Indonesia to explore collaboration and partnerships in the ICT sector. The discussions aimed to strengthen ties and foster cooperation between the two countries in the field of information and communication technology.	Mission News	2025-09-28 09:13:38.752259
381	19	Sri Lanka Mission in Tokyo celebrates “Thai Pongal” Festival	19.01.2022	https://mfa.gov.lk/en/sri-lanka-mission-in-tokyo-celebrates-thai-pongal-festival/	The Sri Lanka Mission in Tokyo celebrated the "Thai Pongal" festival in a hybrid format in collaboration with the Sri Lanka Students Association in Japan on January 13, 2022, at the Mission premises. The event began with a short introduction and brought together attendees to mark the occasion.	Mission News	2025-09-28 09:13:38.752259
382	19	MICE Tourism in Sri Lanka promoted in Indonesia	19.01.2022	https://mfa.gov.lk/en/mice-tourism-in-sri-lanka-promoted-in-indonesia/	The Sri Lanka Embassy in Indonesia organized a virtual webinar on January 12, 2022, to promote Sri Lanka as a MICE destination. This initiative is part of the Economic Diplomacy efforts to boost MICE tourism in Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
383	19	High Commissioner of Sri Lanka in the UK meets FCDO Minister of State for South and Central Asia, United Nations and the Commonwealth	18.01.2022	https://mfa.gov.lk/en/high-commissioner-of-sri-lanka-in-the-uk-meets-fcdo-minister-of-state-for-south-and-central-asia-united-nations-and-the-commonwealth/	Sri Lanka's High Commissioner in the UK, Saroja Sirisena, met with the Minister of State for South and Central Asia, United Nations, and the Commonwealth, Lord Ahmad of Wimbledon, at the Foreign, Commonwealth and Development Office. The meeting aimed to discuss matters concerning the regions and organizations they represent.	Mission News	2025-09-28 09:13:38.752259
384	19	Sri Lanka Deputy High Commission in Chennai Celebrates Thai Pongal	18.01.2022	https://mfa.gov.lk/en/sri-lanka-deputy-high-commission-in-chennai-celebrates-thai-pongal/	The Sri Lanka Deputy High Commission in Chennai celebrated Thai Pongal, a four-day festival that expresses gratitude to the Sun, nature, and farm animals for a bountiful harvest. This annual festival takes place in January to coincide with the harvest season.	Mission News	2025-09-28 09:13:38.752259
385	19	Meeting between Prof. Kshanika Hirimburegama & Khondker M.Talha, Ambassador of Bangladesh & Permanent Delegate to UNESCO	14.01.2022	https://mfa.gov.lk/en/meeting-between-prof-kshanika-hirimburegama-khondker-m-talha-ambassador-of-bangladesh-permanent-delegate-to-unesco/	Prof. Kshanika Hirimburegama met with Khondker M. Talha, the Ambassador of Bangladesh and Permanent Delegate to UNESCO, on December 22, 2021, at the Sri Lanka Embassy in Paris. The meeting aimed to discuss collaboration and mutual interests between the two parties.	Mission News	2025-09-28 09:13:38.752259
386	19	​Sri Lankan products and tourism booth draws interest at Dashihui Summit Forum of International Business Cooperation and Public Welfare	14.01.2022	https://mfa.gov.lk/en/%e2%80%8bsri-lankan-products-and-tourism-booth-draws-interest-at-dashihui-summit-forum-of-international-business-cooperation-and-public-welfare/	The Consulate General of Sri Lanka in Guangzhou showcased Sri Lankan food products, tea, handicrafts, and tourism at the Dashihui Summit Forum of International Business Cooperation and Public Welfare. The booth attracted significant interest from attendees, highlighting the appeal of Sri Lankan offerings in the global market.	Mission News	2025-09-28 09:13:38.752259
387	19	The grand celebrations of ‘EXPO National Day of Sri Lanka’ at EXPO 2020, Dubai	11.01.2022	https://mfa.gov.lk/en/the-grand-celebrations-of-expo-national-day-of-sri-lanka-at-expo-2020-dubai/	The grand celebrations of the 'EXPO National Day of Sri Lanka' took place on 3 January 2022 at Al Wasl Plaza during EXPO 2020 in Dubai. The event was attended by a delegation led by Sri Lanka's Foreign Minister, Prof. G.L. Peiris.	Mission News	2025-09-28 09:13:38.752259
388	19	Sri Lanka Ambassador in Thailand invokes blessings at the beginning of 2022	10.01.2022	https://mfa.gov.lk/en/sri-lanka-ambassador-in-thailand-invokes-blessings-at-the-beginning-of-2022/	Sri Lanka's Ambassador in Thailand, C.A. Chaminda I. Colonne, along with his spouse, conducted an almsgiving ceremony to invoke blessings at the start of 2022 before beginning their official duties.	Mission News	2025-09-28 09:13:38.752259
389	19	The Embassy of Sri Lanka in Beijing Commenced Work for 2022 with a Simple Ceremony	06.01.2022	https://mfa.gov.lk/en/the-embassy-of-sri-lanka-in-beijing-commenced-work-for-2022-with-a-simple-ceremony/	The Embassy of Sri Lanka in Beijing started work for 2022 with a simple ceremony attended by all staff members. Ambassador Dr. Palitha Kohona highlighted the Mission's achievements in 2021, including securing 26 million vaccine doses.	Mission News	2025-09-28 09:13:38.752259
390	19	Sri Lanka Embassy in Oman Commences work for the Year 2022 by taking Public Servants’ Oath	05.01.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-oman-commences-work-for-the-year-2022-by-taking-public-servants-oath/	The staff of the Sri Lanka Embassy in Oman started their work for 2022 by taking the oath of allegiance to the public service at a ceremony on January 2, 2022. The ceremony marked the beginning of their official duties for the year.	Mission News	2025-09-28 09:13:38.752259
391	19	Embassy and Permanent Mission of Sri Lanka in Vienna commenced work for 2022	05.01.2022	https://mfa.gov.lk/en/embassy-and-permanent-mission-of-sri-lanka-in-vienna-commenced-work-for-2022/	The Embassy and Permanent Mission of Sri Lanka in Vienna started its operations for 2022 with a ceremony at the Embassy premises. The event included hoisting the National Flag and singing the national anthem. The mission is now fully operational for the year ahead.	Mission News	2025-09-28 09:13:38.752259
392	19	Sri Lanka’s first ever coco peat export to Kenya launched	05.01.2022	https://mfa.gov.lk/en/sri-lankas-first-ever-coco-peat-export-to-kenya-launched/	Sri Lanka has launched its first-ever coco peat export to Kenya, boosting economic activities between the two countries. The initiative gained momentum during the visit of Sri Lankan ministers of Youth and Sports, Development Co-ordination, and Moni.	Mission News	2025-09-28 09:13:38.752259
393	19	Ceremonial Commencement of Work for the New Year 2022- Consulate General of Sri Lanka – Jeddah, Saudi Arabia	04.01.2022	https://mfa.gov.lk/en/ceremonial-commencement-of-work-for-the-new-year-2022-consulate-general-of-sri-lanka-jeddah-saudi-arabia/	The Consulate General of Sri Lanka in Jeddah, Saudi Arabia marked the ceremonial commencement of work for the New Year 2022 with the hoisting of the National Flag and singing of the National Anthem by Acting Consul General T.F.M. Aashiq and staff. The event also included a two-minute silence to honor the occasion.	Mission News	2025-09-28 09:13:38.752259
394	19	The Embassy of Sri Lanka in Paris celebrated the first working day of the 2022 New Year	04.01.2022	https://mfa.gov.lk/en/the-embassy-of-sri-lanka-in-paris-celebrated-the-first-working-day-of-the-2022-new-year/	The Embassy of Sri Lanka in Paris celebrated the first working day of the 2022 New Year with a ceremony at 9:00 am, attended by the Ambassador, Diplomats, and Embassy staff following French health guidelines. The event marked the commencement of the new year activities at the Embassy.	Mission News	2025-09-28 09:13:38.752259
395	19	State Minister Tharaka Balasuriya participates at Sri Lanka – Oman Hockey Tournament organized to mark the 40th Anniversary of Diplomatic Relations	04.01.2022	https://mfa.gov.lk/en/state-minister-tharaka-balasuriya-participates-at-sri-lanka-oman-hockey-tournament-organized-to-mark-the-40th-anniversary-of-diplomatic-relations/	State Minister of Regional Cooperation of Sri Lanka, Tharaka Balasuriya, participated as the guest of honour at the presentation ceremony of the first-ever Sri Lanka-Oman Club Level Hockey Tournament. The event was organized to mark the 40th Anniversary of Diplomatic Relations between the two countries.	Mission News	2025-09-28 09:13:38.752259
396	19	Sri Lanka Embassy in Ankara Celebrates Christmas and New Year with Children with Special needs	03.01.2022	https://mfa.gov.lk/en/sri-lanka-embassy-in-ankara-celebrates-christmas-and-new-year-with-children-with-special-needs/	The Sri Lanka Embassy in Ankara celebrated Christmas and New Year with children at the "Autism Foundation School" in Incek on December 29, 2021. Ambassador M. Rizvi Hassen, along with family and Embassy staff, visited the school for the occasion, spreading joy and festive cheer.	Mission News	2025-09-28 09:13:38.752259
397	19	​Honorary Consuls of Sri Lanka and Sri Lankans living in Ankara donated medical equipment to support GOSL effort	03.01.2022	https://mfa.gov.lk/en/%e2%80%8bhonorary-consuls-of-sri-lanka-and-sri-lankans-living-in-ankara-donated-medical-equipment-to-support-gosl-effort/	Sri Lankans living in Turkey and Honorary Consuls from various cities donated medical equipment to support the Sri Lankan government's efforts in combating Covid-19. The equipment will be used in government hospitals in Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
398	19	Leading Chinese Tour Operators and Agencies will target the Sri Lanka Market when Travel Restrictions are relaxed	03.01.2022	https://mfa.gov.lk/en/leading-chinese-tour-operators-and-agencies-will-target-the-sri-lanka-market-when-travel-restrictions-are-relaxed/	Leading Chinese tour operators and agencies are set to target the Sri Lanka market once travel restrictions are eased. The Embassy of Sri Lanka in Beijing, along with Sri Lankan Airlines, recently hosted a town hall meeting with 60 invited guests, including tour operators. This initiative aims to strengthen tourism ties between China and Sri Lanka.	Mission News	2025-09-28 09:13:38.752259
\.


--
-- Data for Name: attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb (id, entity_attribute_id, percentage, country, number, created_at) FROM stdin;
1	8	17.33	Saudi Arabia	53902	2025-09-28 09:13:34.046646
2	8	25.44	Kuwait	79123	2025-09-28 09:13:34.046646
3	8	11.43	UAE	35563	2025-09-28 09:13:34.046646
4	8	23.13	Qatar	71954	2025-09-28 09:13:34.046646
5	8	3.43	Oman	10669	2025-09-28 09:13:34.046646
6	8	3.02	South Korea	9394	2025-09-28 09:13:34.046646
7	8	3.19	Maldives	9916	2025-09-28 09:13:34.046646
8	8	1.8	Jordan	5597	2025-09-28 09:13:34.046646
9	8	1.08	Bahrain	3370	2025-09-28 09:13:34.046646
10	8	0.41	Lebanon	1284	2025-09-28 09:13:34.046646
11	8	0.62	Malaysia	1941	2025-09-28 09:13:34.046646
12	8	0.52	Israel	1632	2025-09-28 09:13:34.046646
13	8	0.95	Cyprus	2964	2025-09-28 09:13:34.046646
14	8	0.97	Singapore	3007	2025-09-28 09:13:34.046646
15	8	0.52	Seychelles	1606	2025-09-28 09:13:34.046646
16	8	0.16	Bangladesh	499	2025-09-28 09:13:34.046646
17	8	0.16	Hong Kong	511	2025-09-28 09:13:34.046646
18	8	0.08	Mauritius	247	2025-09-28 09:13:34.046646
19	8	0.1	Iraq	301	2025-09-28 09:13:34.046646
20	8	0.02	Kurdistan	77	2025-09-28 09:13:34.046646
21	8	0.06	India	201	2025-09-28 09:13:34.046646
22	8	0.01	Afghanistan	18	2025-09-28 09:13:34.046646
23	8	1.45	Japan	4518	2025-09-28 09:13:34.046646
24	8	0.16	New Zealand	502	2025-09-28 09:13:34.046646
25	8	2.79	Romania	8679	2025-09-28 09:13:34.046646
26	8	0.04	Papua New Guinea	128	2025-09-28 09:13:34.046646
27	8	0.03	Ethiopia	101	2025-09-28 09:13:34.046646
28	8	0.01	Italy	36	2025-09-28 09:13:34.046646
29	8	0.01	Kenya	43	2025-09-28 09:13:34.046646
30	8	0.01	Uganda	26	2025-09-28 09:13:34.046646
31	8	0.03	Pakistan	97	2025-09-28 09:13:34.046646
32	8	0.02	Egypt	47	2025-09-28 09:13:34.046646
33	8	0.01	Fiji	43	2025-09-28 09:13:34.046646
34	8	0.01	Sudan	29	2025-09-28 09:13:34.046646
35	8	0.01	Brunei	17	2025-09-28 09:13:34.046646
36	8	0.02	Vietnam	67	2025-09-28 09:13:34.046646
37	8	0.04	Australia	127	2025-09-28 09:13:34.046646
38	8	0.04	Ireland	132	2025-09-28 09:13:34.046646
39	8	0	Yemen	5	2025-09-28 09:13:34.046646
40	8	0	Libya	5	2025-09-28 09:13:34.046646
41	8	0	United States	7	2025-09-28 09:13:34.046646
42	8	0	China	8	2025-09-28 09:13:34.046646
43	8	0.01	Greece	40	2025-09-28 09:13:34.046646
44	8	0.05	Malta	164	2025-09-28 09:13:34.046646
45	8	0	Myanmar	12	2025-09-28 09:13:34.046646
46	8	0	Botswana	15	2025-09-28 09:13:34.046646
47	8	0.01	Malawi	29	2025-09-28 09:13:34.046646
48	8	0.02	Thailand	52	2025-09-28 09:13:34.046646
49	8	0	South Africa	11	2025-09-28 09:13:34.046646
50	8	0.16	United Kingdom	499	2025-09-28 09:13:34.046646
51	8	0.04	Turkey	138	2025-09-28 09:13:34.046646
52	8	0	Mozambique	13	2025-09-28 09:13:34.046646
53	8	0.03	Lithuania	79	2025-09-28 09:13:34.046646
54	8	0	Angola	6	2025-09-28 09:13:34.046646
55	8	0	Djibouti	4	2025-09-28 09:13:34.046646
56	8	0.03	Canada	100	2025-09-28 09:13:34.046646
57	8	0.16	Russia	509	2025-09-28 09:13:34.046646
58	8	0.32	Other	997	2025-09-28 09:13:34.046646
\.


--
-- Data for Name: attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1 (id, entity_attribute_id, february, march, april, june, july, september, october, country, may, august, november, december, january, created_at) FROM stdin;
1	30	2	16	0	0	2	0	0	Afghanistan	1	0	7	11	0	2025-09-28 09:13:44.12426
2	30	7	10	6	8	4	2	3	Albania	7	2	3	10	21	2025-09-28 09:13:44.12426
3	30	24	31	8	9	10	10	12	Algeria	15	9	11	29	6	2025-09-28 09:13:44.12426
4	30	1	3	0	1	2	0	0	Andorra	2	13	0	3	0	2025-09-28 09:13:44.12426
5	30	0	0	0	0	0	0	0	Antarctica	0	0	0	1	0	2025-09-28 09:13:44.12426
6	30	2	3	2	0	1	3	0	Angola	0	0	0	0	2	2025-09-28 09:13:44.12426
7	30	0	3	1	1	1	0	1	Antigua & Barbuda	2	2	2	1	2	2025-09-28 09:13:44.12426
8	30	25	38	27	7	8	4	17	Argentina	14	4	40	55	29	2025-09-28 09:13:44.12426
9	30	89	74	56	14	25	37	57	Armenia	26	15	86	244	56	2025-09-28 09:13:44.12426
10	30	1688	2359	3508	2511	1974	2309	2106	Australia	1660	1898	2939	5158	2814	2025-09-28 09:13:44.12426
11	30	1054	887	575	109	299	152	239	Austria	189	206	424	619	788	2025-09-28 09:13:44.12426
12	30	75	366	29	9	11	9	15	Azerbaijan	21	37	55	89	65	2025-09-28 09:13:44.12426
13	30	0	0	0	1	0	0	0	Bahamas	0	0	1	0	0	2025-09-28 09:13:44.12426
14	30	49	80	22	42	36	14	28	Bahrain	51	22	19	88	59	2025-09-28 09:13:44.12426
15	30	259	451	155	129	176	338	417	Bangladesh	249	168	511	662	302	2025-09-28 09:13:44.12426
16	30	3	0	0	0	0	1	0	Barbados	1	0	2	6	0	2025-09-28 09:13:44.12426
17	30	823	515	129	34	35	54	143	Belarus	68	46	456	582	736	2025-09-28 09:13:44.12426
18	30	620	761	846	259	1115	316	274	Belgium	212	475	279	512	495	2025-09-28 09:13:44.12426
19	30	0	1	0	0	0	0	0	Belize	0	0	0	0	1	2025-09-28 09:13:44.12426
20	30	0	0	1	0	0	0	0	Benin	0	0	0	0	0	2025-09-28 09:13:44.12426
21	30	11	6	2	3	3	8	5	Bhutan	1	30	31	9	30	2025-09-28 09:13:44.12426
22	30	1	3	8	2	0	3	5	Bolivia	2	2	3	2	6	2025-09-28 09:13:44.12426
23	30	27	28	11	1	0	0	2	Bosnia & Herzegovina	5	4	5	6	15	2025-09-28 09:13:44.12426
24	30	0	0	1	0	3	0	0	Botswana	2	0	0	4	5	2025-09-28 09:13:44.12426
25	30	48	87	135	27	34	40	27	Brazil	42	32	51	97	49	2025-09-28 09:13:44.12426
26	30	0	0	0	0	0	2	1	Brunei Darussalam	1	6	2	4	0	2025-09-28 09:13:44.12426
27	30	547	396	146	13	13	22	18	Bulgaria	15	25	30	113	305	2025-09-28 09:13:44.12426
28	30	0	0	0	0	0	0	0	Burkina Faso	0	0	0	0	1	2025-09-28 09:13:44.12426
29	30	22	2	4	2	14	8	12	Cambodia	6	3	43	20	21	2025-09-28 09:13:44.12426
30	30	1	2	0	0	0	0	1	Cameroon	0	2	0	0	1	2025-09-28 09:13:44.12426
31	30	1958	2989	2083	2308	3458	1552	1625	Canada	2013	2581	1994	2618	1666	2025-09-28 09:13:44.12426
32	30	2	1	1	0	0	0	0	Cape Verde	0	0	0	0	2	2025-09-28 09:13:44.12426
33	30	2	0	0	0	0	0	0	Chad	1	1	0	1	0	2025-09-28 09:13:44.12426
34	30	14	30	12	5	7	7	12	Chile	16	4	23	23	29	2025-09-28 09:13:44.12426
35	30	266	358	261	231	266	637	468	China	242	534	591	635	226	2025-09-28 09:13:44.12426
36	30	28	40	61	12	8	11	23	Colombia	37	20	17	27	20	2025-09-28 09:13:44.12426
37	30	1	2	1	2	0	1	1	Comoros	2	0	1	3	2	2025-09-28 09:13:44.12426
38	30	1	3	1	0	2	1	1	Congo, Republic Of.	0	0	2	0	3	2025-09-28 09:13:44.12426
39	30	11	7	5	1	0	0	0	Costa Rica	1	2	3	6	4	2025-09-28 09:13:44.12426
40	30	0	0	0	0	1	0	0	Cote Divoire	0	0	0	0	0	2025-09-28 09:13:44.12426
41	30	67	73	23	8	13	8	8	Croatia	8	8	21	41	60	2025-09-28 09:13:44.12426
42	30	1	4	7	1	2	0	0	Cuba	1	0	0	2	1	2025-09-28 09:13:44.12426
43	30	25	48	54	17	19	19	19	Cyprus	11	73	28	38	39	2025-09-28 09:13:44.12426
44	30	2055	1802	686	151	217	53	150	Czech Republic	83	95	355	529	1174	2025-09-28 09:13:44.12426
45	30	1217	1187	1307	275	457	164	265	Denmark	295	235	312	551	1013	2025-09-28 09:13:44.12426
46	30	1	1	1	0	0	0	0	Djibouti	3	0	1	0	0	2025-09-28 09:13:44.12426
47	30	4	6	4	0	2	0	2	Dominica	0	3	7	6	3	2025-09-28 09:13:44.12426
48	30	0	0	3	0	0	0	1	Dominican Republic	0	0	1	1	2	2025-09-28 09:13:44.12426
49	30	4	7	4	12	1	5	2	Ecuador	6	3	5	8	2	2025-09-28 09:13:44.12426
50	30	453	445	170	84	136	53	173	Egypt	211	41	137	220	217	2025-09-28 09:13:44.12426
51	30	4	3	3	3	1	1	2	El Salvador	0	3	2	3	0	2025-09-28 09:13:44.12426
52	30	0	0	0	1	0	0	0	Equatorial Guinea	2	0	0	0	0	2025-09-28 09:13:44.12426
53	30	2	1	0	0	0	0	0	Eritrea	3	1	2	1	2	2025-09-28 09:13:44.12426
54	30	285	210	64	5	8	10	58	Estonia	12	2	28	111	185	2025-09-28 09:13:44.12426
55	30	4	5	3	6	3	2	3	Ethiopia	11	0	2	14	3	2025-09-28 09:13:44.12426
56	30	0	6	0	1	3	8	4	Fiji	1	3	3	19	0	2025-09-28 09:13:44.12426
57	30	298	181	169	95	59	28	78	Finland	45	40	77	159	271	2025-09-28 09:13:44.12426
58	30	5699	5741	4035	1717	3567	1201	1540	France	1076	2784	1841	2665	3616	2025-09-28 09:13:44.12426
59	30	0	1	1	0	0	0	0	Gabon	0	0	1	0	0	2025-09-28 09:13:44.12426
60	30	0	0	1	0	0	0	0	Gambia	0	0	0	0	0	2025-09-28 09:13:44.12426
61	30	168	67	28	61	24	28	40	Georgia	64	70	71	65	106	2025-09-28 09:13:44.12426
62	30	7780	9561	6088	2466	3666	2149	2881	Germany	2208	3251	5169	4984	5339	2025-09-28 09:13:44.12426
63	30	3	0	0	1	3	0	0	Ghana	1	2	10	7	2	2025-09-28 09:13:44.12426
64	30	150	102	145	16	40	27	52	Greece	25	49	41	174	78	2025-09-28 09:13:44.12426
65	30	2	0	0	0	0	0	0	Guam	0	0	0	0	0	2025-09-28 09:13:44.12426
66	30	0	3	0	3	2	3	1	Grenada	0	1	0	1	0	2025-09-28 09:13:44.12426
67	30	3	2	8	0	0	0	1	Guatemala	0	0	2	1	0	2025-09-28 09:13:44.12426
68	30	0	0	0	0	0	0	0	Guinea-Bissau	0	0	0	1	0	2025-09-28 09:13:44.12426
69	30	0	4	2	0	0	0	0	Guyana	0	1	1	1	0	2025-09-28 09:13:44.12426
70	30	2	0	0	0	1	2	0	Honduras	0	0	2	2	1	2025-09-28 09:13:44.12426
71	30	0	0	0	0	0	0	0	Hong Kong	0	0	0	1	0	2025-09-28 09:13:44.12426
72	30	0	0	1	0	0	0	0	Haiti	0	0	0	0	0	2025-09-28 09:13:44.12426
73	30	502	508	217	47	42	31	66	Hungary	33	17	136	300	425	2025-09-28 09:13:44.12426
74	30	22	18	21	23	11	2	5	Iceland	4	1	6	29	21	2025-09-28 09:13:44.12426
75	30	12744	23216	8678	6810	6031	6493	8862	India	5562	5340	10167	17350	11751	2025-09-28 09:13:44.12426
76	30	81	112	56	45	30	71	70	Indonesia	72	36	103	134	75	2025-09-28 09:13:44.12426
77	30	303	2235	227	79	35	214	190	Iran	102	88	206	362	260	2025-09-28 09:13:44.12426
78	30	171	236	71	40	98	18	44	Iraq	120	59	39	145	72	2025-09-28 09:13:44.12426
79	30	375	746	603	137	172	52	101	Ireland	191	80	139	243	217	2025-09-28 09:13:44.12426
80	30	1587	1007	1228	212	404	826	557	Israel	150	643	548	1457	707	2025-09-28 09:13:44.12426
81	30	553	730	584	506	650	352	480	Italy	329	937	619	1206	503	2025-09-28 09:13:44.12426
82	30	0	4	2	1	0	1	0	Jamaica	0	1	0	2	2	2025-09-28 09:13:44.12426
83	30	122	226	249	148	169	226	318	Japan	158	294	377	708	92	2025-09-28 09:13:44.12426
84	30	230	363	135	79	242	145	181	Jordan	207	154	177	335	224	2025-09-28 09:13:44.12426
85	30	2821	2598	122	22	12	27	27	Kazakhstan	28	13	95	262	2041	2025-09-28 09:13:44.12426
86	30	19	42	20	12	5	6	15	Kenya	12	9	29	42	19	2025-09-28 09:13:44.12426
87	30	0	3	3	1	1	0	1	Kosovar	0	0	1	1	2	2025-09-28 09:13:44.12426
88	30	204	131	49	45	78	43	58	Kuwait	118	53	41	96	36	2025-09-28 09:13:44.12426
89	30	109	82	22	0	1	9	30	Kyrgyzstan	21	9	30	94	125	2025-09-28 09:13:44.12426
90	30	9	4	0	1	0	3	4	Lao Peoples	0	3	0	3	2	2025-09-28 09:13:44.12426
91	30	209	375	67	12	12	10	39	Latvia	11	6	237	135	192	2025-09-28 09:13:44.12426
92	30	153	200	305	71	108	58	88	Lebanon	123	58	88	267	87	2025-09-28 09:13:44.12426
93	30	0	0	0	1	0	0	0	Lesotho	2	0	0	0	0	2025-09-28 09:13:44.12426
94	30	1	1	0	0	1	0	1	Liberia	1	0	0	0	0	2025-09-28 09:13:44.12426
95	30	8	3	0	0	2	3	5	Libya	0	0	0	8	0	2025-09-28 09:13:44.12426
96	30	1	5	5	0	1	0	2	Liechtenstein	3	0	1	8	1	2025-09-28 09:13:44.12426
97	30	555	466	146	32	52	21	59	Lithuania	50	29	195	158	352	2025-09-28 09:13:44.12426
98	30	33	24	63	5	16	8	9	Luxembourg	6	18	13	27	11	2025-09-28 09:13:44.12426
99	30	29	16	7	0	0	2	4	Macedonia	1	0	3	6	3	2025-09-28 09:13:44.12426
100	30	3	4	6	9	4	3	5	Madagascar	2	8	6	10	2	2025-09-28 09:13:44.12426
101	30	3	0	0	5	0	1	0	Malawi	1	0	2	3	0	2025-09-28 09:13:44.12426
102	30	147	317	244	161	123	207	264	Malaysia	153	135	350	519	159	2025-09-28 09:13:44.12426
103	30	1532	1910	567	1130	1207	1314	1943	Maldives	849	957	1626	3444	2401	2025-09-28 09:13:44.12426
104	30	0	1	0	0	0	0	1	Mali	0	0	1	0	0	2025-09-28 09:13:44.12426
105	30	15	12	34	20	5	41	10	Malta	10	15	5	98	8	2025-09-28 09:13:44.12426
106	30	0	0	1	0	0	0	0	Marshall Islands	0	0	0	0	1	2025-09-28 09:13:44.12426
107	30	1	2	0	0	1	0	0	Mauritania	0	0	1	0	0	2025-09-28 09:13:44.12426
108	30	14	9	12	2	7	7	4	Mauritius	7	3	17	41	7	2025-09-28 09:13:44.12426
109	30	33	43	35	12	18	13	29	Mexico	18	15	33	64	21	2025-09-28 09:13:44.12426
110	30	0	0	0	0	0	0	0	Micronesia	0	0	0	1	0	2025-09-28 09:13:44.12426
111	30	56	14	7	2	1	6	12	Moldova	6	1	20	37	79	2025-09-28 09:13:44.12426
112	30	1	4	3	0	0	0	3	Monaco	0	0	0	31	1	2025-09-28 09:13:44.12426
113	30	22	0	1	1	4	4	3	Mongolia	1	1	1	0	14	2025-09-28 09:13:44.12426
114	30	13	12	9	1	3	0	0	Montenegro	2	1	7	6	5	2025-09-28 09:13:44.12426
115	30	61	90	23	20	19	10	24	Morocco	44	28	42	56	29	2025-09-28 09:13:44.12426
116	30	2	1	0	1	0	3	1	Mozambique	2	0	2	2	0	2025-09-28 09:13:44.12426
117	30	23	19	42	11	16	33	25	Myanmar	16	10	14	27	16	2025-09-28 09:13:44.12426
118	30	0	1	10	0	2	2	0	Namibia	3	0	1	3	2	2025-09-28 09:13:44.12426
119	30	97	186	94	30	25	47	90	Nepal	39	50	126	181	100	2025-09-28 09:13:44.12426
120	30	1232	1422	1575	423	2053	473	559	Netherlands	483	1021	649	956	1141	2025-09-28 09:13:44.12426
121	30	131	246	329	153	239	186	244	New Zealand	181	166	307	572	112	2025-09-28 09:13:44.12426
122	30	0	0	0	1	1	0	0	Nicaragua	0	0	1	0	0	2025-09-28 09:13:44.12426
123	30	3	3	5	0	1	1	1	Nigeria	0	1	1	6	5	2025-09-28 09:13:44.12426
124	30	0	0	0	0	1	0	0	Niger	1	0	0	0	0	2025-09-28 09:13:44.12426
125	30	595	768	587	1021	757	250	257	Norway	192	295	332	408	521	2025-09-28 09:13:44.12426
126	30	127	93	18	35	75	26	58	Oman	47	55	84	157	101	2025-09-28 09:13:44.12426
127	30	691	1256	138	279	241	421	443	Pakistan	214	286	783	898	610	2025-09-28 09:13:44.12426
128	30	27	55	13	21	28	15	23	Palestinian Territories	29	20	39	76	20	2025-09-28 09:13:44.12426
129	30	1	0	0	2	4	1	0	Panama	1	1	0	0	2	2025-09-28 09:13:44.12426
130	30	1	2	1	1	2	3	1	Papua New Guinea	0	1	1	8	0	2025-09-28 09:13:44.12426
131	30	2	0	3	0	0	0	0	Paraguay	0	1	2	1	1	2025-09-28 09:13:44.12426
132	30	12	13	9	1	3	3	4	Peru	10	5	2	14	11	2025-09-28 09:13:44.12426
133	30	157	256	246	97	149	115	162	Philippines	160	125	149	236	109	2025-09-28 09:13:44.12426
134	30	4315	3315	1391	320	344	228	307	Poland	203	261	802	524	3185	2025-09-28 09:13:44.12426
135	30	206	341	295	128	86	95	120	Portugal	64	113	145	156	157	2025-09-28 09:13:44.12426
136	30	17	53	5	9	38	21	15	Qatar	55	9	18	57	4	2025-09-28 09:13:44.12426
137	30	0	1	0	0	0	0	0	Republic Of Zimbabwe	1	1	1	0	6	2025-09-28 09:13:44.12426
138	30	776	517	475	46	64	77	110	Romania	50	117	146	407	528	2025-09-28 09:13:44.12426
139	30	15340	8899	3874	1610	1918	1553	6189	Russian Federation	3202	1426	13820	19963	13478	2025-09-28 09:13:44.12426
140	30	1	0	2	0	0	0	0	Rwanda	0	0	1	2	3	2025-09-28 09:13:44.12426
141	30	8	3	3	2	3	1	4	Saint Kitts And Nevis	6	1	1	10	4	2025-09-28 09:13:44.12426
142	30	0	0	0	0	0	0	0	San Marino	0	0	0	1	0	2025-09-28 09:13:44.12426
143	30	0	0	1	0	3	0	0	Saint Lucia	0	2	1	0	0	2025-09-28 09:13:44.12426
144	30	861	1397	225	281	311	118	212	Saudi Arabia	365	220	471	324	1167	2025-09-28 09:13:44.12426
145	30	0	0	0	3	0	1	1	Senegal	1	1	1	1	1	2025-09-28 09:13:44.12426
146	30	158	147	95	6	9	7	12	Serbia	7	13	27	54	138	2025-09-28 09:13:44.12426
147	30	32	16	30	9	20	27	36	Seychelles	14	29	31	66	37	2025-09-28 09:13:44.12426
148	30	0	2	2	0	1	0	3	Sierra Leone	1	1	0	0	0	2025-09-28 09:13:44.12426
149	30	283	489	289	222	156	262	297	Singapore	209	182	432	720	229	2025-09-28 09:13:44.12426
150	30	515	462	287	47	112	38	87	Slovakia	66	50	199	206	363	2025-09-28 09:13:44.12426
151	30	116	54	106	24	80	6	33	Slovenia	3	9	21	82	68	2025-09-28 09:13:44.12426
152	30	0	0	0	0	1	0	0	Solomon Islands	0	0	0	0	0	2025-09-28 09:13:44.12426
153	30	2	4	1	0	0	1	5	Somalia	1	0	0	3	1	2025-09-28 09:13:44.12426
154	30	161	290	257	76	55	34	58	South Africa-Zuid Afrika	64	51	125	258	73	2025-09-28 09:13:44.12426
155	30	117	200	151	102	87	138	211	South Korea	63	111	237	322	104	2025-09-28 09:13:44.12426
156	30	0	0	0	0	1	0	0	South Sudan	0	0	0	0	0	2025-09-28 09:13:44.12426
157	30	744	1112	1447	1027	1499	1091	799	Spain	692	2148	748	991	597	2025-09-28 09:13:44.12426
158	30	151	156	15	21	65	36	66	Sudan	63	21	32	45	147	2025-09-28 09:13:44.12426
159	30	1	0	2	0	0	0	1	Suriname	0	1	0	0	0	2025-09-28 09:13:44.12426
160	30	2	0	0	0	0	0	0	Swaziland	0	0	0	1	1	2025-09-28 09:13:44.12426
161	30	818	725	464	304	209	145	220	Sweden	104	124	409	892	683	2025-09-28 09:13:44.12426
162	30	1495	1243	1647	665	2207	583	889	Switzerland	570	695	832	1248	1186	2025-09-28 09:13:44.12426
163	30	4	1	1	1	0	0	0	Syrian Arab Republic	0	1	0	1	5	2025-09-28 09:13:44.12426
164	30	23	35	16	50	16	22	24	Taiwan	11	17	59	77	13	2025-09-28 09:13:44.12426
165	30	36	28	0	7	1	5	6	Tajikistan	2	3	11	6	28	2025-09-28 09:13:44.12426
166	30	2	16	6	3	3	2	1	Tanzania	1	2	22	24	3	2025-09-28 09:13:44.12426
167	30	86	156	123	131	84	89	210	Thailand	84	97	282	311	72	2025-09-28 09:13:44.12426
168	30	0	0	0	0	0	0	0	TIMOR-LESTE	0	0	0	2	0	2025-09-28 09:13:44.12426
169	30	0	0	1	0	0	0	0	Togo	1	0	0	0	2	2025-09-28 09:13:44.12426
170	30	0	1	0	0	0	0	0	Tonga	0	0	0	0	0	2025-09-28 09:13:44.12426
171	30	1	3	3	0	0	1	1	Trinidad And Tobago	1	1	2	8	1	2025-09-28 09:13:44.12426
172	30	36	94	28	19	11	9	23	Tunisia	38	11	23	57	30	2025-09-28 09:13:44.12426
173	30	166	290	176	57	57	47	61	Turkey	66	42	154	224	174	2025-09-28 09:13:44.12426
174	30	4	3	2	0	3	0	4	Turkmenistan	2	0	0	9	2	2025-09-28 09:13:44.12426
175	30	1	8	6	9	3	9	2	Uganda	3	2	4	6	3	2025-09-28 09:13:44.12426
176	30	5288	401	158	77	58	69	136	Ukraine	84	68	260	544	7774	2025-09-28 09:13:44.12426
177	30	53	240	51	69	112	53	74	United Arab Emirates	191	110	123	207	64	2025-09-28 09:13:44.12426
178	30	10642	12908	11539	3368	9257	2872	4275	United Kingdom	3723	6776	4506	7879	7442	2025-09-28 09:13:44.12426
179	30	1855	3114	1872	1647	1469	991	1253	United States	1368	1105	2089	3638	1829	2025-09-28 09:13:44.12426
180	30	6	13	10	1	1	1	7	Uruguay	1	2	3	7	1	2025-09-28 09:13:44.12426
181	30	382	563	32	21	13	13	32	Uzbekistan	15	12	30	44	85	2025-09-28 09:13:44.12426
182	30	0	0	0	1	0	0	2	Vanuatu	0	1	2	3	1	2025-09-28 09:13:44.12426
183	30	2	8	4	1	2	1	3	Venezuela	1	0	2	2	4	2025-09-28 09:13:44.12426
184	30	40	46	83	43	22	41	52	Vietnam	34	46	37	58	17	2025-09-28 09:13:44.12426
185	30	26	36	3	13	13	6	8	Yemen	17	21	41	21	24	2025-09-28 09:13:44.12426
186	30	1	1	0	1	0	1	2	Zambia	2	0	1	16	1	2025-09-28 09:13:44.12426
187	30	3	7	6	3	5	0	1	Zimbabwe	13	0	5	7	19	2025-09-28 09:13:44.12426
\.


--
-- Data for Name: attr_cat_333e54f020_db905fd311_2022_cat_333e54f020; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020 (id, entity_attribute_id, port, arrivals, created_at) FROM stdin;
1	32	Katunayake (Bandaranaike International Airport)	1124022	2025-09-28 09:13:44.823922
2	32	Mattala Rajapaksa International Airport	0	2025-09-28 09:13:44.823922
3	32	Galle Harbour	1922	2025-09-28 09:13:44.823922
4	32	Colombo Harbour	1466	2025-09-28 09:13:44.823922
5	32	Others	102	2025-09-28 09:13:44.823922
\.


--
-- Data for Name: attr_cat_382785f270_f19d1a303a_2022_cat_382785f270; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270 (id, entity_attribute_id, purpose, percentage, created_at) FROM stdin;
1	35	Pleasure/Vacation	55.16	2025-09-28 09:13:45.777127
2	35	Visiting Friends and Relatives	26.83	2025-09-28 09:13:45.777127
3	35	Other or not Responded	11.92	2025-09-28 09:13:45.777127
4	35	Business	5.42	2025-09-28 09:13:45.777127
5	35	MICE	2.46	2025-09-28 09:13:45.777127
6	35	Health / Ayurvedic	1.03	2025-09-28 09:13:45.777127
7	35	Sports	0.37	2025-09-28 09:13:45.777127
8	35	Religious	0.05	2025-09-28 09:13:45.777127
9	35	Education	0.05	2025-09-28 09:13:45.777127
10	35	Official	0.02	2025-09-28 09:13:45.777127
\.


--
-- Data for Name: attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387 (id, entity_attribute_id, title, date, link, summary, category, created_at) FROM stdin;
1	20	Revision of Consular Fees	30.12.2022	https://mfa.gov.lk/en/revision-of-consular-fees/	The Consular Affairs Division of the Ministry of Foreign Affairs in Colombo has revised fees for attestation of Certificates/Documents as per the Extraordinary Gazette No 2306/35 dated 16.11.2022. This update affects services provided at both the Colombo and Regional Consular Offices.	Ministry News	2025-09-28 09:13:39.845962
2	20	Repatriation of 152 Sri Lankan Migrants Rescued at Sea	28.12.2022	https://mfa.gov.lk/en/repatriation-of-152-sri-lankan-migrants-rescued-at-sea/	The Ministry of Foreign Affairs of Sri Lanka and the International Organization for Migration (IOM) organized the voluntary return of 152 Sri Lankan migrants rescued at sea. They were flown back to Sri Lanka from Ho Chi Minh City on a chartered flight.	Ministry News	2025-09-28 09:13:39.845962
3	20	Orientation programme for newly appointed Sri Lanka Heads of Mission	27.12.2022	https://mfa.gov.lk/en/newly-appointed-sri-lanka-heads-of-mission/	The Ministry of Foreign Affairs held an orientation programme from December 16 to 23 for fourteen newly appointed Heads of Sri Lanka Missions abroad and two Heads of Post. The programme aimed to prepare them for their roles in representing Sri Lanka internationally.	Ministry News	2025-09-28 09:13:39.845962
4	20	The message of H.E. Ranil Wickremesinghe, President of Sri Lanka for Christmas 2022	25.12.2022	https://mfa.gov.lk/en/the-message-of-h-e-ranil-wickremesinghe-president-of-sri-lanka-for-christmas-2022/	President of Sri Lanka, H.E. Ranil Wickremesinghe, delivered a Christmas message for 2022. The message conveyed warm wishes and festive greetings to the nation.	Ministry News	2025-09-28 09:13:39.845962
5	20	Ministry of Foreign Affairs and Ministry of Tourism and Lands discuss revival of tourism promotion in the current economic context	23.12.2022	https://mfa.gov.lk/en/mfa-tourism-land-discuss/	Minister of Foreign Affairs Ali Sabry met with officials from the Ministry of Tourism and Lands on 21 December 2022 to discuss challenges and strategies for reviving tourism promotion in Sri Lanka's current economic context. The meeting focused on the evolving strategy for Sri Lanka Tourism and the role of the Sri Lanka Missions in promoting tourism.	Ministry News	2025-09-28 09:13:39.845962
6	20	Sri Lanka High Commission in South Africa Organizes a Conference on   the Applicability of South Africa’s TRC to Sri Lanka	19.12.2022	https://mfa.gov.lk/en/sri-lanka-high-commission-in-south-africa-organizes-a-conference-on-the-applicability-of-south-africas-trc-to-sri-lanka/	The Sri Lanka High Commission in South Africa, in partnership with the Lakshman Kadiragamar Institute of International Relations and Strategic Studies (LKI) in Colombo and the South Africa High Commission in Colombo, organized a conference to explore the applicability of South Africa's Truth and Reconciliation Commission (TRC) model to Sri Lanka. The conference aimed to facilitate discussions on transitional justice processes and reconciliation efforts between the two countries.	Ministry News	2025-09-28 09:13:39.845962
7	20	Correction of Recent News Articles relating to Sri Lanka Embassy in Oman	16.12.2022	https://mfa.gov.lk/en/correction-news-oman/	Recent news articles regarding an employee of the Sri Lanka Foreign Employment Bureau stationed at the Sri Lanka Embassy in Oman have caught the Ministry's attention. The Ministry is addressing the inaccuracies in these articles to provide clarity on the situation.	Ministry News	2025-09-28 09:13:39.845962
8	20	Foreign Secretary Aruni Wijewardane delivers Keynote Address at High-Level Segment of Comprehensive Test Ban Treaty (CTBTO) 3rd Science Diplomacy Symposium, Vienna	09.12.2022	https://mfa.gov.lk/en/fssl-ctbto/	Foreign Secretary Aruni Wijewardane delivered the Keynote Address at the High-Level Segment of the 3rd CTBTO Science Diplomacy Symposium in Vienna, upon the invitation of the Comprehensive Test Ban Treaty Organization (CTBTO). The symposium focused on science diplomacy and nuclear non-proliferation efforts.	Ministry News	2025-09-28 09:13:39.845962
9	20	State Minister of Foreign Affairs Tharaka Balasuriya attends 4th Ministerial Meeting of the AIS Forum Bali	09.12.2022	https://mfa.gov.lk/en/smfa-ais-bali-2022/	State Minister of Foreign Affairs Tharaka Balasuriya attended the 4th Ministerial Meeting of the Archipelagic and Island States (AIS) Forum in Bali, Indonesia on December 5-6, 2022. During the meeting, he emphasized the significance and vitality of cooperation among participating nations.	Ministry News	2025-09-28 09:13:39.845962
10	20	Address by the State Minister of Foreign Affairs Tharaka Balasuriya, at the 4th Ministerial Meeting (MM-4) of the Archipelagic and Island States (AIS) Forum on 6 December, 2022	06.12.2022	https://mfa.gov.lk/en/smofa-mm4-ais-2022/	State Minister of Foreign Affairs Tharaka Balasuriya addressed the 4th Ministerial Meeting of the Archipelagic and Island States Forum on December 6, 2022. He expressed appreciation to Excellency Luhut B. Panjaitan and other distinguished delegates for their participation. The meeting aimed to discuss important maritime affairs issues affecting archipelagic and island states.	Ministry News	2025-09-28 09:13:39.845962
11	20	Sri Lanka High Commissioner visits the crew aboard vessel detained by Nigeria	02.12.2022	https://mfa.gov.lk/en/vessel-nigeria/	Sri Lanka's High Commissioner in Kenya, Velupillai Kananathan, recently visited the crew of the vessel M/T Heroic IDUN, which was detained by Nigeria. The visit included High Commissioners and Diplomats from India, Poland, and the Philippines on November 27.	Ministry News	2025-09-28 09:13:39.845962
12	20	Visit of Foreign Minister Ali Sabry to the United States of America	28.11.2022	https://mfa.gov.lk/en/visit-of-mfa-sl-usa/	Foreign Minister Ali Sabry will visit the United States from November 29 to December 4, 2022, at the invitation of U.S. Secretary of State Antony Blinken. The visit aims to strengthen diplomatic ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
13	20	Foreign Minister Ali Sabry addresses the Council of Ministers’ meeting of IORA in Bangladesh	24.11.2022	https://mfa.gov.lk/en/fmsl-iora-bangladesh/	Foreign Minister Ali Sabry addressed the 22nd Meeting of the Council of Ministers of the 23-member Indian Ocean Rim Association (IORA) in Bangladesh. During his speech, he highlighted the significance of collaboration among IORA member states for regional development and cooperation.	Ministry News	2025-09-28 09:13:39.845962
14	20	Statement by the Minister of Foreign Affairs – 22nd Indian Ocean Rim Association (IORA) Council of Ministers’ Meeting (COM) 24 November 2022, Dhaka, Bangladesh	24.11.2022	https://mfa.gov.lk/en/statement-mfa-iora/	The Minister of Foreign Affairs, Dr. A. K. Abdul Momen, chaired the 22nd Indian Ocean Rim Association (IORA) Council of Ministers’ Meeting on 24 November 2022 in Dhaka, Bangladesh. The meeting was attended by the Ministers of Foreign Affairs from IORA member countries and the Secretary General.	Ministry News	2025-09-28 09:13:39.845962
15	20	Foreign Secretary Aruni Wijewardane delivers Keynote Address at the Ceylon Chamber of Commerce Members’ Forum – 2022	23.11.2022	https://mfa.gov.lk/en/fs-ccc-iora-2022/	Foreign Secretary Aruni Wijewardane delivered the Keynote Address at the Ceylon Chamber of Commerce Members’ Forum – 2022 as the Chief Guest. The event took place at the Shangri-La Hotel in Colombo, where he explained the substantive work.	Ministry News	2025-09-28 09:13:39.845962
16	20	Sri Lanka and EU parliamentary delegations review bilateral cooperation in virtual meeting	22.11.2022	https://mfa.gov.lk/en/sl-eu-parliamentary-delegations/	Sri Lanka and EU parliamentary delegations engaged in a virtual meeting to discuss bilateral cooperation. The dialogue took place between a multi-party delegation from the Parliament of Sri Lanka and the Delegation for relations with the countries of South Asia in the European Parliament (DSAS) on Thursday, November 17.	Ministry News	2025-09-28 09:13:39.845962
17	20	Non-Resident High Commissioner of Singapore calls on Minister of Foreign Affairs	16.11.2022	https://mfa.gov.lk/en/nrhc-singapore-mfa/	The Non-Resident High Commissioner of Singapore, Chandra Das, visited Sri Lanka from November 13 to 18 and met with Minister of Foreign Affairs Ali Sabry on November 15 at the Ministry of Foreign Affairs.	Ministry News	2025-09-28 09:13:39.845962
18	20	Saudi Business Delegation calls on Foreign Minister Sabry	14.11.2022	https://mfa.gov.lk/en/saudi-business-delegation-fm/	A Saudi business delegation, led by Sheikh Mohamed Al-Ajlan, met with Foreign Minister Sabry during a fact-finding mission on investments in Sri Lanka. Sheikh Al-Ajlan, Deputy Board Chairman of Ajlan Group and President of the Saudi Chinese Business Council in Saudi Arabia, discussed potential investment opportunities with the Minister.	Ministry News	2025-09-28 09:13:39.845962
19	20	Foreign Ministry convenes a workshop on economic diplomacy	14.11.2022	https://mfa.gov.lk/en/fm-holds-workshop-diplomats/	The Foreign Ministry organized a workshop on economic diplomacy with experts from various government bodies including the Ministry of Finance, Export Development Board, and Sri Lanka Tea Board. The workshop aimed to enhance collaboration and strategies for promoting economic interests internationally.	Ministry News	2025-09-28 09:13:39.845962
20	20	Three Sri Lankans rescued from a fire in a garage in Male, Maldives	12.11.2022	https://mfa.gov.lk/en/3-sl-recuedf-from-fire-male/	Three Sri Lankan nationals were rescued from a fire in a garage in Male, Maldives. The Sri Lanka High Commission in Male reported that they were evacuated by the rescue team following the incident on November 10.	Ministry News	2025-09-28 09:13:39.845962
21	20	Appointment of the Ambassador of the France to Sri Lanka	12.11.2022	https://mfa.gov.lk/en/ambassador-france-sl/	The Government of France, with the agreement of Sri Lanka, has appointed Mr. Jean-Francois Pactet as the new Ambassador of France to Sri Lanka. He will serve as the Ambassador Extraordinary and Plenipotentiary of France in Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
22	20	Appointment of the Ambassador of the Oman to Sri Lanka	12.11.2022	https://mfa.gov.lk/en/ambassador-oman-sl/	The Government of the Sultanate of Oman, in agreement with the Government of Sri Lanka, has appointed Mr. Ahmed Ali Saeed Al Rashdi as the new Ambassador Extraordinary and Plenipotentiary of Oman to Sri Lanka. Mr. Al Rashdi will represent Oman in Sri Lanka in his new diplomatic role.	Ministry News	2025-09-28 09:13:39.845962
23	20	Appointment of the Ambassador of Russian Federation to Sri Lanka	12.11.2022	https://mfa.gov.lk/en/ambassador-russia-sl/	The Government of the Russian Federation, in agreement with the Government of Sri Lanka, has appointed Mr. Levan S. Dzhagaryan as the new Ambassador Extraordinary and Plenipotentiary of the Russian Federation to Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
24	20	Appointment of the Ambassador of Grand Duchy of Luxembourg to Sri Lanka	11.11.2022	https://mfa.gov.lk/en/ambassador-luxembourg-sl/	The Government of the Grand Duchy of Luxembourg, with the approval of the Government of Sri Lanka, has appointed Ms. Peggy Frantzen as the Ambassador Extraordinary and Plenipotentiary of the Grand Duchy of Luxembourg to Sri Lanka. Ms. Frantzen will represent Luxembourg in her new role in Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
25	20	Appointment of the High Commissioner Republic of Ghana to Sri Lanka	11.11.2022	https://mfa.gov.lk/en/high-commissioner-ghana-sl/	The Government of the Republic of Ghana, with the approval of the Government of Sri Lanka, has appointed Mr. Kwaku Asomah-Cheremeh as the High Commissioner of Ghana to Sri Lanka. He will be based in New Delhi for his diplomatic duties.	Ministry News	2025-09-28 09:13:39.845962
26	20	Appointment of the Ambassador of Republic of Paraguay to Sri Lanka	11.11.2022	https://mfa.gov.lk/en/ambassador-of-paraguay-sl/	The Government of the Republic of Paraguay, with the approval of the Government of Sri Lanka, has named Mr. Fleming Raul Duarte as the new Ambassador Extraordinary and Plenipotentiary of Paraguay to Sri Lanka. Mr. Duarte will represent Paraguay in Sri Lanka in his diplomatic role.	Ministry News	2025-09-28 09:13:39.845962
27	20	Appointment of the Ambassador of Kingdom of Bhutan to Sri Lanka	11.11.2022	https://mfa.gov.lk/en/ambassador-of-bhutan-sl/	The Government of the Kingdom of Bhutan, with the agreement of the Government of Sri Lanka, has named Mr. Rinchen Kuentsyl as the new Ambassador Extraordinary and Plenipotentiary of Bhutan to Sri Lanka. Mr. Kuentsyl will represent Bhutan in Sri Lanka in his new role.	Ministry News	2025-09-28 09:13:39.845962
28	20	Appointment of the Ambassador of United Mexican States to Sri Lanka	11.11.2022	https://mfa.gov.lk/en/ambassador-of-mexican-sl/	The Government of the United Mexican States, with the approval of the Government of Sri Lanka, has named Mr. Federico Salas Lotfe as the new Ambassador Extraordinary and Plenipotentiary of Mexico to Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
29	20	Media Statement on Sri Lankan crew members of the oil tanker MT Heroic, Idun detained by Equatorial Guinea	11.11.2022	https://mfa.gov.lk/en/media-statement-on-sri-lankan-crew-members-of-the-oil-tanker-mt-heroic-idun-detained-by-equatorial-guinea/	The Ministry of Foreign Affairs is actively collaborating with relevant parties to secure the prompt release of 8 Sri Lankan crew members from the oil tanker MT Heroic Idun detained by Equatorial Guinea. Efforts are underway to resolve the situation and ensure the crew's safe return home.	Ministry News	2025-09-28 09:13:39.845962
30	20	Sri Lanka monitors the progress of rescued passengers	09.11.2022	https://mfa.gov.lk/en/sl-monitors-rescued-passengers/	Sri Lanka's Ministry of Foreign Affairs is closely monitoring the progress of rescued passengers of Sri Lankan origin who arrived at the Port of Vung Tau in Vietnam on November 8, 2022. The ministry continues to provide assistance and support to the rescued individuals.	Ministry News	2025-09-28 09:13:39.845962
31	20	High-level Business delegation of Sri Lankan heritage from Canada visits Sri Lanka	04.11.2022	https://mfa.gov.lk/en/high-level-business-delegation/	A high-level business delegation of Sri Lankan heritage from Canada visited Sri Lanka to engage in economic and commercial activities, establish people-to-people contacts, and contribute to the economy. The delegation comprised industry and corporate leaders aiming to strengthen ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
32	20	Joint Press Release: Sixth Meeting of the European Union – Sri Lanka Working Group on Governance, Rule of Law and Human Rights	02.11.2022	https://mfa.gov.lk/en/6th-meeting-eu-sl/	The Sixth Meeting of the European Union – Sri Lanka Working Group on Governance, Rule of Law and Human Rights convened in Colombo on 28 October 2022. This meeting was part of the routine bilateral engagements between the European Union and Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
33	20	​Foreign Minister Ali Sabry discusses U.S – Sri Lanka bilateral relations with the Assistant Secretary of State for South and Central Asian Affairs Donald Lu	20.10.2022	https://mfa.gov.lk/en/us-sl-bilateral-relations/	Foreign Minister Ali Sabry met with U.S Assistant Secretary of State for South and Central Asian Affairs Ambassador Donald Lu at the Ministry of Foreign Affairs on Wednesday, October 19, 2022. They discussed bilateral relations between the U.S and Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
34	20	​State Minister of Foreign Affairs Tharaka Balasuriya explores multiple areas of cooperation on the sidelines of the Sixth CICA Summit in Kazakhstan	16.10.2022	https://mfa.gov.lk/en/smfa-cica-6th-summit/	State Minister of Foreign Affairs Tharaka Balasuriya led Sri Lanka's delegation at the Sixth CICA Summit in Kazakhstan, where he explored various areas of cooperation. During the summit, he held meetings to discuss collaboration opportunities with other participating countries, aiming to strengthen ties and promote mutual understanding.	Ministry News	2025-09-28 09:13:39.845962
35	20	State Minister of Foreign Affairs Tharaka Balasuriya leads Sri Lanka’s delegation to the Sixth CICA Summit in Kazakhstan	14.10.2022	https://mfa.gov.lk/en/smfa-6-cica-summit-astana/	State Minister of Foreign Affairs Tharaka Balasuriya is leading Sri Lanka's delegation to the Sixth Summit of the Conference on Interaction and Confidence Building Measures in Asia (CICA) in Astana, Kazakhstan from 12-13 October 2022. The summit aims to enhance cooperation and dialogue among Asian countries for regional peace and stability.	Ministry News	2025-09-28 09:13:39.845962
36	20	​Foreign Ministry conducts a Briefing Session on Diplomatic Formalities for the Senior Sri Lankan Police Officers	14.10.2022	https://mfa.gov.lk/en/briefing-diplomatic-formalities-sl-police/	The Ministry of Foreign Affairs conducted a one-day briefing session for 30 Senior Sri Lankan Police Officers on diplomatic formalities to aid their official responsibilities effectively. The session aimed to enhance their understanding of diplomatic practices and facilitate smoother execution of their duties.	Ministry News	2025-09-28 09:13:39.845962
37	20	Minister of Foreign Affairs engages in a discussion with Key Business Chambers	12.10.2022	https://mfa.gov.lk/en/engages-key-business-chambers/	Minister of Foreign Affairs, Ali Sabry, engaged in a discussion with Presidents, Secretaries General, senior officials, and business leaders from export-oriented organizations and chambers of commerce on October 12. The meeting aimed to strengthen ties and collaboration between the government and key business chambers.	Ministry News	2025-09-28 09:13:39.845962
38	20	Sri Lanka rejects resolution at the UN Human Rights Council	06.10.2022	https://mfa.gov.lk/en/sl-rejects-resolution-unhrc/	Sri Lanka has rejected a resolution at the UN Human Rights Council titled "Promoting reconciliation, accountability, and human rights in Sri Lanka." The resolution was tabled by several countries including the United Kingdom, Canada, and Germany.	Ministry News	2025-09-28 09:13:39.845962
39	20	​Sri Lanka commemorates the 25th Anniversary of the BIMSTEC	04.10.2022	https://mfa.gov.lk/en/the-25th-anniversary-bimstec/	Sri Lanka marked the 25th Anniversary of the Bay of Bengal Initiative for Technical and Economic Cooperation (BIMSTEC with an event organized by the Ministry of Foreign Affairs in collaboration with the Lakshman Kadirgamar Institute.	Ministry News	2025-09-28 09:13:39.845962
40	20	​51st session of the UN Human Rights Council	03.10.2022	https://mfa.gov.lk/en/%e2%80%8b51st-session-of-the-un-human-rights-council/	The 51st session of the United Nations Human Rights Council is taking place in Geneva and will end on October 7, 2022. The session includes discussions on the draft resolution A/HRC/51/L.1 titled "Promoting reco.	Ministry News	2025-09-28 09:13:39.845962
41	20	​Australian High Commissioner paid a courtesy call on Foreign Minister	02.10.2022	https://mfa.gov.lk/en/australian-high-commissioner/	Australian High Commissioner Paul Stephens paid a courtesy visit to Foreign Minister Ali Sabry at the Ministry on September 30, 2022. During the meeting, the Foreign Minister congratulated the High Commissioner on his recent appointment.	Ministry News	2025-09-28 09:13:39.845962
42	20	Consular Affairs Division of the Ministry of Foreign Affairs Launches e-Channeling Appointment System for Authentication Services	02.10.2022	https://mfa.gov.lk/en/launches-e-channeling-for-authentication-services/	The Consular Affairs Division of the Ministry of Foreign Affairs has introduced an e-Channeling appointment system in partnership with SLT Mobitel on September 29, 2022. This system aims to enhance service efficiency for the public seeking authentication services.	Ministry News	2025-09-28 09:13:39.845962
43	20	Ambassador of Vietnam to Sri Lanka calls on Minister of Foreign Affairs	02.10.2022	https://mfa.gov.lk/en/vietnam-ambassador/	The Ambassador of Vietnam to Sri Lanka, Ho Thi Thanh Truc, met with Minister of Foreign Affairs Ali Sabry on Friday, September 30, 2022, at the Ministry of Foreign Affairs. During the meeting, the Ambassador extended congratulations.	Ministry News	2025-09-28 09:13:39.845962
44	20	South African High Commissioner to Sri Lanka calls on Minister of Foreign Affairs	29.09.2022	https://mfa.gov.lk/en/south-african-hc/	South African High Commissioner to Sri Lanka, Sandile Schalk, met with Minister of Foreign Affairs Ali Sabry on 29 September 2022 at the Ministry of Foreign Affairs. The meeting aimed to discuss bilateral relations between the two countries.	Ministry News	2025-09-28 09:13:39.845962
45	20	​Foreign Secretary welcomes U.S. assistance to Sri Lanka in meeting with U.S. PRUN to Rome	27.09.2022	https://mfa.gov.lk/en/fs-us-prun-rome/	Foreign Secretary Aruni Wijewardane welcomed U.S. assistance to Sri Lanka during a meeting with U.S. Permanent Representative to the UN Agencies in Rome, Ambassador Cindy McCain, at the Ministry of Foreign Affairs in Colombo on Monday.	Ministry News	2025-09-28 09:13:39.845962
46	20	Consular Affairs Division of the Ministry of Foreign Affairs launches e-Channeling Appointment System for Authentication Services	27.09.2022	https://mfa.gov.lk/en/launches-e-channeling/	The Consular Affairs Division of the Ministry of Foreign Affairs has partnered with SLT Mobitel to introduce an e-Channeling Appointment System for Authentication Services starting September 29, 2022. This system aims to enhance public access to efficient services.	Ministry News	2025-09-28 09:13:39.845962
47	20	​Statement by the Minister of Foreign Affairs & Head of Delegation of Sri Lanka Hon. Ali Sabry, at the General Debate of the 77th Session of the United Nations General Assembly on 24 September, 2022 – New York.	25.09.2022	https://mfa.gov.lk/en/77th-session-unga/	Sri Lanka's Minister of Foreign Affairs & Head of Delegation, Hon. Ali Sabry, addressed the 77th Session of the United Nations General Assembly in New York on September 24, 2022. He expressed his honor in representing Sri Lanka at this session, which marks the gathering of world leaders after a two-year hiatus.	Ministry News	2025-09-28 09:13:39.845962
48	20	Foreign Minister Ali Sabry meets international dignitaries and  addresses meetings on the sidelines of the United Nations General Assembly in New York	23.09.2022	https://mfa.gov.lk/en/foreignmeetingsjbiden/	Foreign Minister Ali Sabry, leading the Sri Lanka delegation at the 77th UNGA, met with various international dignitaries on the sidelines of the United Nations General Assembly in New York. He addressed meetings with leaders of UN member states to discuss key global issues.	Ministry News	2025-09-28 09:13:39.845962
49	20	State Minister of Foreign Affairs welcomes USAID support towards Sri Lanka’s tech and innovations industries	23.09.2022	https://mfa.gov.lk/en/smfa-usaid/	State Minister of Foreign Affairs Tharaka Balasuriya welcomed USAID's support for Sri Lanka's tech and innovation industries during a meeting with USAID Mission Director Gabriel Grau at the Ministry of Foreign Affairs on Wednesday, 21st.	Ministry News	2025-09-28 09:13:39.845962
50	20	Interview of the Minister of Foreign Affairs Hon. Ali Sabry on One on One TRT World in New York .	23.09.2022	https://mfa.gov.lk/en/slfm-on-one-on-one-trt-world-in-new-york/	Minister of Foreign Affairs Hon. Ali Sabry discusses economic and political crises and geopolitical issues on One on One TRT World in New York. The full interview provides insights into the country's stance on global divisions.	Ministry News	2025-09-28 09:13:39.845962
51	20	​Appointment of the Ambassador of the Kingdom of Saudi Arabia to Sri Lanka	20.09.2022	https://mfa.gov.lk/en/kingdom-of-saudi-arabia-sl/	The Government of Saudi Arabia, with the approval of Sri Lanka, has named Mr. Khalid Hamoud Nasser Aldasam Alkahtani as the new Ambassador to Sri Lanka. He will serve as the Ambassador Extraordinary and Plenipotentiary of the Kingdom.	Ministry News	2025-09-28 09:13:39.845962
52	20	Appointment of the Ambassador of the Kingdom of Netherlands to Sri Lanka	20.09.2022	https://mfa.gov.lk/en/kingdom-of-netherlands-sl/	Ms. Bonnie Horbach has been appointed as the Ambassador Extraordinary and Plenipotentiary of the Kingdom of the Netherlands to Sri Lanka with the concurrence of the Government of Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
53	20	Resumption of the Attestation & Verification process at the Consular Affairs Division	19.09.2022	https://mfa.gov.lk/en/attestation-verification-consular-division/	The Ministry of Foreign Affairs has announced the resumption of the Attestation & Verification process at the Consular Affairs Division following a computer system breakdown. The General Public is informed that services are now operational.	Ministry News	2025-09-28 09:13:39.845962
54	20	Foreign Minister Ali Sabry leads the Sri Lanka delegation to the UNGA in New York	18.09.2022	https://mfa.gov.lk/en/unga_ny/	Foreign Minister Ali Sabry will represent Sri Lanka at the 77th Session of the United Nations General Assembly in New York on September 24, 2022. He is scheduled to deliver the Sri Lanka statement and address various matters during his visit.	Ministry News	2025-09-28 09:13:39.845962
55	20	News item on Sri Lankan students in Kharkiv region, Ukraine	17.09.2022	https://mfa.gov.lk/en/news-item-on-sl-students-in-ukraine/	The Ministry of Foreign Affairs is aware of a news item circulating on social media regarding the rescue of Sri Lankan students in the Kharkiv region, Ukraine on 17 September.	Ministry News	2025-09-28 09:13:39.845962
56	20	Foreign Minister Ali Sabry highlights Sri Lanka’s commitment to continuing progress in human rights and reconciliation through a credible domestic process at the 51st session of the Human Rights Council	16.09.2022	https://mfa.gov.lk/en/unhrc2022/	Foreign Minister Ali Sabry emphasized Sri Lanka's dedication to advancing human rights and reconciliation through a credible domestic process at the 51st session of the Human Rights Council. Despite economic challenges, Sri Lanka remains committed to progress in these areas.	Ministry News	2025-09-28 09:13:39.845962
57	20	Ambassador of Israel to Sri Lanka Gilon calls on Foreign Minister Sabry	16.09.2022	https://mfa.gov.lk/en/israel-ambassador-slfm/	Israel's Ambassador to Sri Lanka, Naor Gilon, based in New Delhi, met with Foreign Minister Ali Sabry on September 15, 2022. They discussed various ways of enhancing bilateral relations during the meeting.	Ministry News	2025-09-28 09:13:39.845962
58	20	​​Computer System Breakdown at the Consular Affairs Division	16.09.2022	https://mfa.gov.lk/en/consular-division/	The Verification and Attestation units of the Consular Affairs Division at the Ministry of Foreign Affairs in Colombo 01 and its Regional Offices in Jaffna, Trincomalee, and Mat are experiencing service disruptions due to a computer system breakdown.	Ministry News	2025-09-28 09:13:39.845962
59	20	​Statement by the Minister of Foreign Affairs of Sri Lanka at the 51st  Regular Session of the United Nations Human Rights Council in Geneva on 12 September 2022	12.09.2022	https://mfa.gov.lk/en/regular-session-51st-12-09-2022/	During the 51st Regular Session of the United Nations Human Rights Council in Geneva on September 12, 2022, the Minister of Foreign Affairs of Sri Lanka reaffirmed the government's steadfast dedication to promoting and safeguarding human rights. The statement emphasized their commitment to advancing and protecting human rights.	Ministry News	2025-09-28 09:13:39.845962
60	20	State Minister of Foreign Affairs Tharaka Balasuriya assumes duties	09.09.2022	https://mfa.gov.lk/en/state-minister-mfa-assumes-duties/	State Minister of Foreign Affairs Tharaka Balasuriya officially started his duties today at the Ministry of Foreign Affairs in a modest ceremony. He was joined by Foreign Secretary Aruni Wijewardane and other senior officials.	Ministry News	2025-09-28 09:13:39.845962
61	20	Sri Lanka donates a consignment of tea to Pakistan flood victims	06.09.2022	https://mfa.gov.lk/en/sl-donates-tea-pakistan/	Sri Lanka's Government donated a consignment of Ceylon Tea to aid flood victims in Pakistan after recent devastating flash floods. The donation was handed over by the Minister of Foreign Affairs, Ali Sabry, to support those affected by the natural disaster.	Ministry News	2025-09-28 09:13:39.845962
62	20	World Food Programme Regional Director for Asia and the Pacific calls on Foreign Minister Ali Sabry	02.09.2022	https://mfa.gov.lk/en/wfp-regional-director-asia-pacific/	World Food Programme (WFP) Regional Director for Asia and the Pacific, John Aylieff, visited Sri Lanka and met with Foreign Minister Ali Sabry on September 1, 2022. The meeting was a courtesy call during Aylieff's current visit to the country.	Ministry News	2025-09-28 09:13:39.845962
63	20	Egyptian Ambassador to Sri Lanka calls on the Minister of Foreign Affairs	01.09.2022	https://mfa.gov.lk/en/egyptian-ambassador-slfm/	Egyptian Ambassador to Sri Lanka, Maged Mosleh, met with Sri Lankan Minister of Foreign Affairs Ali Sabry on August 31, 2022, at the Ministry of Foreign Affairs. The meeting between Foreign Minister Sabry and Ambassador Mosleh covered a wide range of topics.	Ministry News	2025-09-28 09:13:39.845962
64	20	Foreign Minister to address the 51st Session of the Human Rights Council   on 12 September 2022	29.08.2022	https://mfa.gov.lk/en/hrc8_29/	Foreign Minister Ali Sabry will lead the Sri Lanka delegation at the 51st Session of the Human Rights Council in Geneva from September 12 to October 7, 2022. He is scheduled to address the council on September 12, 2022.	Ministry News	2025-09-28 09:13:39.845962
65	20	Sri Lankan trained nurses ready to begin their careers in the UK	28.08.2022	https://mfa.gov.lk/en/uknuress/	Sri Lankan trained nurses received letters of appointment from Minister of Foreign Affairs Ali Sabry, marking the start of their careers in the UK. The nurses are set to commence employment at hospitals in the United Kingdom following a ceremony held on August 25.	Ministry News	2025-09-28 09:13:39.845962
136	20	Sri Lanka registers strong protest with Canada on House of Commons motion	20.05.2022	https://mfa.gov.lk/en/cahocom/	Sri Lanka's Foreign Affairs Minister, Prof. G.L. Peiris, strongly protested and expressed deep concern to Canada regarding a motion adopted by the Canadian Parliament on May 18, 2022, alleging genocide.	Ministry News	2025-09-28 09:13:39.845962
66	20	UNICEF Regional Director for South Asia George Laryea-Adjei calls on Foreign Minister Ali Sabry	26.08.2022	https://mfa.gov.lk/en/unicef-2/	UNICEF Regional Director for South Asia, George Laryea-Adjei, visited Sri Lanka and met with Foreign Minister Ali Sabry on August 24, 2022. The meeting was a courtesy call during his visit to the country.	Ministry News	2025-09-28 09:13:39.845962
67	20	Regional Director of the United Nations Development Cooperation Office calls on Foreign Minister Ali Sabry	19.08.2022	https://mfa.gov.lk/en/undco/	The Regional Director for Asia and the Pacific of the United Nations Development Cooperation Office (UNDCO), David Mclachlan-Karr, visited Sri Lanka and met with Foreign Minister Ali Sabry during his official visit. The meeting was a courtesy call to discuss cooperation and development initiatives.	Ministry News	2025-09-28 09:13:39.845962
68	20	Appointment of the Ambassador of the Nepal to Sri Lanka	18.08.2022	https://mfa.gov.lk/en/ambassador-of-the-nepal-to-sl/	The Government of Nepal, with the approval of the Government of Sri Lanka, has appointed Mr. Bashu Dev Mishra as the new Ambassador Extraordinary and Plenipotentiary of Nepal to Sri Lanka. He will be based in Colombo and has already presented his credentials.	Ministry News	2025-09-28 09:13:39.845962
69	20	Appointment of the High Commissioner of Australia to Sri Lanka	18.08.2022	https://mfa.gov.lk/en/hc-of-australia-to-sl/	The Government of Australia, with the agreement of the Government of Sri Lanka, has appointed Mr. Paul Wesley Stephens as the new High Commissioner of Australia to Sri Lanka. He is based in Colombo and has already presented his credentials.	Ministry News	2025-09-28 09:13:39.845962
70	20	Foreign Minister briefs the Diplomatic Corps on current developments	16.08.2022	https://mfa.gov.lk/en/dccd/	Foreign Minister Ali Sabry briefed Colombo-based Ambassadors and High Commissioners on current developments at the Ministry of Foreign Affairs on August 15, 2022, ahead of the 51st session.	Ministry News	2025-09-28 09:13:39.845962
71	20	​​Ambassador of Iran Hashem Ashjazadeh calls on Foreign Minister Ali Sabry	16.08.2022	https://mfa.gov.lk/en/ambassador-of-iran-hashem-ashjazadeh/	Iran's Ambassador Hashem Ashjazadeh met with Foreign Minister Ali Sabry at the Ministry of Foreign Affairs on August 15, 2022. The Foreign Minister highlighted the countries' longstanding cordial relations during the meeting.	Ministry News	2025-09-28 09:13:39.845962
72	20	Foreign Minister Ali Sabry meets with visiting UNDP Deputy Regional Director Christophe Bahuet	15.08.2022	https://mfa.gov.lk/en/undp-deputy-regional-director/	Foreign Minister Ali Sabry met with Christophe Bahuet, the Deputy Regional Director for Asia and the Pacific of the UNDP, who is currently visiting Sri Lanka. They discussed matters related to development and cooperation during the meeting.	Ministry News	2025-09-28 09:13:39.845962
73	20	Chinese vessel Yuan Wang 5	12.08.2022	https://mfa.gov.lk/en/chinese-vessel-yuan-wang-5/	The Ministry of Foreign Affairs received notification from the Chinese Embassy in Colombo regarding the Chinese vessel Yuan Wang 5 on June 28, 2022. The Embassy informed the Ministry through a Diplomatic Note.	Ministry News	2025-09-28 09:13:39.845962
74	20	​UAE Ambassador Calls on Foreign Minister	10.08.2022	https://mfa.gov.lk/en/uae-ambassador-calls-on/	The Ambassador of the United Arab Emirates, Khaled Nasser Al-Ameri, met with Foreign Minister Ali Sabry at the Ministry of Foreign Affairs today. During the meeting, Foreign Minister Ali Sabry briefed the Ambassador on important matters.	Ministry News	2025-09-28 09:13:39.845962
75	20	High Commissioner of New Zealand calls on Foreign Minister	10.08.2022	https://mfa.gov.lk/en/hc-new-zealand/	The High Commissioner of New Zealand, Michael Appleton, met with Foreign Minister Ali Sabry at the Ministry of Foreign Affairs on August 9, 2022. During the meeting, the Foreign Minister acknowledged the long-standing cordial relationship between the two countries.	Ministry News	2025-09-28 09:13:39.845962
76	20	Foreign Secretary Aruni Wijewardane at the 55th ASEAN Day Celebrations in Colombo	09.08.2022	https://mfa.gov.lk/en/fs-55th-asean/	Foreign Secretary Aruni Wijewardane attended the 55th ASEAN Day celebrations on August 8, 2022, at the Indonesian Embassy in Colombo as the Chief Guest. The event was hosted by the Indonesian Ambassador, Dewi Gus.	Ministry News	2025-09-28 09:13:39.845962
77	20	Latest Developments on the Chinese vessel Yuang Wang 5	08.08.2022	https://mfa.gov.lk/en/lyuang-wang-5/	The Ministry of Foreign Affairs has granted diplomatic clearance for the Chinese vessel Yuang Wang 5 to make a port call at the Hambantota port from August 11 to 17, 2022.	Ministry News	2025-09-28 09:13:39.845962
78	20	U.S. Ambassador Julie Chung calls on Foreign Minister Ali Sabry	04.08.2022	https://mfa.gov.lk/en/us8_4/	U.S. Ambassador Julie Chung met with Sri Lankan Foreign Minister Ali Sabry on July 29, 2022, at the Ministry of Foreign Affairs. During the meeting, the Ambassador congratulated Minister Sabry.	Ministry News	2025-09-28 09:13:39.845962
79	20	​Korean Ambassador calls on Foreign Minister Ali Sabry	03.08.2022	https://mfa.gov.lk/en/korean-ambassadar-08-2022/	The Korean Ambassador in Sri Lanka, Woonjin Jeong, visited Foreign Minister Ali Sabry on July 29, 2022, to discuss enhancing bilateral cooperation. The meeting took place at the Ministry, where both sides exchanged views on strengthening their relationship.	Ministry News	2025-09-28 09:13:39.845962
80	20	Foreign Minister to attend 29th ASEAN Regional Forum (ARF) in Cambodia	02.08.2022	https://mfa.gov.lk/en/cambodia/	Foreign Minister M.U.M. Ali Sabry will attend the 29th ASEAN Regional Forum (ARF) Ministerial Meeting in Phnom Penh, Cambodia on August 4-5, 2022. The ARF is a key platform for dialogue and cooperation on security issues in the Asia-Pacific region.	Ministry News	2025-09-28 09:13:39.845962
81	20	Japanese Ambassador calls on the Minister of Foreign Affairs	02.08.2022	https://mfa.gov.lk/en/japan8_2/	Japanese Ambassador Mizukoshi Hideaki met with Sri Lanka's newly appointed Minister of Foreign Affairs, Ali Sabry on July 28, 2022, at the Ministry. During the meeting, they discussed bilateral relations and cooperation between the two countries.	Ministry News	2025-09-28 09:13:39.845962
82	20	Foreign Minister Ali Sabry briefs Colombo-based Diplomatic Corps on Key Developments	02.08.2022	https://mfa.gov.lk/en/cmb-based-diplomatic-corps/	Foreign Minister Ali Sabry briefed the Colombo-based Diplomatic Corps on key developments following the election of the new President and the formation of the new Government. The briefing aimed to update Ambassadors and High Commissioners on recent political changes in the country.	Ministry News	2025-09-28 09:13:39.845962
83	20	​Russian Ambassador calls on new Foreign Minister	31.07.2022	https://mfa.gov.lk/en/yury-materiy-called-on-fam/	The Russian Ambassador to Sri Lanka, Yury Materiy, met with the newly appointed Foreign Minister, Ali Sabry, on July 28, 2022, at the Foreign Ministry to congratulate Minister Sabry.	Ministry News	2025-09-28 09:13:39.845962
84	20	High Commissioner of Pakistan calls on Minister of Foreign Affairs of Sri Lanka	31.07.2022	https://mfa.gov.lk/en/hc-pakistan-mfa/	The High Commissioner of Pakistan to Sri Lanka, Maj. Gen. (Rtd) Umar Farooq Burki, visited the Ministry of Foreign Affairs on July 29, 2022, and met with Minister Ali Sabry. During the meeting, they discussed bilateral relations and cooperation between the two countries.	Ministry News	2025-09-28 09:13:39.845962
85	20	​Chinese Ambassador pays courtesy call on Foreign Minister	28.07.2022	https://mfa.gov.lk/en/chinese-ambassador-paid-a-courtesy-call-on/	Chinese Ambassador Qi Zhenhong paid a courtesy call on Foreign Minister Ali Sabry at the Ministry on July 27, 2022. During the meeting, Ambassador Qi congratulated the Foreign Minister on his recent appointment.	Ministry News	2025-09-28 09:13:39.845962
86	20	High Commissioner of India pays a courtesy call on the newly appointed Minister of Foreign Affairs	27.07.2022	https://mfa.gov.lk/en/hci-mfa/	The High Commissioner of India to Sri Lanka, Gopal Baglay, paid a courtesy call on Sri Lanka's newly appointed Minister of Foreign Affairs, Ali Sabry, on July 26, 2022, at the Ministry. The meeting aimed to strengthen diplomatic ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
87	20	​​Foreign Minister Ali Sabry assumes duties	25.07.2022	https://mfa.gov.lk/en/fm-ali-sabry-assumes-duties/	Foreign Minister Ali Sabry officially began his duties at the Ministry of Foreign Affairs today in a simple ceremony attended by Foreign Secretary Aruni Wijewardane and senior officials. In his address to the officials, Minister Sabry emphasized the importance of diplomacy in advancing the country's interests.	Ministry News	2025-09-28 09:13:39.845962
88	20	Demise of Mr. Moragodage Christopher Walter Pinto	22.07.2022	https://mfa.gov.lk/en/demise-of-mr-moragodage-christopher-walter-pinto/	The Foreign Ministry announced the passing of Mr. Moragodage Christopher Walter Pinto, also known as Mr. Chris Pinto, on July 21, 2022, in The Hague, Netherlands. Mr. Pinto was the first Legal A. We extend our deepest condolences to his family and friends during this difficult time.	Ministry News	2025-09-28 09:13:39.845962
89	20	Sri Lanka concludes bilateral consultations with Japan	17.07.2022	https://mfa.gov.lk/en/sl-japan/	Sri Lanka recently concluded bilateral consultations with Japan. The discussions were led by Secretary of Foreign Affairs Aruni Wijewardane and a senior delegation from the Japanese Ministry of Foreign Affairs, headed by the Assistant Minister of Southwest and Southeast Asia Affairs.	Ministry News	2025-09-28 09:13:39.845962
90	20	Outgoing Ambassador for Sultanate of  Oman calls on Foreign Minister Prof. Peiris	10.07.2022	https://mfa.gov.lk/en/sultanate-oman/	Ambassador Juma Hamdan Hassan Al Shehhi of the Sultanate of Oman bid farewell to Foreign Minister Prof. G.L. Peiris during a meeting at the Ministry of Foreign Affairs on July 7, 2022. The ambassador paid a courtesy visit before concluding his term.	Ministry News	2025-09-28 09:13:39.845962
91	20	Foreign Minister meets with the Ambassador of the European Union in Colombo	08.07.2022	https://mfa.gov.lk/en/eun-7-8/	Foreign Minister Prof. G.L. Peiris met with the European Union Ambassador Denis Chaibi in Colombo at the Ministry of Foreign Affairs on July 6, 2022. The meeting involved discussions on various matters of mutual interest between the two parties.	Ministry News	2025-09-28 09:13:39.845962
92	20	Foreign Minister G.L Peiris reviews progress on the work of domestic mechanisms in relation to reconciliation and human rights	07.07.2022	https://mfa.gov.lk/en/mfamd7_7/	Foreign Minister G.L. Peiris and Justice Minister Wijeyadasa Rajapakshe co-chaired a meeting on July 4, 2022, at the Ministry of Foreign Affairs to review progress on domestic mechanisms related to reconciliation and human rights. The meeting aimed to assess the work done so far in these areas and discuss future steps for improvement.	Ministry News	2025-09-28 09:13:39.845962
93	20	Foreign Minister Meets with the UN Resident Coordinator in Colombo	06.07.2022	https://mfa.gov.lk/en/un-resident-coordinator-in-cmb/	Foreign Minister Prof. G.L. Peiris met with the United Nations Resident Coordinator Hanna Singer-Hamdy in Colombo on July 1, 2022. They discussed various matters during the meeting at the Ministry of Foreign Affairs.	Ministry News	2025-09-28 09:13:39.845962
94	20	Minister of Foreign Affairs and Minister of Labour & Foreign Employment co-host a meeting on Promotion of Foreign Employment	05.07.2022	https://mfa.gov.lk/en/mol-fe/	Minister of Foreign Affairs Prof. G.L. Peiris and Minister of Labour & Foreign Employment Manusha Nanayakkara co-hosted a meeting at the Ministry of Foreign Affairs on July 4, 2022, to discuss the promotion of foreign employment. They explored potential avenues for enhancing opportunities in this sector.	Ministry News	2025-09-28 09:13:39.845962
95	20	​Foreign Minister meets with Chinese Ambassador	03.07.2022	https://mfa.gov.lk/en/chinese-ambassador/	Foreign Minister Professor G.L. Peiris met with Chinese Ambassador Qi Zhenhong on June 30, 2022, at the Ministry of Foreign Affairs. The meeting involved discussions on bilateral relations and cooperation between the two countries.	Ministry News	2025-09-28 09:13:39.845962
96	20	Consular Affairs Division of Ministry of Foreign Affairs  Resumes its Regular Services	01.07.2022	https://mfa.gov.lk/en/con_01-07/	The Consular Affairs Division of the Ministry of Foreign Affairs has resumed its regular services to meet the high demand for consular assistance. The division will now be open to the public on weekdays, from Monday to Friday starting in July. This change aims to better serve the public's needs for consular services.	Ministry News	2025-09-28 09:13:39.845962
97	20	Charge d’ Affaires a.i. of the Embassy of Kingdom of Saudi Arabia Abdullah A. Orkobi called on the Foreign Minister	01.07.2022	https://mfa.gov.lk/en/ksa/	Charge d’Affaires a.i. of the Embassy of the Kingdom of Saudi Arabia, Abdullah A. Orkobi, met with Foreign Minister G.L. Peiris at the Foreign Ministry on June 30, 2022. The meeting aimed to discuss bilateral relations between the two countries.	Ministry News	2025-09-28 09:13:39.845962
98	20	Russian Ambassador calls on Foreign Minister Peiris	30.06.2022	https://mfa.gov.lk/en/ruassian-ambassador-to-sl/	Russian Ambassador Yury Materiy visited Foreign Minister G.L. Peiris on June 29, 2022, at the Ministry of Foreign Affairs in Sri Lanka. The meeting aimed to discuss diplomatic matters between the two countries.	Ministry News	2025-09-28 09:13:39.845962
99	20	Consular Services for public only on Monday, Wednesday, and Friday	29.06.2022	https://mfa.gov.lk/en/consular-services/	Starting June 30, 2022, the Consular Affairs Division of the Ministry of Foreign Affairs will offer services to the public on Mondays, Wednesdays, and Fridays due to the current situation in the country.	Ministry News	2025-09-28 09:13:39.845962
100	20	Foreign Minister Peiris attends the Commonwealth Heads of Government Meeting 2022 (CHOGM) in Kigali, Rwanda from 23–25 June, 2022	29.06.2022	https://mfa.gov.lk/en/chogm-commonwealth-hog/	Foreign Minister Prof. G.L. Peiris represented President Gotabaya Rajapaksa at the 2022 Commonwealth Heads of Government Meeting (CHOGM) held in Kigali, Rwanda from June 23 to 25, 2022. The meeting aimed to address key issues affecting Commonwealth nations.	Ministry News	2025-09-28 09:13:39.845962
101	20	Foreign Secretary Aruni Wijewardane meets visiting delegation from  U.S.Treasury and State Department	28.06.2022	https://mfa.gov.lk/en/sfausa/	Foreign Secretary Aruni Wijewardane met with a senior delegation from the U.S. Department of the Treasury and the Department of State. The delegation was led by Rob, the Deputy Assistant Secretary of Treasury for Asia.	Ministry News	2025-09-28 09:13:39.845962
102	20	Foreign Minister Peiris holds bilateral discussions with Commonwealth Foreign Ministers on the side-lines of CHOGM 2022	28.06.2022	https://mfa.gov.lk/en/chogm-heads-of-delegations/	Foreign Minister Prof. G.L. Peiris engaged in bilateral discussions with Commonwealth Foreign Ministers during the CHOGM 2022 in Kigali, Rwanda on June 24-25. The meetings aimed to strengthen diplomatic ties and cooperation among participating countries.	Ministry News	2025-09-28 09:13:39.845962
103	20	Sri Lanka’s Candidate Prof. Rangita De Silva De Alwis elected to the Committee on the Elimination of All Forms of Discrimination Against Women (CEDAW)	24.06.2022	https://mfa.gov.lk/en/rangita/	Professor Rangita De Silva De Alwis from Sri Lanka has been elected to the UN Committee on the Elimination of All Forms of Discrimination Against Women for the term 2023-2026. She will represent Sri Lanka in this role following the recent elections.	Ministry News	2025-09-28 09:13:39.845962
104	20	Foreign Minister Peiris meets India’s External Affairs Minister  on the side-lines of CHOGM 2022	24.06.2022	https://mfa.gov.lk/en/fmiea/	Foreign Minister Prof. G.L. Peiris met with India’s External Affairs Minister Dr. S. Jaishankar on the sidelines of the CHOGM Summit in Kigali, Rwanda on June 23. The bilateral discussion aimed to strengthen diplomatic ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
105	20	Consular Service on 24 June, 2022	23.06.2022	https://mfa.gov.lk/en/consular-service-on-24-06-2022/	On 24 June, 2022, the Consular Affairs Division of the Ministry of Foreign Affairs will serve only 400 applicants due to maintenance work at their premises. Please plan accordingly if you require consular services on that day.	Ministry News	2025-09-28 09:13:39.845962
106	20	Indian Foreign Secretary Vinay Kwatra calls on Foreign Secretary Aruni Wijewardane	23.06.2022	https://mfa.gov.lk/en/indian-fs-and-sl-fs/	Indian Foreign Secretary Vinay Kwatra visited Sri Lanka on June 23, 2022, and met with Sri Lankan Foreign Secretary Aruni Wijewardane at the Ministry of Foreign Affairs. The meeting aimed to discuss bilateral relations and cooperation between the two countries.	Ministry News	2025-09-28 09:13:39.845962
107	20	Indian Foreign Secretary Vinay Kwatra and delegation visit Sri Lanka	23.06.2022	https://mfa.gov.lk/en/indian-fm-visit-sl/	Indian Foreign Secretary Vinay Kwatra and his delegation visited Sri Lanka today to discuss bilateral assistance provided by India amid the current economic situation. The visit aimed to strengthen ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
108	20	Sri Lanka and New Zealand Foreign Ministers meet on the sidelines of CHOGM 2022	23.06.2022	https://mfa.gov.lk/en/new-zealand-chogm-2022/	Sri Lanka's Minister of Foreign Affairs G.L. Peiris met with New Zealand's Minister for Foreign Affairs and Local Government Nanaia Mahuta on June 22 during the CHOGM Summit in Kigali. The bilateral meeting aimed to discuss mutual interests and strengthen diplomatic ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
109	20	Foreign Minister Peiris to attend Commonwealth Heads of Government Meeting in Kigali, Rwanda	21.06.2022	https://mfa.gov.lk/en/chogm-rwanda/	Foreign Minister Prof. G.L. Peiris will represent President Gotabaya Rajapaksa at the Commonwealth Heads of Government Meeting (CHOGM) in Kigali, Rwanda from June 21 to 25, 2022. The meeting aims to address key issues affecting member countries.	Ministry News	2025-09-28 09:13:39.845962
110	20	Joint Press Release by Clare O’Neil MP, Australia’s Minister for Home Affairs and Prof G. L. Peiris, Sri Lanka’s Minister of Foreign Affairs on 20 June 2022	20.06.2022	https://mfa.gov.lk/en/joinpressaus/	Australia's Minister for Home Affairs, Clare O’Neil MP, met with Sri Lanka’s Minister of Foreign Affairs, Prof G. L. Peiris, during her visit to Colombo from 19 to 21 June 2022. This meeting marks an important diplomatic engagement between the two countries.	Ministry News	2025-09-28 09:13:39.845962
111	20	Foreign Minister meets High Commissioner for Human Rights	19.06.2022	https://mfa.gov.lk/en/unhrc-19-06-22/	Foreign Minister G.L. Peiris met with the UN High Commissioner for Human Rights, the Secretary General of the International Federation of the Red Cross, and the Permanent Representatives of China. The meeting aimed to discuss human rights issues and international cooperation.	Ministry News	2025-09-28 09:13:39.845962
112	20	Sri Lanka stresses importance of relations with Japan	16.06.2022	https://mfa.gov.lk/en/japan-16-06-22/	Sri Lanka's Minister of Foreign Affairs, Prof. G.L. Peiris, emphasized the importance of relations with Japan during meetings with the Vice Minister for Foreign Affairs of Japan, the UK's Minister for Foreign and Commonwealth Affairs, and Ambassadors/Permanent Representatives of the United Nations. The discussions highlighted the significance of strengthening diplomatic ties between Sri Lanka and these key international partners.	Ministry News	2025-09-28 09:13:39.845962
113	20	​Foreign Minister Peiris briefs the President of the Human Rights Council on Sri Lankan Issues	15.06.2022	https://mfa.gov.lk/en/unhrc-brazil/	Foreign Minister Prof. G.L. Peiris briefed the President of the Human Rights Council on Sri Lankan issues during meetings with the Coordinator of the Non-Aligned Movement (Geneva Chapter) and the Permanent Representative of Brazil.	Ministry News	2025-09-28 09:13:39.845962
114	20	​Statement by the Minister of Foreign Affairs of Sri Lanka at the 50th Regular Session of the United Nations Human Rights Council in Geneva on 13 June 2022	13.06.2022	https://mfa.gov.lk/en/statement-mfa-50th-sesson-unhrc/	During the 50th Regular Session of the United Nations Human Rights Council in Geneva on 13 June 2022, the Minister of Foreign Affairs of Sri Lanka highlighted the country's progress and challenges in an open exchange with the Council and other UN organs, emphasizing transparency, candor, and openness.	Ministry News	2025-09-28 09:13:39.845962
115	20	Foreign Minister to address the Human Rights Council on Monday 13 June, 2022	13.06.2022	https://mfa.gov.lk/en/address-the-hrc-on-13-6-2022/	Foreign Minister Prof. G.L. Peiris will address the Human Rights Council on Monday, June 13, 2022, leading the Sri Lankan delegation at the 50th Session. The statement is scheduled for noon GMT.	Ministry News	2025-09-28 09:13:39.845962
116	20	Foreign Minister Peiris attends 19th IISS Shangri-La Dialogue in Singapore 10-11 June, 2022	13.06.2022	https://mfa.gov.lk/en/shangri-la-dialogue-singapore/	Foreign Minister Prof. G.L. Peiris attended the 19th IISS Shangri-La Dialogue in Singapore on June 10-11, 2022. The summit is recognized as Asia's premier Security Summit. Peiris participated in discussions on regional security issues during the event.	Ministry News	2025-09-28 09:13:39.845962
117	20	Consular Services on Special Holiday, 13 June, 2022	12.06.2022	https://mfa.gov.lk/en/limited-services-13-06-2022/	On Monday, 13 June 2022, the Consular Affairs Division of the Ministry of Foreign Affairs will provide services only for urgent cases due to the high number of service seekers. Regular consular services will be limited on this special holiday.	Ministry News	2025-09-28 09:13:39.845962
118	20	​Foreign Minister Peiris meets Australia’s Deputy Prime Minister in Singapore	12.06.2022	https://mfa.gov.lk/en/australia-dpm/	Foreign Minister Professor G. L. Peiris met with Australia’s Deputy Prime Minister and Minister of Defence, Dr. Richard Marles, in Singapore during the Shangri La dialogue. Minister Peiris discussed matters of mutual interest with Dr. Marles during the meeting.	Ministry News	2025-09-28 09:13:39.845962
119	20	Foreign Minister of Sri Lanka meets Singapore’s Senior Minister and Coordinating Minister for Social Policies	10.06.2022	https://mfa.gov.lk/en/fmcm/	Sri Lanka's Foreign Minister Prof. G. L. Peiris recently met with Singapore's Senior Minister and Coordinating Minister for Social Policies, Tharman Shanmugaratnam, at the Ministry of Finance in Singapore on 9 January. The meeting aimed to discuss bilateral relations and cooperation between the two countries.	Ministry News	2025-09-28 09:13:39.845962
120	20	Foreign Minister Peiris in Singapore for Official Visit	10.06.2022	https://mfa.gov.lk/en/sp6-10/	Foreign Minister Prof. G. L. Peiris visited Singapore from June 8-9, 2022, at the invitation of Singapore's Minister for Foreign Affairs, Dr. Vivian Balakrishnan. The visit was an official engagement aimed at strengthening diplomatic ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
121	20	Ambassador of Qatar calls on the Minister of Foreign Affairs	08.06.2022	https://mfa.gov.lk/en/ambassador-qatar/	Ambassador Jassim bin Jaber Al-Sorour of Qatar visited Minister of Foreign Affairs Prof. G.L. Peiris at the Ministry of Foreign Affairs on June 6, 2022. The meeting aimed to discuss diplomatic matters and strengthen bilateral relations between the two countries.	Ministry News	2025-09-28 09:13:39.845962
122	20	Foreign Minister Peiris to visit Singapore for bilateral visit and take part in Asia Security Summit	07.06.2022	https://mfa.gov.lk/en/singapore-asia-security-summit/	Foreign Minister Prof. G.L. Peiris will visit Singapore on June 8-9, 2022, at the invitation of Singapore's Foreign Affairs Minister Vivian Balakrishnan for a bilateral visit. He will also participate in the Asia Security Summit during his visit.	Ministry News	2025-09-28 09:13:39.845962
123	20	​Minister of Foreign Affairs chairs a webinar on current challenges to the economy and seeking remedies through all Missions abroad	07.06.2022	https://mfa.gov.lk/en/webinar-economic-channelings/	The Minister of Foreign Affairs, Prof. G.L. Peiris, chaired a webinar addressing current economic challenges and seeking solutions through all Missions abroad. The webinar was attended by the Governor of the Central Bank, Dr. Nandalal Weerasinghe, the Secretary of Foreign Affairs, Aruni Wijewardane, and heads of all overseas missions. Discussions focused on strategies to address the economic issues faced by the country.	Ministry News	2025-09-28 09:13:39.845962
124	20	Foreign Minister Peiris thanks Indian High Commissioner Baglay for generous assistance	06.06.2022	https://mfa.gov.lk/en/fam-indian-hc/	Foreign Minister Prof. G.L. Peiris expressed gratitude to Indian High Commissioner Shri Gopal Baglay for their generous assistance during a meeting at the Ministry of Foreign Affairs on June 2, 2022. The discussion likely focused on strengthening bilateral relations between Sri Lanka and India.	Ministry News	2025-09-28 09:13:39.845962
125	20	Chinese Ambassador pays a courtesy call on the Minister of Foreign Affairs	05.06.2022	https://mfa.gov.lk/en/china-fam-sl/	Chinese Ambassador Qi Zhenhong paid a courtesy call on Sri Lanka's Minister of Foreign Affairs, Prof. G.L. Peiris, at the Ministry on June 2, 2022. During the meeting, Ambassador Zhenhong briefed the Minister on assistance initiatives.	Ministry News	2025-09-28 09:13:39.845962
126	20	Statement by the Ministry of Foreign Affairs on the Aeroflot passenger aircraft at the Bandaranaike International Airport	04.06.2022	https://mfa.gov.lk/en/statement-mfa-sl-aeroflot/	The Ministry of Foreign Affairs issued a statement regarding the Aeroflot passenger aircraft flight SU-289 at Bandaranaike International Airport. The statement was made on 2 June 2022.	Ministry News	2025-09-28 09:13:39.845962
127	20	Minister of Foreign Affairs Prof. Peiris addresses Colombo based Diplomatic corps on the present situation in Sri Lanka	02.06.2022	https://mfa.gov.lk/en/mfa-sl-colombo-based-dip-corps/	Minister of Foreign Affairs Prof. G. L. Peiris addressed the Colombo-based Diplomatic Corps on June 2, 2022, at the Ministry of Foreign Affairs in Sri Lanka. During his briefing, he outlined the current situation in the country.	Ministry News	2025-09-28 09:13:39.845962
128	20	Foreign Minister Peiris meets with Japanese Deputy Head of Mission	31.05.2022	https://mfa.gov.lk/en/fm-sl-japanese-dh-of-mission/	Foreign Minister Prof. G.L. Peiris met with Japanese Deputy Head of Mission Katsuki Kotaro on May 27, 2022. They discussed bilateral engagements, domestic developments, and assistance during the meeting.	Ministry News	2025-09-28 09:13:39.845962
129	20	​Foreign Minister Peiris seeks assistance from the World Bank	30.05.2022	https://mfa.gov.lk/en/fam-sl-world-bank/	Foreign Minister Prof. G.L. Peiris met with World Bank Country Manager Chiyo Kanda in Colombo on May 27, 2022, seeking assistance. The meeting took place at the Ministry of Foreign Affairs.	Ministry News	2025-09-28 09:13:39.845962
130	20	​Foreign Minister Peiris meets with U.S. Ambassador Chung	29.05.2022	https://mfa.gov.lk/en/us-ambassador-fam-sl-2/	Foreign Minister Prof. G.L. Peiris met with U.S. Ambassador Julie Chung at the Ministry of Foreign Affairs on Friday, 27 May 2022. They discussed a wide range of topics, focusing on bilateral relations and current domestic developments.	Ministry News	2025-09-28 09:13:39.845962
131	20	British High Commissioner Hulton meets with Foreign Minister Peiris to discuss recent developments	27.05.2022	https://mfa.gov.lk/en/bhc-hulton-fam-sl/	British High Commissioner Sarah Hulton met with Sri Lanka's Foreign Minister G.L. Peiris on May 26, 2022, to discuss recent developments. During the meeting at the Ministry of Foreign Affairs, Hulton congratulated Peiris.	Ministry News	2025-09-28 09:13:39.845962
132	20	Foreign​ Affairs ​Minister Peiris meets with the UN Food and Agriculture Organization (FAO) Representative and the Country Director of the World Food Programme (WFP) to Sri Lanka	26.05.2022	https://mfa.gov.lk/en/fam-sl-fao/	Foreign Affairs Minister Prof. G.L. Peiris held meetings with Vimlendra Sharan, the UN Food and Agriculture Organization (FAO) Representative, and Abdur Rahim Siddiqui, the Country Director of the World Food Programme (WFP) in Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
133	20	Foreign ​Affairs ​Minister Peiris meets with the World Health Organisation (WHO) Representative to Sri Lanka	26.05.2022	https://mfa.gov.lk/en/representative-who-fam-sl/	Foreign Affairs Minister Prof. G.L. Peiris met with Dr. Alaka Singh, the World Health Organisation (WHO) Representative to Sri Lanka, on May 25, 2022, at the Ministry of Foreign Affairs to discuss ongoing health-related matters.	Ministry News	2025-09-28 09:13:39.845962
134	20	UN assures assistance to Sri Lanka in addressing current economic challenges	24.05.2022	https://mfa.gov.lk/en/un-fam-sl/	The Minister of Foreign Affairs, Prof. G. L. Peiris, met with the UN Resident Coordinator in Colombo, Hanaa Singer-Hamdy on May 23, 2022, to address the economic challenges facing Sri Lanka. The UN has pledged assistance to help the country navigate through the current economic situation.	Ministry News	2025-09-28 09:13:39.845962
135	20	New Foreign Secretary Aruni Wijewardane assumes duties	23.05.2022	https://mfa.gov.lk/en/newsec/	Aruni Wijewardane assumed duties as the new Secretary to the Ministry of Foreign Affairs on 23 May 2022, following her appointment with effect from 20 May 2022. The ceremony marking her assumption of office was held at the Foreign Ministry.	Ministry News	2025-09-28 09:13:39.845962
137	20	Sri Lanka Missions abroad generate Rs.3,221 million in the year 2021	20.05.2022	https://mfa.gov.lk/en/slmiss2021/	Sri Lanka's Missions abroad generated Rs.3,221 million in 2021, according to the Ministry of Foreign Affairs. The revenue was generated amidst the challenges posed by the COVID-19 pandemic.	Ministry News	2025-09-28 09:13:39.845962
138	20	The Sri Lanka rejects motion on alleged genocide adopted in Canadian Parliament	19.05.2022	https://mfa.gov.lk/en/slrejects/	The Government of Sri Lanka expressed regret over the Canadian Parliament's adoption of a motion on the alleged genocide of Tamils in Sri Lanka and the recognition of May 18 as Tamil Genocide Remembrance Day. Sri Lanka rejected the motion.	Ministry News	2025-09-28 09:13:39.845962
139	20	Minister of Foreign Affairs signs the Book of Condolence	16.05.2022	https://mfa.gov.lk/en/mfasl-signs-condolence-book/	The Minister of Foreign Affairs, Prof. G.L. Peiris, signed the book of condolence at the residence of the Ambassador following the passing of the President of the United Arab Emirates, Sheikh Khalifa bin Zayed Al Nahyan.	Ministry News	2025-09-28 09:13:39.845962
140	20	The message of H.E. Gotabaya Rajapaksa President of Sri Lanka for Vesak Day 2022	15.05.2022	https://mfa.gov.lk/en/presidents-vesak-day-message/	Sri Lankan President Gotabaya Rajapaksa delivered a message for Vesak Day 2022, emphasizing the significance of the occasion. In his address, he highlighted the importance of peace, compassion, and unity in celebrating Vesak.	Ministry News	2025-09-28 09:13:39.845962
141	20	Demise of Consul General of Sri Lanka in Sydney Lakshman Hulugalle	14.05.2022	https://mfa.gov.lk/en/demise-consul-general-of-sl-in-sydney/	The Ministry of Foreign Affairs announced the passing of Consul General of Sri Lanka in Sydney, Lakshman Hulugalle, who died in Sydney, Australia on Saturday, May 14, 2022. He passed away due to a undisclosed cause. Our condolences go out to his family and loved ones during this difficult time.	Ministry News	2025-09-28 09:13:39.845962
142	20	​Australia delegation in Colombo marks 75th Anniversary of relations	01.05.2022	https://mfa.gov.lk/en/australia-cmb-75-relations/	A delegation from Australia, led by Gary Cowan, the First Assistant Secretary of the Department of Foreign Affairs and Trade, visited Colombo to commemorate the 75th Anniversary of diplomatic relations. During the visit, discussions were held with officials from the Ministry of Foreign Affairs.	Ministry News	2025-09-28 09:13:39.845962
143	20	Diplomatic briefing by Foreign Minister Peiris on post conflict reconciliation and related issues	29.04.2022	https://mfa.gov.lk/en/dbfm29/	Foreign Minister Prof. G.L. Peiris briefed a group of Ambassadors on April 26, 2022, highlighting the Government of Sri Lanka's progress in addressing post-conflict reconciliation and related issues.	Ministry News	2025-09-28 09:13:39.845962
144	20	Indonesia donates 3.1 tonnes of Humanitarian Aid to Sri Lanka	28.04.2022	https://mfa.gov.lk/en/indonesia-donates-to-sl/	Indonesia donated 3.1 tonnes of humanitarian aid to Sri Lanka. Minister of Foreign Affairs Prof. G.L. Peiris received Ambassador Dewi Gustina Tobing at the Foreign Ministry on April 27, 2022, who provided an update on the aid from the Indonesian government.	Ministry News	2025-09-28 09:13:39.845962
145	20	ICRC to provide humanitarian assistance to Sri Lanka	27.04.2022	https://mfa.gov.lk/en/icrc-mfa-sl/	The Head of the ICRC Delegation in Sri Lanka, Loukas Petridis, met with Foreign Affairs Minister Prof. G.L. Peiris on April 25, 2022, to discuss providing humanitarian assistance. The ICRC aims to support Sri Lanka in addressing humanitarian needs effectively.	Ministry News	2025-09-28 09:13:39.845962
146	20	Sri Lanka collaborates with Blue Planet Fund	22.04.2022	https://mfa.gov.lk/en/bpf/	Sri Lanka recently collaborated with the Blue Planet Fund (BPF) through the Ocean Country Partnership Programme (OCPP). The partnership was officially introduced during the Biodiversity Stakeholder Session held on 14 March at the Ministry of Environment.	Ministry News	2025-09-28 09:13:39.845962
147	20	Chinese Ambassador pledges continues support to Sri Lanka	21.04.2022	https://mfa.gov.lk/en/china-sl-pledges-support/	Chinese Ambassador Qi Zhenhong pledged continued support to Sri Lanka during a meeting with Minister of Foreign Affairs, Professor G.L. Peiris on April 21, 2022. Minister Peiris welcomed the Ambassador and expressed appreciation for China's ongoing assistance.	Ministry News	2025-09-28 09:13:39.845962
148	20	Pakistan’s Anti-Terrorism Court sentences six of the accused to death for the murder of Sri Lankan factory manager Priyantha Kumara Diyawadanage	20.04.2022	https://mfa.gov.lk/en/atc-pakistan-priyantha/	Pakistan's Anti-Terrorism Court in Gujranwala sentenced six individuals to death for the murder of Sri Lankan factory manager Priyantha Kumara Diyawadanage. The Ministry of Foreign Affairs has welcomed this verdict, which was issued on April 18, 2022.	Ministry News	2025-09-28 09:13:39.845962
149	20	​Minister of Foreign Affairs Prof. Peiris briefs donor nations	17.04.2022	https://mfa.gov.lk/en/mfa-briefs-donar-nations/	Minister of Foreign Affairs Prof. Peiris, along with Minister of Finance M. U. M. Ali Sabry PC and the Governor of the Central Bank Dr. Nandalal Weer, briefed donor nations at the Ministry of Foreign Affairs on April 12, 2022.	Ministry News	2025-09-28 09:13:39.845962
150	20	Bandu Samarasinghe not appointed Consul General in Milan	16.04.2022	https://mfa.gov.lk/en/mil/	The Ministry of Foreign Affairs has clarified that Mr. Bandu Samarasinghe will not be appointed as the Consul General in Milan. This decision was confirmed by the Ministry in Colombo on April 16, 2022.	Ministry News	2025-09-28 09:13:39.845962
151	20	The message of H.E. Gotabaya Rajapaksa, President of Sri Lanka for Easter Sunday	15.04.2022	https://mfa.gov.lk/en/easter-sunday-message/	President of Sri Lanka, H.E. Gotabaya Rajapaksa, delivered a message for Easter Sunday. The message emphasized the significance of the occasion and conveyed well wishes to the nation.	Ministry News	2025-09-28 09:13:39.845962
152	20	President’s New Year Message	13.04.2022	https://mfa.gov.lk/en/presidents-new-year-message-sl/	President delivers a New Year message in English and Tamil to the nation. The message highlights key priorities and goals for the upcoming year, emphasizing unity and progress for all citizens.	Ministry News	2025-09-28 09:13:39.845962
153	20	Minister of Foreign Affairs Prof. Peiris briefs NAM envoys	10.04.2022	https://mfa.gov.lk/en/maf-nam-envoys/	Minister of Foreign Affairs Professor G.L. Peiris briefed High Commissioners and Ambassadors from Non-Aligned Movement (NAM) countries at the Ministry of Foreign Affairs on April 7, 2022. The meeting aimed to discuss important diplomatic matters and strengthen relationships within the NAM.	Ministry News	2025-09-28 09:13:39.845962
154	20	The Ministry of Foreign Affairs notes that attention has been focused on the revision of the U.S. Travel Advisory	08.04.2022	https://mfa.gov.lk/en/usad/	The Ministry of Foreign Affairs highlights the recent revision of the U.S. Travel Advisory for Sri Lanka as of April 6, 2022. This revision follows the ongoing attention since June 2021, amidst the COVID-19 pandemic. The Ministry emphasizes the importance of staying informed about travel advisories for Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
155	20	Sri Lankan Community in Jordan donates Medical Equipment	08.04.2022	https://mfa.gov.lk/en/sljo/	The Sri Lankan Community in Jordan donated medical equipment through the Sri Lankan Embassy in Jordan. The donation was handed over at a ceremony, strengthening ties between the two nations.	Ministry News	2025-09-28 09:13:39.845962
156	20	Sri Lankan Community in Frankfurt donates Medical Equipment	08.04.2022	https://mfa.gov.lk/en/slcfr/	The Sri Lankan Community in Frankfurt, Germany donated medical equipment through the Consulate General of Sri Lanka in Frankfurt. The donation was handed over to support healthcare efforts in the region.	Ministry News	2025-09-28 09:13:39.845962
157	20	Sri Lanka and the Netherlands hold inaugural bilateral political consultations	07.04.2022	https://mfa.gov.lk/en/slnl/	Sri Lanka and the Netherlands held their first bilateral political consultations at the Foreign Ministry level on April 5, 2022, conducted virtually. The consultations marked an important milestone in the diplomatic relations between the two countries.	Ministry News	2025-09-28 09:13:39.845962
158	20	​Minister of Foreign Affairs Prof. Peiris briefs Colombo based Diplomatic corps on the prevailing situation in Sri Lanka	07.04.2022	https://mfa.gov.lk/en/diplomatic-corps-sl-mfa/	Minister of Foreign Affairs Prof. G. L. Peiris briefed the Colombo-based Diplomatic corps on the current situation in Sri Lanka on April 6, 2022. He emphasized the Government's stance during the address at the Ministry of Foreign Affairs.	Ministry News	2025-09-28 09:13:39.845962
159	20	Temporary Closure of Sri Lanka’s Embassies in Oslo and Baghdad, and Consulate General in Sydney	05.04.2022	https://mfa.gov.lk/en/temporary-closure/	The Ministry of Foreign Affairs has started the process of temporarily closing the Sri Lanka Embassies in Oslo and Baghdad, along with the Consulate General in Sydney. This decision follows a recent announcement by the Cabinet of Ministers.	Ministry News	2025-09-28 09:13:39.845962
160	20	Korea doubles its employment quota for Sri Lankan migrant workers and increases Overseas Development Assistance amount to Sri Lanka- Minister for Government Policy Coordination of the Republic of Korea, Koo Yun-cheol	05.04.2022	https://mfa.gov.lk/en/sl-mfa-south-korea/	During an official visit to Sri Lanka, Minister Koo Yun-cheol of the Republic of Korea announced the doubling of the employment quota for Sri Lankan migrant workers and an increase in Overseas Development Assistance to Sri Lanka. Minister Koo Yun-cheol met with Sri Lankan Minister of Foreign Affairs, Prof. G.L. Peiris, on April 1, 2022, to discuss these developments and strengthen bilateral relations.	Ministry News	2025-09-28 09:13:39.845962
161	20	Outgoing Ambassador for Saudi Arabia calls on Foreign Minister Prof. Peiris	01.04.2022	https://mfa.gov.lk/en/s-a-04_01/	Ambassador Abdulnaser bin Hussain Al-Harthi of Saudi Arabia bid farewell to Foreign Minister Prof. G.L. Peiris on March 25, 2022, at the Ministry of Foreign Affairs in Colombo. The meeting marked the conclusion of his term as the Saudi Arabian Ambassador.	Ministry News	2025-09-28 09:13:39.845962
162	20	Foreign Ministers of Sri Lanka and Nepal renew commitment to further expand bilateral relations into new areas of cooperation	01.04.2022	https://mfa.gov.lk/en/nepal01-04/	During the BIMSTEC Summit in Colombo, Foreign Minister of Nepal Dr. Narayan Khadka met with Prof. G.L. Peiris, Sri Lanka's Minister of Foreign Affairs, renewing their commitment to expand bilateral relations into new areas of cooperation. The meeting emphasized strengthening ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
163	20	The Minister of Foreign Affairs of Sri Lanka and the Deputy Prime Minister and Foreign Minister of Thailand hold discussions on the sidelines of the BIMSTEC Summit	31.03.2022	https://mfa.gov.lk/en/fam-sl-dpm-fm-thailand-bimstec/	Minister of Foreign Affairs Prof. G. L. Peiris and Deputy Prime Minister and Foreign Minister of Thailand Don Pramudwinai held discussions on the sidelines of the 5th Bay of Bengal Initiative for Multi-Sectoral Technical and Economic Cooperation (BIMSTEC) Summit. The meeting aimed to strengthen bilateral relations between Sri Lanka and Thailand.	Ministry News	2025-09-28 09:13:39.845962
164	20	The Minister of Foreign Affairs of Sri Lanka and the Foreign Minister of Bangladesh hold discussions on the sidelines of the BIMSTEC Summit	31.03.2022	https://mfa.gov.lk/en/bimstec-bangladesh-sl-fam/	The Minister of Foreign Affairs of Sri Lanka, Prof. G. L. Peiris, and the Foreign Minister of Bangladesh, Dr. A. K. Abdul Momen MP, held discussions on the sidelines of the 5th Bay of Bengal Initiative for Multi-Sectoral Technical and Economic Cooperation (BIMSTEC) Summit. The meeting aimed to strengthen bilateral ties and cooperation between the two countries.	Ministry News	2025-09-28 09:13:39.845962
165	20	​President Gotabaya Rajapaksa chairs the 5th BIMSTEC Summit in Colombo	30.03.2022	https://mfa.gov.lk/en/president-chairs-5th-bimstec/	President Gotabaya Rajapaksa of Sri Lanka chaired the 5th BIMSTEC Summit in Colombo on March 30, 2022, held in virtual mode. The Summit focused on enhancing cooperation among BIMSTEC member countries.	Ministry News	2025-09-28 09:13:39.845962
166	20	Ministerial Meeting of BIMSTEC held in Colombo	29.03.2022	https://mfa.gov.lk/en/ministerial-meeting-of-bimstec-held-in-colombo/	The 18th Ministerial Meeting of BIMSTEC took place on March 29, 2022, in Colombo at the Bandaranaike Memorial International Conference Hall (BMICH).	Ministry News	2025-09-28 09:13:39.845962
167	20	Minister of External Affairs of India Dr. S. Jaishankar and the Minister of Foreign Affairs of Sri Lanka Prof. G.L Peiris hold talks on the sidelines of the BIMSTEC Summit	29.03.2022	https://mfa.gov.lk/en/mfa-sl-moea-india-bimstec/	During his official visit for the 5th BIMSTEC Summit in Colombo, India's Minister of External Affairs Dr. S. Jaishankar met with Sri Lanka's Minister of Foreign Affairs Prof. G.L Peiris to discuss bilateral matters. The talks took place on the sidelines of the summit.	Ministry News	2025-09-28 09:13:39.845962
168	20	BIMSTEC Senior Officials’ Meeting held in Colombo today	28.03.2022	https://mfa.gov.lk/en/bimstec-colombo/	The BIMSTEC Senior Officials’ Meeting took place in Colombo today, chaired by Sri Lanka. The meeting was held in hybrid mode on 28 March 2022.	Ministry News	2025-09-28 09:13:39.845962
169	20	​U.S. Under Secretary for Political Affairs, Victoria Nuland concludes successful visit to Sri Lanka	28.03.2022	https://mfa.gov.lk/en/us-under-secretary-sl/	U.S. Under Secretary for Political Affairs, Victoria Nuland successfully concluded her visit to Sri Lanka on March 23, 2022. She engaged in productive discussions with Sri Lanka's Minister of Foreign Affairs, G.L. Peiri during her visit.	Ministry News	2025-09-28 09:13:39.845962
170	20	Minister of Foreign​ Affairs​ Prof. Peiris meets the Ambassador of South Africa	27.03.2022	https://mfa.gov.lk/en/fam-sl-meets-ambassador-sa/	Minister of Foreign Affairs Professor G. L. Peiris met with the Ambassador of South Africa, Sandile Edwin Schalk, at the Ministry of Foreign Affairs on 25 March 2021. The main focus of the discussion was to enhance diplomatic relations between the two countries.	Ministry News	2025-09-28 09:13:39.845962
171	20	Sri Lanka hosts the Fifth BIMSTEC Summit in Colombo	27.03.2022	https://mfa.gov.lk/en/sl-hosts-5th-bimstec-cmb/	Sri Lanka will host the Fifth BIMSTEC Summit in Colombo from 28-30 March 2022 in a hybrid mode. The summit will bring together Senior Officials from member countries for discussions on technical and economic cooperation in the Bay of Bengal region.	Ministry News	2025-09-28 09:13:39.845962
172	20	Foreign Minister Peiris meets a delegation of French Senators	25.03.2022	https://mfa.gov.lk/en/fam-french-senators/	Foreign Minister Professor G.L. Peiris met with a delegation of French Senators from the French Republic in Colombo on Thursday, 24 March 2022. The discussions during the meeting covered a variety of issues, enhancing diplomatic relations between the two countries.	Ministry News	2025-09-28 09:13:39.845962
173	20	Foreign Minister Prof. Peiris discusses follow-up action on matters raised at the Mobile Service “Access to Justice” in Jaffna	24.03.2022	https://mfa.gov.lk/en/fam-mof-special-mobile-service/	Foreign Minister Prof. G.L. Peiris led a meeting on March 21, 2022, with Justice Minister Ali Sabry and MP Angajan Ramanathan to address follow-up actions from the "Access to Justice" Mobile Service event in Jaffna. Discussions focused on addressing key issues raised during the event.	Ministry News	2025-09-28 09:13:39.845962
174	20	Sri Lanka participates at “EnviroteQ|AgriteQ 2022” in Doha	23.03.2022	https://mfa.gov.lk/en/sri-lanka-participates-at-enviroteqagriteq-2022-in-doha/	Sri Lanka participated in "EnviroteQ|AgriteQ 2022" in Doha for the first time, showcasing its agricultural products in collaboration with the Export Development Board. The event marked Qatar's 9th International Agriculture Exhibition, organized by the Sri Lanka Embassy in Doha.	Ministry News	2025-09-28 09:13:39.845962
175	20	Joint Statement-Fourth Session of the Sri Lanka – United States Partnership Dialogue	23.03.2022	https://mfa.gov.lk/en/joint-statement-4th-session-usa/	The Governments of Sri Lanka and the United States released a joint statement on the Fourth Sri Lanka – U.S. Partnership Dialogue held on March 23, 2022, in Colombo. The statement outlines the discussions and agreements reached during the dialogue.	Ministry News	2025-09-28 09:13:39.845962
176	20	Minister of Foreign Affairs Prof. Peiris and Qatar’s Ambassador Al – Sorour discuss the multifaceted relations between Sri Lanka and Qatar	22.03.2022	https://mfa.gov.lk/en/mfa-sl-qatar/	Minister of Foreign Affairs Prof. G. L. Peiris met with Qatar's Ambassador Jassim bin Jaber J.B. Al-Sorour on March 21, 2022, in Colombo to discuss the multifaceted relations between Sri Lanka and Qatar. The meeting took place at the Ministry of Foreign Affairs, focusing on strengthening bilateral ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
177	20	Minister of Foreign Affairs Prof. Peiris and United Arab Emirates Ambassador Al – Ameri discuss the importance of strengthening bilateral cooperation	22.03.2022	https://mfa.gov.lk/en/mfa-sl-uae-ambassador/	Minister of Foreign Affairs Prof. G.L. Peiris and United Arab Emirates Ambassador Khaled Nasser Al-Ameri discussed the importance of enhancing bilateral cooperation during a meeting at the Ministry of Foreign Affairs in Colombo on March 16, 2022. They emphasized the need to strengthen ties between Sri Lanka and the United Arab Emirates.	Ministry News	2025-09-28 09:13:39.845962
178	20	​U.S. Under Secretary for Political Affairs, Victoria Nuland to visit Sri Lanka	21.03.2022	https://mfa.gov.lk/en/us-secretary-visit-sl/	U.S. Under Secretary for Political Affairs, Victoria Nuland, will visit Sri Lanka from March 22 to 23, 2022. She oversees regional and bilateral policy issues at the U.S. Department of State. This visit aims to strengthen diplomatic relations between the two countries.	Ministry News	2025-09-28 09:13:39.845962
179	20	​Newly Appointed Egyptian Ambassador to Sri Lanka calls on the Minister of Foreign Affairs	21.03.2022	https://mfa.gov.lk/en/egypt-sl-fam/	The newly appointed Egyptian Ambassador to Sri Lanka, Maged Mosleh, met with the Minister of Foreign Affairs, Prof. G.L. Peiris, on March 19, 2022, at the Ministry of Foreign Affairs in Colombo. During the meeting, Minister Peiris extended a warm welcome and discussed bilateral relations between the two countries.	Ministry News	2025-09-28 09:13:39.845962
180	20	Chinese Ambassador pays courtesy call on the Minister of Foreign Affairs	20.03.2022	https://mfa.gov.lk/en/sl-fam-china/	Chinese Ambassador Qi Zhenhong paid a courtesy call on Sri Lankan Minister of Foreign Affairs Prof. G.L Peiris on March 18, 2022. The meeting included discussions and the presentation of a first-day cover issued by the Chinese authorities.	Ministry News	2025-09-28 09:13:39.845962
181	20	​Foreign Secretary Colombage discusses areas of cooperation with the new U.S. Ambassador to Sri Lanka	18.03.2022	https://mfa.gov.lk/en/fam-secretary-us-ambassador/	Foreign Secretary Colombage met with the new U.S. Ambassador to Sri Lanka, Julie Chung, on March 16, 2022, at the Ministry of Foreign Affairs. They discussed areas of cooperation between the two countries.	Ministry News	2025-09-28 09:13:39.845962
182	20	​Foreign Minister Prof. Peiris meets Core Group in Sri Lanka	18.03.2022	https://mfa.gov.lk/en/fam-meets-core-group/	Foreign Minister Prof. Peiris held an informal discussion with the Core Group on Sri Lanka at the Ministry of Foreign Affairs on Friday, March 18. The meeting included the Secretary to the Ministry of Foreign Affairs.	Ministry News	2025-09-28 09:13:39.845962
183	20	​Joint Press Statement of the 5th NSA Level Meeting of the Colombo Security   Conclave held on 09 – 10 March 2022, in Maldives.	16.03.2022	https://mfa.gov.lk/en/5th-nsa-level-meeting/	Delegations from the founding members of the Colombo Security Conclave - Maldives, India, and Sri Lanka - along with the newest member, Mauritius, successfully concluded the 5th National Security Advisor Level Meeting held on 09-10 March 2022 in Maldives.	Ministry News	2025-09-28 09:13:39.845962
184	20	Foreign Minister conveys Sri Lanka’s concerns over UK Travel Advisory	16.03.2022	https://mfa.gov.lk/en/fam-uk-travel-advisory/	Foreign Minister Prof. G.L. Peiris raised concerns about inaccuracies in the UK Travel Advisory on Sri Lanka, leading to a negative portrayal of the country. He highlighted the need for revisions to present a more accurate image.	Ministry News	2025-09-28 09:13:39.845962
185	20	Sri Lanka delegation attends the 49th Session of the Human Rights Council in Geneva	15.03.2022	https://mfa.gov.lk/en/49th-unhrc-sl-fam/	Sri Lanka's delegation, led by Minister of Foreign Affairs Prof. G.L. Peiris, participated in the 49th Session of the Human Rights Council in Geneva. The delegation also included Minister of Justice Ali Sabry and State Minister.	Ministry News	2025-09-28 09:13:39.845962
186	20	​​Minister of Foreign Affairs of the Kingdom of Saudi Arabia, Prince Faisal bin Farhan bin Abdulla Al Saud and the accompanying delegation make an official visit to Sri Lanka	14.03.2022	https://mfa.gov.lk/en/mfa-sl-ksa-fam/	The Minister of Foreign Affairs of Saudi Arabia, Prince Faisal bin Farhan bin Abdulla Al Saud, and his delegation visited Sri Lanka. During the visit, they paid courtesy calls on President Gotabaya Rajapaksa and Prime Minister Mahinda Rajapaksa.	Ministry News	2025-09-28 09:13:39.845962
187	20	​Cabinet Sub Committees on Economic Way Forward initiate deliberations under the Chairmanship of Minister of Foreign Affairs Prof. G.L. Peiris	13.03.2022	https://mfa.gov.lk/en/economic-sub-committees-fam/	Cabinet Sub Committees on Economic Way Forward, chaired by Minister of Foreign Affairs Prof. G.L. Peiris, began deliberations on economic matters with China, Japan, and the Middle East last month. The committees held their inaugural meetings on March 9 and 10, 2022, at the Parli.	Ministry News	2025-09-28 09:13:39.845962
188	20	​New U.S. Ambassador to Sri Lanka calls on Foreign Affairs Minister Peiris	10.03.2022	https://mfa.gov.lk/en/us-ambassador-fam-sl/	The newly appointed U.S. Ambassador to Sri Lanka, Julie Chung, met with Foreign Affairs Minister G.L. Peiris on March 9, 2022, at the Ministry of Foreign Affairs in Colombo. Minister Peiris warmly welcomed Ambassador Chung during the visit.	Ministry News	2025-09-28 09:13:39.845962
189	20	​Overwhelming support for Sri Lanka at the Interactive Dialogue at the Human Rights Council	08.03.2022	https://mfa.gov.lk/en/unhrc-interactive-dialogue/	During the Interactive Dialogue at the Human Rights Council, Sri Lanka garnered significant support from countries in the Global South regarding the written update by the High Commissioner for Human Rights on March 7, 2022.	Ministry News	2025-09-28 09:13:39.845962
190	20	​Interactive dialogue on the OHCHR report on Sri Lanka  Statement by Hon. Prof. G.L. Peiris Minister of Foreign Affairs of Sri Lanka  (Geneva, 04 March 2022)	05.03.2022	https://mfa.gov.lk/en/ohchr-statement-sl-fam/	During an interactive dialogue on the OHCHR report on Sri Lanka, Hon. Prof. G.L. Peiris, the Minister of Foreign Affairs of Sri Lanka, stated that Resolution 46/1 was adopted by a divided vote in the Council. Sri Lanka and other Member States opposed the resolution due to fundamental disagreement with its deeply flawed procedure.	Ministry News	2025-09-28 09:13:39.845962
191	20	​Advisory to Sri Lankan Students in Belarus	04.03.2022	https://mfa.gov.lk/en/advisory-sl-students-belarus/	The Ministry of Foreign Affairs, in coordination with the Sri Lanka Embassy in Moscow, is monitoring the situation in Belarus regarding recent developments. An advisory has been issued to Sri Lankan students in Belarus to stay informed and take necessary precautions. Sri Lankan students are encouraged to follow guidance from the embassy for their safety and well-being.	Ministry News	2025-09-28 09:13:39.845962
192	20	​Foreign Affairs Minister Prof. Peiris holds multiple meetings on the sidelines of the Human Rights Council in Geneva	04.03.2022	https://mfa.gov.lk/en/unhrc-uk-usa-iran-sl-fam/	Foreign Affairs Minister Prof. G.L. Peiris held meetings with the Permanent Representatives of the United States of America, the United Kingdom, and Iran on the sidelines of the Human Rights Council in Geneva. Among those he met were Bathsheba Nell Crocker, Simon Manley, and Esmaeil Bghaei Hamaneh.	Ministry News	2025-09-28 09:13:39.845962
193	20	​Foreign Affairs Minister G.L. Peiris meets with President of the Human Rights Council and Permanent Representative of Argentina	04.03.2022	https://mfa.gov.lk/en/fam-unhrc-argentina/	Foreign Affairs Minister Prof. G.L. Peiris met with Federico Villegas, President of the Human Rights Council and Permanent Representative of Argentina, at the Palais des Nations. They discussed a range of issues during the meeting.	Ministry News	2025-09-28 09:13:39.845962
194	20	​Foreign Affairs Minister G.L. Peiris meets with the United Nations High Commissioner for Human Rights	03.03.2022	https://mfa.gov.lk/en/fam-sl-unhc/	Foreign Affairs Minister G.L. Peiris met with United Nations High Commissioner for Human Rights Michelle Bachelet at her office in the Palaise des Nations in Geneva. They engaged in wide-ranging discussions during the meeting.	Ministry News	2025-09-28 09:13:39.845962
195	20	Foreign Affairs Minister Peiris holds multiple meetings on the sidelines of the Human Rights Council in Geneva	03.03.2022	https://mfa.gov.lk/en/fam-sl-geneva/	Foreign Affairs Minister Peiris led a high-level Sri Lankan delegation at the 49th session of the Human Rights Council in Geneva. During the event, he held meetings with delegations from Pakistan, Palestine, South Africa, and Saudi Arabia.	Ministry News	2025-09-28 09:13:39.845962
196	20	​Foreign Ministry Facilitates Evacuation of Sri Lankans in Ukraine and Belarus in Coordination with Sri Lanka Missions in Ankara, Warsaw and Moscow	02.03.2022	https://mfa.gov.lk/en/fam-sl-facilitates/	The Foreign Ministry is working closely with Sri Lanka's missions in Ankara, Warsaw, and Moscow to facilitate the safe evacuation of Sri Lankan expatriates and students from Ukraine and Belarus. Seventeen Sri Lankans have been successfully evacuated so far.	Ministry News	2025-09-28 09:13:39.845962
197	20	​Seven Sri Lankan Fishermen detained in Myanmar granted pardon by the Myanmar Government	02.03.2022	https://mfa.gov.lk/en/sl-fisherman-myanmar/	Seven Sri Lankan fishermen detained in Myanmar have been granted a pardon by the Myanmar Government. The fishermen were serving their sentences in jail, and this decision reflects the positive bilateral relations between the two countries.	Ministry News	2025-09-28 09:13:39.845962
198	20	Foreign Affairs Minister G.L. Peiris attends bilateral meetings on the sidelines of the High-Level Segment of the 49th session of the Human Rights Council in Geneva	02.03.2022	https://mfa.gov.lk/en/fam-sl-oic-wipo/	Foreign Affairs Minister G.L. Peiris and the Sri Lanka delegation held high-level bilateral meetings on February 28, 2022, with representatives from the United Kingdom, the Commonwealth Secretariat, and the Organization of Islamic Cooperation during the High-Level Segment of the 49th session of the Human Rights Council in Geneva.	Ministry News	2025-09-28 09:13:39.845962
199	20	​49th session of the Human Rights Council High Level Segment Statement by Hon. Prof. G.L. Peiris, Minister of Foreign Affairs of Sri Lanka	01.03.2022	https://mfa.gov.lk/en/49th-session-unhrc-sl/	During the 49th session of the Human Rights Council's High Level Segment, Hon. Prof. G.L. Peiris, Sri Lanka's Minister of Foreign Affairs, emphasized the country's active participation in promoting and protecting human rights within the multilateral framework. He highlighted that fundamental rights are enshrined in Sri Lanka's Constitution and continuously advanced.	Ministry News	2025-09-28 09:13:39.845962
200	20	​Developments in Ukraine: Status Update on Sri Lankan Nationals	28.02.2022	https://mfa.gov.lk/en/%e2%80%8bdevelopments-in-ukraine-sl/	The Foreign Ministry is actively monitoring developments in Ukraine and is evacuating around forty Sri Lankan nationals, including two students.	Ministry News	2025-09-28 09:13:39.845962
201	20	Strengthening Economic relations the focus of several meetings in Paris	27.02.2022	https://mfa.gov.lk/en/economic-relations-paris-sl/	Foreign Minister Prof. G.L Peiris met with Minister Delegate for Trade and Economic Attractiveness Franck Reister at the Foreign Ministry in Paris to discuss strengthening economic relations. The focus of the meetings was on French support for expanding economic ties between the two countries.	Ministry News	2025-09-28 09:13:39.845962
202	20	Appointment of ​the ​Ambassador of the State of Libya to Sri Lanka	25.02.2022	https://mfa.gov.lk/en/appointment-libya-ambassador-sl/	The State of Libya, in agreement with the Government of Sri Lanka, has appointed Mr. Nasser Yonis Alfurjani as the Ambassador Extraordinary and Plenipotentiary of Libya to Sri Lanka. He will be based in Colombo.	Ministry News	2025-09-28 09:13:39.845962
203	20	​Appointment of​ the​ Ambassador of the United States of America to Sri Lanka	25.02.2022	https://mfa.gov.lk/en/appointment-ambassador-usa-sl/	The United States of America, with the approval of the Government of Sri Lanka, has named Ms. Julie J. Chung as the Ambassador Extraordinary and Plenipotentiary to Sri Lanka. Ms. Chung will represent the United States in Sri Lanka in her new role.	Ministry News	2025-09-28 09:13:39.845962
204	20	​Appointment of ​​the ​Ambassador of ​​the United Arab Emirates to Sri Lanka	25.02.2022	https://mfa.gov.lk/en/appointment-uae-ambassador-sl/	The United Arab Emirates, with the approval of the Government of Sri Lanka, has appointed Mr. Khaled Nasser AlAmeri as the Ambassador Extraordinary and Plenipotentiary to Sri Lanka. Mr. AlAmeri will represent the United Arab Emirates in Sri Lanka in his new role.	Ministry News	2025-09-28 09:13:39.845962
205	20	Sri Lanka and the European Union identify areas for close collaboration	25.02.2022	https://mfa.gov.lk/en/sl-eu-collaboration/	Sri Lanka's Foreign Minister Prof. G.L Peiris and the European Union's Commissioner for International Partnerships Jutta Urpilainen discussed areas for collaboration at the Indo-Pacific Ministerial Forum. The meeting aimed to strengthen ties between Sri Lanka and the EU.	Ministry News	2025-09-28 09:13:39.845962
206	20	Statement on Developments in Ukraine	25.02.2022	https://mfa.gov.lk/en/mst-ukraine/	Sri Lanka's government expresses deep concern over the escalating violence in Ukraine and urges all parties to show restraint and work towards an immediate cessation of hostilities.	Ministry News	2025-09-28 09:13:39.845962
207	20	​Advisory to Sri Lankan Nationals in Ukraine	24.02.2022	https://mfa.gov.lk/en/advisory-to-sl-in-ukraine/	The Foreign Ministry has advised Sri Lankan nationals in Ukraine to stay safe amidst the escalating situation. The Sri Lanka Embassy in Ankara, which is also accredited to Kyiv, has been instructed to coordinate safe passage for its citizens. Sri Lankans in Ukraine are urged to follow the embassy's guidance for their safety.	Ministry News	2025-09-28 09:13:39.845962
208	20	Foreign Minister Prof. Peiris presents Sri Lankan perspective to senators of the French Republic	24.02.2022	https://mfa.gov.lk/en/fm-sl-senators-french-republic/	Foreign Minister Prof. G.L. Peiris presented the Sri Lankan perspective to the senators of the French Republic during a breakfast meeting with the France-Sri Lanka Friendship Group. He expressed gratitude for the opportunity to engage with the Chair and Members of the group.	Ministry News	2025-09-28 09:13:39.845962
209	20	Sri Lankan and Dutch Foreign ​Ministers resolve to intensify cooperation	24.02.2022	https://mfa.gov.lk/en/sl-dutch-fms/	Sri Lankan Foreign Minister Professor G.L Peiris and Dutch Foreign Minister Wopke Hoekstra met at the Ministerial Forum for Cooperation in the Indo-Pacific to enhance collaboration. The meeting took place at the Foreign Ministry of the Netherlands. Both ministers resolved to intensify cooperation between their countries.	Ministry News	2025-09-28 09:13:39.845962
210	20	​Foreign Minister Prof. Peiris emphasizes Sri Lanka’s role at Ocean Affairs Ministerial Forum in Paris	23.02.2022	https://mfa.gov.lk/en/fm-sl-oamf-in-paris/	Foreign Minister Prof. G.L. Peiris highlighted Sri Lanka's role at the Ocean Affairs Ministerial Forum in Paris, addressing the Ministerial Forum for Co-operation in the Indo-Pacific at the Conference Centre of the Ministry for Europe and Foreign Affairs. The forum aimed to discuss cooperation in the Indo-Pacific region.	Ministry News	2025-09-28 09:13:39.845962
211	20	​Foreign Minister Peiris addresses Diplomatic Corps based in New Delhi	22.02.2022	https://mfa.gov.lk/en/fm-sl-diplomatic-corps-nd/	Foreign Minister Prof. G.L. Peiris virtually addressed the Diplomatic Corps based in New Delhi on February 18, 2022. The briefing aimed to share updates on progress related to human rights and reconciliation efforts.	Ministry News	2025-09-28 09:13:39.845962
212	20	​Advisory on Sri Lankan Nationals in Ukraine	21.02.2022	https://mfa.gov.lk/en/advisory-on-sl-ukraine/	The Government of Sri Lanka is closely monitoring the situation in Ukraine following recent developments. The Sri Lanka Embassy in Ankara, which is also accredited to Kyiv, is maintaining close contact with its nationals in the region. Sri Lankan nationals in Ukraine are advised to stay informed and follow any guidance provided by the embassy.	Ministry News	2025-09-28 09:13:39.845962
213	20	​Foreign Minister Peiris to lead Sri Lanka’s delegation to the UNHRC	20.02.2022	https://mfa.gov.lk/en/fm-sl-unhrc/	Foreign Minister Peiris will lead Sri Lanka's delegation to the 49th Session of the United Nations Human Rights Council in Geneva from 28 February to 1 April, 2022. The UN High Commissioner for Human Rights will present a written update on Sri Lanka during the session.	Ministry News	2025-09-28 09:13:39.845962
214	20	65th Anniversary of the Establishment of Diplomatic Relations between Sri Lanka and Russia in 2022	19.02.2022	https://mfa.gov.lk/en/65th-anniversary-sl-russia-2022/	In 2022, Sri Lanka and Russia marked the 65th anniversary of establishing diplomatic relations. Messages of felicitation were exchanged between the Presidents of both countries to commemorate this milestone. The messages were also translated into English for wider understanding.	Ministry News	2025-09-28 09:13:39.845962
215	20	​Sri Lankan Missions to promote Batik, Handloom and Local Apparels	18.02.2022	https://mfa.gov.lk/en/sl-batik-promote/	Sri Lankan Missions are collaborating with the State Ministry of Batik, Handloom, and Local Apparel Products to promote Sri Lankan batik, handloom, and local apparel. A joint session was held on 18 February 2022 at the Foreign Ministry to discuss and strategize these promotional efforts.	Ministry News	2025-09-28 09:13:39.845962
216	20	Australia to assist Sri Lanka in developing a comprehensive national maritime disaster preparedness mechanism	18.02.2022	https://mfa.gov.lk/en/australia-assist-sl-maritime/	Australia is set to assist Sri Lanka in developing a comprehensive national maritime disaster preparedness mechanism. The meeting, organized by the Ocean Affairs, Environment & Climate Change Division of the Foreign Ministry and the High Commission of Australia to Sri Lanka and the Maldives, aimed to discuss this collaboration. This initiative will enhance Sri Lanka's readiness to respond to maritime disasters effectively.	Ministry News	2025-09-28 09:13:39.845962
217	20	Loan Agreement from Kuwait Fund to construct Medical Faculty at the University of Moratuwa signed in Colombo	10.02.2022	https://mfa.gov.lk/en/kuwait-fund-uom-colombo/	A delegation led by the Deputy Director General for Administration & Financial Affairs of the Kuwait Fund for Arab Economic Development (KFAED), Nedhal A. Al-Olayan, visited Sri Lanka to sign a loan agreement for constructing a Medical Faculty at the University of Moratuwa in Colombo.	Ministry News	2025-09-28 09:13:39.845962
218	20	Joint Press Release – EU-Sri Lanka Joint Commission	09.02.2022	https://mfa.gov.lk/en/eu-sri-lanka-joint-commission/	The European Union (EU) and Sri Lanka convened their 24th Joint Commission meeting on February 8, 2022, in Brussels. The meeting took place in a friendly and open atmosphere, fostering productive discussions and cooperation between the two parties.	Ministry News	2025-09-28 09:13:39.845962
219	20	Foreign Minister Prof. G.L. Peiris concludes successful visit to New Delhi	08.02.2022	https://mfa.gov.lk/en/fm-new-delhi/	Foreign Minister of Sri Lanka Prof. G.L. Peiris successfully concluded a two-day official visit to New Delhi on February 6-8, 2022. This marked his first visit to India after assuming office.	Ministry News	2025-09-28 09:13:39.845962
220	20	The proposed amendment to the present Prevention of Terrorism Act is a progressive step towards securing, advancing and protecting fundamental rights guaranteed under the Constitution	07.02.2022	https://mfa.gov.lk/en/pta-sl/	The proposed amendment to the Prevention of Terrorism Act in Sri Lanka is seen as a positive step towards safeguarding fundamental rights guaranteed under the Constitution. The Government's intention to introduce this bill in Parliament is aimed at enhancing legal protections for citizens.	Ministry News	2025-09-28 09:13:39.845962
221	20	​Israel donates a consignment of COVID 19 related medical equipment to Sri Lanka	07.02.2022	https://mfa.gov.lk/en/israel-donates-sl/	Israel, through the Israeli Agency for International Development Cooperation (MASHAV), donated a consignment of COVID-19 medical equipment to Sri Lanka. The donation includes ventilators, personal protective equipment (PPEs), and pulse oximeters, aiding Sri Lanka's efforts in combating the pandemic.	Ministry News	2025-09-28 09:13:39.845962
222	20	Israel Ambassador calls on Foreign Minister	04.02.2022	https://mfa.gov.lk/en/israel-ambassador-fm-sl/	Israel Ambassador Naor Itzhak Gilon, concurrently accredited to Sri Lanka, met with Foreign Minister Prof. G.L. Peiris on February 3, 2022. They discussed various matters of mutual interest during the courtesy call.	Ministry News	2025-09-28 09:13:39.845962
223	20	Foreign Ministry refutes claims made by Ambika Satkunanathan to the European Parliament’s Subcommittee on Human Rights	04.02.2022	https://mfa.gov.lk/en/fm-refutes-claims-ambika/	The Foreign Ministry refutes claims made by Ambika Satkunanathan to the European Parliament’s Subcommittee on Human Rights, citing numerous misleading statements in her testimony. The Ministry expressed concern over the inaccuracies presented during the exchange of views on the situation.	Ministry News	2025-09-28 09:13:39.845962
224	20	Appointment of Ambassador of the Republic of Estonia to Sri Lanka	03.02.2022	https://mfa.gov.lk/en/estonia-sl/	The Government of the Republic of Estonia, in agreement with the Government of Sri Lanka, has appointed Ms. Katrin Kivi as the Ambassador Extraordinary and Plenipotentiary of Estonia to Sri Lanka. Ms. Kivi will represent Estonia in Sri Lanka in her new diplomatic role.	Ministry News	2025-09-28 09:13:39.845962
225	20	Appointment of Ambassador of the Israel to Sri Lanka	03.02.2022	https://mfa.gov.lk/en/israel-sl/	The Government of Israel, in agreement with Sri Lanka, has appointed Mr. Naor Gilon as the new Ambassador of Israel to Sri Lanka. He will serve as the Ambassador Extraordinary and Plenipotentiary based in Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
226	20	Appointment of Ambassador of the Iceland to Sri Lanka	03.02.2022	https://mfa.gov.lk/en/iceland-sl/	The Government of Iceland, in agreement with Sri Lanka, has appointed Mr. Guðni Bragason as the new Ambassador of Iceland to Sri Lanka. Mr. Bragason will serve as the Ambassador Extraordinary and Plenipotentiary of Iceland in Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
227	20	Appointment of Ambassador of the Austria to Sri Lanka	03.02.2022	https://mfa.gov.lk/en/austria-sl/	The Government of the Republic of Austria, with the approval of the Government of Sri Lanka, has named Ms. Katharina Wieser as the new Ambassador Extraordinary and Plenipotentiary of Austria to Sri Lanka. Ms. Wieser will represent Austria in Sri Lanka in her diplomatic capacity.	Ministry News	2025-09-28 09:13:39.845962
228	20	Appointment of Ambassador of the Philippines to Sri Lanka	03.02.2022	https://mfa.gov.lk/en/philippines-sl/	The Government of the Republic of the Philippines, with the concurrence of Sri Lanka, has appointed Mr. Alan Deniega as the Ambassador Extraordinary and Plenipotentiary of the Philippines to Sri Lanka. Mr. Deniega will represent the Philippines in his new diplomatic role.	Ministry News	2025-09-28 09:13:39.845962
229	20	Appointment of Ambassador of the Republic of the Kazakhstan to Sri Lanka	03.02.2022	https://mfa.gov.lk/en/kazakhstan-sl/	The Government of Kazakhstan, with the approval of Sri Lanka, has appointed Mr. Nurlan Zhalgasbayev as the new Ambassador of Kazakhstan to Sri Lanka. Mr. Zhalgasbayev will serve as the Ambassador Extraordinary and Plenipotentiary in this role.	Ministry News	2025-09-28 09:13:39.845962
230	20	Appointment of High Commissioner of the Republic of the Gambia to Sri Lanka	03.02.2022	https://mfa.gov.lk/en/gambia-sl/	Mr. Mustapha Jawara has been appointed as the High Commissioner of the Republic of the Gambia to Sri Lanka by the Government of the Republic of the Gambia, with the concurrence of the Government of Sri Lanka. He will be based in New Delhi for his diplomatic role.	Ministry News	2025-09-28 09:13:39.845962
231	20	​​Appointment of Ambassador of the Kingdom of Denmark to Sri Lanka	03.02.2022	https://mfa.gov.lk/en/denmark-sl/	The Kingdom of Denmark, with the approval of the Government of Sri Lanka, has named Mr. Freddy Svane as the Ambassador Extraordinary and Plenipotentiary to Sri Lanka. He will be stationed in New Delhi for his diplomatic duties.	Ministry News	2025-09-28 09:13:39.845962
232	20	High Commissioner-designate of Sri Lanka to Malaysia assumes duties	03.02.2022	https://mfa.gov.lk/en/high-commissioner-designate-of-sri-lanka-to-malaysia-assumes-duties/	Air Chief Marshal Sumangala Dias, the newly appointed High Commissioner-designate of Sri Lanka to Malaysia, assumed his duties at the Sri Lanka High Commission in Kuala Lumpur on 27 January 2022. He officially began his role, representing Sri Lanka in Malaysia.	Ministry News	2025-09-28 09:13:39.845962
233	20	Sri Lanka’s Envoy to Maldives presents credentials to President Solih	03.02.2022	https://mfa.gov.lk/en/sri-lankas-envoy-to-maldives-presents-credentials-to-president-solih/	Sri Lanka's High Commissioner-designate to Maldives, A.M.J. Sadiq, presented his Letter of Credence and his predecessor's Letter of Recall to Maldives President Ibrahim Mohamed Solih.	Ministry News	2025-09-28 09:13:39.845962
234	20	Foreign Minister Peiris refutes the alleged purchase of weapons from North Korea	01.02.2022	https://mfa.gov.lk/en/fm-north-korea/	Foreign Minister Peiris has denied the reported purchase of weapons from North Korea following a news item on newsfirst.lk alleging such transactions. The Foreign Ministry addressed the claim made by Minister Basil R on January 31, 20.	Ministry News	2025-09-28 09:13:39.845962
235	20	​Donation of Medical Equipment by the Sri Lankan Community in Saudi Arabia	31.01.2022	https://mfa.gov.lk/en/donation-saudi-arabia/	The Embassy of Sri Lanka in Saudi Arabia facilitated a donation of medical equipment worth SLRs 1.2 million for hospitals in Sri Lanka. The Sri Lanka Cultural Forum collaborated with the Sri Lankan community in Saudi Arabia to make this contribution, benefiting healthcare facilities in Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
236	20	​The Minister of Foreign Affairs of Turkey pays an official visit to Sri Lanka	30.01.2022	https://mfa.gov.lk/en/fam-turkey-visit-sl/	The Minister of Foreign Affairs of Turkey visited Sri Lanka, where Foreign Minister Prof. G.L. Peiris highlighted the strong partnership between the two countries during their bilateral meeting.	Ministry News	2025-09-28 09:13:39.845962
237	20	High Commissioner – designate of Sri Lanka to Maldives presents the open copy of the letter of credentials to the Foreign Ministry in Malé	29.01.2022	https://mfa.gov.lk/en/high-commissioner-designate-of-sri-lanka-to-maldives-presents-the-open-copy-of-the-letter-of-credentials-to-the-foreign-ministry-in-male/	The High Commissioner-designate of Sri Lanka to Maldives, A.M.J. Sadiq, presented the open copy of his letter of credentials to the Foreign Ministry in Malé upon his arrival on January 25, 2022. He assumed duties at the High Commission of Sri Lanka in Malé on the same day following a simple ceremony attended by staff.	Ministry News	2025-09-28 09:13:39.845962
238	20	​Launching of 1919 Call Centre Services for Appointment Reservation System in the Consular Affairs Division of the Foreign Ministry	28.01.2022	https://mfa.gov.lk/en/1919-consular-reservation-system/	The Foreign Ministry has launched 1919 Call Centre Services to streamline appointment reservations at the Consular Affairs Division, aiding daily visitors. This collaboration with the Government Information Centre aims to enhance public assistance and operational efficiency.	Ministry News	2025-09-28 09:13:39.845962
239	20	​Foreign Minister Prof. G.L. Peiris Briefs Diplomatic Corps on Current Initiatives	27.01.2022	https://mfa.gov.lk/en/fm-briefs-dpl/	Foreign Minister Prof. G.L. Peiris briefed the Diplomatic Corps at the Foreign Ministry Auditorium on January 26, 2022, marking the first diplomatic briefing of the New Year. During the address, Foreign Minister Peiris discussed current initiatives and expressed appreciation for the diplomatic community's support.	Ministry News	2025-09-28 09:13:39.845962
240	20	Human Remains of the Late Consul General of Sri Lanka in Milan Visharada Neela Wickramasinghe to Sri Lanka	25.01.2022	https://mfa.gov.lk/en/late-consul-general-millan/	The human remains of the late Consul General of Sri Lanka in Milan, Visharada Neela Wickramasinghe, who passed away on 17 January 2022 due to a sudden illness, will be repatriated to Sri Lanka on 27 January 2022. The repatriation is scheduled to take place on the specified date.	Ministry News	2025-09-28 09:13:39.845962
241	20	​Foreign Minister Peiris Indonesia Ambassador identify areas of collaboration	25.01.2022	https://mfa.gov.lk/en/indonesia-fm-sl/	Foreign Minister Prof. G.L. Peiris and the Indonesian Ambassador discussed areas of collaboration, emphasizing the common interests and historical ties between Sri Lanka and Indonesia. They highlighted the shared goals that are rooted in their longstanding cultural connections.	Ministry News	2025-09-28 09:13:39.845962
242	20	A delegation from Bangladesh Foreign Service Academy visits the Foreign Ministry	23.01.2022	https://mfa.gov.lk/en/bangladesh-fs-academy-sl/	A delegation from the Bangladesh Foreign Service Academy visited the Foreign Ministry on January 21, 2021, as part of their study tour. The delegation was composed of Farha, the Director of the Foreign Service Academy of Bangladesh.	Ministry News	2025-09-28 09:13:39.845962
243	20	​Response to the Human Rights Watch “World Report 2022”: Sri Lanka Section	22.01.2022	https://mfa.gov.lk/en/hrw-world-report-2022-sl/	The Foreign Ministry expressed regret over the portrayal of Sri Lanka in the HRW "World Report 2022," citing it as exaggerated and overly negative. The ministry emphasized that the report does not accurately reflect the current human rights situation in the country.	Ministry News	2025-09-28 09:13:39.845962
244	20	​Foreign Minister discusses range of projects with Korean Speaker	21.01.2022	https://mfa.gov.lk/en/fm-sl-korean-speaker/	Foreign Minister Prof. G.L. Peiris hosted a lunch on January 20, 2022, in honor of the visiting Korean Delegation led by Speaker Park Byeong-Seug of the National Assembly of the Republic of Korea. They discussed a range of projects during the meeting.	Ministry News	2025-09-28 09:13:39.845962
245	20	​Joint Press Conference to launch the celebration of the 70th anniversary of the establishment of Diplomatic Relations between Sri Lanka and Japan	20.01.2022	https://mfa.gov.lk/en/japan-sl-joint-conference/	The Foreign Ministry and Embassy of Japan held a joint press conference at the Sasakawa Center to mark the 70th anniversary of diplomatic relations between Sri Lanka and Japan. The event launched the celebration of this milestone achievement.	Ministry News	2025-09-28 09:13:39.845962
246	20	​Sri Lanka and the UK acknowledge multifaceted partnership at meeting between Foreign Minister and British Minister for South Asia Lord Ahmad	19.01.2022	https://mfa.gov.lk/en/uk-sl-mou/	During a meeting between Sri Lanka's Foreign Minister Prof. G. L. Peiris and British Minister for South Asia Lord Ahmad, they acknowledged the unique and multifaceted partnership between Sri Lanka and the UK, based on shared democratic values and historical ties. The discussions highlighted the strong relationship between the two countries, emphasizing cooperation in various areas.	Ministry News	2025-09-28 09:13:39.845962
247	20	Government of Sri Lanka corrects erroneous and outdated information contained in the Canadian Travel Advisory on Sri Lanka	19.01.2022	https://mfa.gov.lk/en/sl-canadian/	The Government of Sri Lanka has corrected erroneous and outdated information in the Canadian Travel Advisory issued on January 13, 2022. The advisory did not accurately reflect the current situation in Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
248	20	Sri Lanka condemns terrorist attacks in United Arab Emirates	18.01.2022	https://mfa.gov.lk/en/condemns-attacks-uae/	Sri Lanka's government strongly condemns the recent terrorist attacks on civilian facilities in the United Arab Emirates, leading to the deaths of several civilians. We extend our deepest condolences to the families of the victims during this tragic event.	Ministry News	2025-09-28 09:13:39.845962
249	20	​Demise of Consul General of Sri Lanka in Milan Visharada Neela Wickramasinghe	18.01.2022	https://mfa.gov.lk/en/demise-visharada-wickramasinghe/	The Foreign Ministry announced the passing of Consul General of Sri Lanka in Milan, Visharada D.D. Neela Wickramasinghe, who died in Milan, Italy on January 17, 2022. The ministry expressed deep sorrow at the loss.	Ministry News	2025-09-28 09:13:39.845962
250	20	The message of H.E. Gotabaya Rajapaksa, President of Sri Lanka for Thai Pongal 2022	14.01.2022	https://mfa.gov.lk/en/the-message-of-h-e-gotabaya-rajapaksa-president-of-sri-lanka-for-thai-pongal-2022/	President of Sri Lanka, H.E. Gotabaya Rajapaksa, delivered a message for Thai Pongal 2022. The message was conveyed in English, Sinhala, and Tamil languages, emphasizing the significance of the festival for the people of Sri Lanka.	Ministry News	2025-09-28 09:13:39.845962
251	20	​Hungarian Minister of Foreign Affairs and Trade Visits Sri Lanka	13.01.2022	https://mfa.gov.lk/en/hungarian-sl-affairs/	Hungarian Minister of Foreign Affairs and Trade visited Sri Lanka, where Foreign Minister Prof. G.L. Peiris expressed Sri Lanka's interest in enhancing bilateral ties with Hungary. Both countries aim to develop a results-oriented, multi-faceted partnership.	Ministry News	2025-09-28 09:13:39.845962
252	20	​Sri Lanka to host Asian Development Bank Annual Meeting in Colombo	12.01.2022	https://mfa.gov.lk/en/adb-annual-meeting/	Sri Lanka will host the Asian Development Bank Annual Meeting in Colombo. Foreign Secretary Admiral Prof. Jayanath Colombage chaired a meeting at the Foreign Ministry on January 11, 2022, to discuss the arrangements for the event.	Ministry News	2025-09-28 09:13:39.845962
253	20	​Foreign Ministry of China donates COVID 19 related medical equipment to Sri Lanka	12.01.2022	https://mfa.gov.lk/en/china-donation/	The Foreign Ministry of China donated a large consignment of COVID-19 related medical equipment to Sri Lanka. The donation includes multipara monitors, high flow oxygen nasal therapy machines, oxygen concentrators, and oxygen cylinders. This aid aims to support Sri Lanka in its fight against the pandemic.	Ministry News	2025-09-28 09:13:39.845962
254	20	​Speaker of the National Assembly of the Republic of Korea to visit Sri Lanka next week	11.01.2022	https://mfa.gov.lk/en/rok_sl/	The Speaker of the National Assembly of the Republic of Korea, Park Byeong-Seng, will visit Sri Lanka next week. This follows recent discussions held at the Speaker’s Office in Seoul with Foreign Minister Professor G. L. Peiris.	Ministry News	2025-09-28 09:13:39.845962
255	20	​Sri Lanka and China re-affirm the special bonds of friendship between the two nations	10.01.2022	https://mfa.gov.lk/en/china-sl-friendship/	Sri Lanka's Foreign Minister Prof. G.L. Peiris emphasized the strong and diverse partnership between Sri Lanka and China during a bilateral meeting. The meeting aimed to reaffirm the special bonds of friendship between the two nations.	Ministry News	2025-09-28 09:13:39.845962
256	20	Foreign Minister of Sri Lanka meets Prime Minister of the Republic of Korea	07.01.2022	https://mfa.gov.lk/en/fm-sl-pm-korea/	During his courtesy call on the Prime Minister of the Republic of Korea in Seoul, Foreign Minister Prof. G. L. Peiris requested increased opportunities for Sri Lankan workers. The meeting aimed to strengthen bilateral relations between Sri Lanka and South Korea.	Ministry News	2025-09-28 09:13:39.845962
257	20	Special Investment Zone for South Korea Proposed by Foreign Minister Prof. G. L. Peiris	07.01.2022	https://mfa.gov.lk/en/special-investment-zone-fm-sl/	Foreign Minister Prof. G. L. Peiris proposed a Special Investment Zone for South Korea during discussions in Seoul. The meeting focused on trade, investment, political cooperation, defense initiatives, tourism, and labor issues between Sri Lanka and South Korea.	Ministry News	2025-09-28 09:13:39.845962
258	20	​Foreign Minister Prof. G. L. Peiris meets Deputy Prime Minister and Minister of Education of the Republic of Korea in Seoul	06.01.2022	https://mfa.gov.lk/en/fm-sl-meets-korea-dpm/	Foreign Minister Prof. G. L. Peiris discussed assistance for vocational education during a meeting with Deputy Prime Minister and Minister of Education Yoo Eun-hye in Seoul. They held discussions on enhancing cooperation in this area.	Ministry News	2025-09-28 09:13:39.845962
259	20	New Year message of H.E Gotabaya Rajapaksa, President of Sri Lanka -2022	01.01.2022	https://mfa.gov.lk/en/new-year-message-of-h-e-gotabaya-rajapaksa-president-of-sri-lanka-2022/	In his New Year message for 2022, Sri Lankan President Gotabaya Rajapaksa emphasized the importance of unity and solidarity among citizens to overcome challenges and achieve national development goals. He called for collective efforts to build a prosperous and peaceful future for the country.	Ministry News	2025-09-28 09:13:39.845962
\.


--
-- Data for Name: attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f (id, entity_attribute_id, professional_female, semi_skilled_domestic_housekeeping_assistant_female, skilled_female, middle_level_female, middle_level_male, total, clerical___related_female, clerical___related_male, low_skilled_female, low_skilled_male, age_group, professional_male, skilled_male, semi_skilled_other_female, semi_skilled_other_male, created_at) FROM stdin;
1	2	1	0	123	0	24	1782	12	47	111	801	Equal or Below 19	20	621	0	22	2025-09-28 09:13:31.308478
2	2	65	1363	1435	100	465	28286	287	897	2723	10863	20-24	483	8978	56	571	2025-09-28 09:13:31.308478
3	2	380	6142	1570	297	1274	50890	639	1868	4542	16125	25-29	2227	14693	96	1037	2025-09-28 09:13:31.308478
4	2	392	9428	1048	279	1455	51453	521	1920	4980	13100	30-34	3083	14404	77	766	2025-09-28 09:13:31.308478
5	2	264	13089	877	210	1214	50589	323	1644	6179	9861	35-39	2549	13822	47	510	2025-09-28 09:13:31.308478
6	2	159	16388	752	162	995	52036	287	1338	7407	8331	40-44	1868	13910	54	385	2025-09-28 09:13:31.308478
7	2	96	12400	515	133	646	36007	200	877	5526	4669	45-49	1251	9456	25	213	2025-09-28 09:13:31.308478
8	2	109	15197	538	154	722	40013	278	996	5998	4293	Equal or More than 50	1360	10094	57	217	2025-09-28 09:13:31.308478
\.


--
-- Data for Name: attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369 (id, entity_attribute_id, month, number_of_tourist_arrivals, created_at) FROM stdin;
1	34	January	82327	2025-09-28 09:13:45.460146
2	34	February	96507	2025-09-28 09:13:45.460146
3	34	March	106500	2025-09-28 09:13:45.460146
4	34	April	62980	2025-09-28 09:13:45.460146
5	34	May	30207	2025-09-28 09:13:45.460146
6	34	June	32856	2025-09-28 09:13:45.460146
7	34	July	47293	2025-09-28 09:13:45.460146
8	34	August	37760	2025-09-28 09:13:45.460146
9	34	September	29802	2025-09-28 09:13:45.460146
10	34	October	42026	2025-09-28 09:13:45.460146
11	34	November	59759	2025-09-28 09:13:45.460146
12	34	December	91961	2025-09-28 09:13:45.460146
\.


--
-- Data for Name: attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6 (id, entity_attribute_id, professional_male, semi_skilled_others_male, low_skilled_female, low_skilled_male, semi_skilled_others_female, skilled_male, semi_skilled_domestic_housekeeping_assistants_female, middle_level_male, clerical___related_female, clerical___related_male, total, country, professional_female, skilled_female, middle_level_female, created_at) FROM stdin;
1	1	276	432	21453	5829	84	16695	32217	258	301	635	79123	Kuwait	48	827	68	2025-09-28 09:13:30.845128
2	1	1155	291	1795	11454	9	13253	24636	602	13	579	53902	Saudi Arabia	11	89	15	2025-09-28 09:13:30.845128
3	1	485	83	2098	642	9	1213	5434	220	48	176	10669	Oman	44	164	53	2025-09-28 09:13:30.845128
4	1	2358	1159	4408	6220	172	8323	5338	1680	1008	2718	35563	U A E	521	1116	542	2025-09-28 09:13:30.845128
5	1	2973	1130	1374	23002	40	33376	1682	2422	851	4178	71954	Qatar	248	399	279	2025-09-28 09:13:30.845128
6	1	238	29	132	517	14	756	1324	115	45	118	3370	Bahrain	38	33	11	2025-09-28 09:13:30.845128
7	1	0	2	80	183	1	5	1002	1	1	3	1284	Lebanon	0	6	0	2025-09-28 09:13:30.845128
8	1	5	1	1441	464	1	178	835	5	0	1	2964	Cyprus	1	23	9	2025-09-28 09:13:30.845128
9	1	27	9	949	486	5	1006	425	50	24	87	5597	Jordan	4	2514	11	2025-09-28 09:13:30.845128
10	1	248	20	86	680	0	360	288	52	5	25	1941	Malaysia	22	145	10	2025-09-28 09:13:30.845128
11	1	987	21	920	86	11	218	264	241	8	24	3007	Singapore	101	52	74	2025-09-28 09:13:30.845128
12	1	899	217	366	2688	19	3971	227	507	112	561	9916	Maldives	107	143	99	2025-09-28 09:13:30.845128
13	1	25	1	170	42	0	26	215	3	3	5	511	Hong Kong	15	3	3	2025-09-28 09:13:30.845128
14	1	26	110	642	4198	10	2843	39	42	38	106	8679	Romania	3	610	12	2025-09-28 09:13:30.845128
15	1	0	0	8	6	0	2	22	0	0	0	40	Greece	0	0	2	2025-09-28 09:13:30.845128
16	1	33	0	6	2	1	21	19	9	2	2	97	Pakistan	0	1	1	2025-09-28 09:13:30.845128
17	1	11	0	4	3	0	15	9	2	2	0	47	Egypt	0	0	1	2025-09-28 09:13:30.845128
18	1	0	0	1126	441	0	17	9	2	0	0	1632	Israel	0	36	1	2025-09-28 09:13:30.845128
19	1	108	41	42	168	3	1043	7	98	5	68	1606	Seychelles	6	10	7	2025-09-28 09:13:30.845128
20	1	0	0	22	6	0	2	2	1	0	0	36	Italy	0	2	1	2025-09-28 09:13:30.845128
21	1	20	13	8	141	0	77	1	15	1	23	301	Iraq	1	0	1	2025-09-28 09:13:30.845128
22	1	1755	49	108	963	14	826	1	140	54	92	4518	Japan	197	284	35	2025-09-28 09:13:30.845128
23	1	2	1	5	31	1	27	1	6	0	0	77	Kurdistan	0	1	2	2025-09-28 09:13:30.845128
24	1	27	0	0	3	0	5	1	7	0	3	52	Thailand	0	2	4	2025-09-28 09:13:30.845128
25	1	2	3	40	21	0	60	1	4	0	4	138	Turkey	1	1	1	2025-09-28 09:13:30.845128
26	1	8	0	0	1	0	12	1	3	0	1	26	Uganda	0	0	0	2025-09-28 09:13:30.845128
27	1	117	13	32	24	2	86	1	31	1	12	499	United Kingdom	30	105	45	2025-09-28 09:13:30.845128
28	1	0	0	0	13	0	1	0	1	0	3	18	Afghanistan	0	0	0	2025-09-28 09:13:30.845128
29	1	0	0	0	0	0	2	0	0	0	0	2	Africa	0	0	0	2025-09-28 09:13:30.845128
30	1	316	3	2	15	0	73	0	44	2	19	499	Bangladesh	10	8	7	2025-09-28 09:13:30.845128
31	1	20	1	2	16	0	36	0	8	1	8	100	Canada	2	4	2	2025-09-28 09:13:30.845128
32	1	38	1	0	6	0	29	0	17	1	7	101	Ethiopia	0	2	0	2025-09-28 09:13:30.845128
33	1	34	0	0	1	1	4	0	4	0	1	52	Germany	5	2	0	2025-09-28 09:13:30.845128
34	1	0	0	0	0	0	11	0	0	0	0	11	Greenland	0	0	0	2025-09-28 09:13:30.845128
35	1	78	1	2	11	1	49	0	19	3	14	201	India	4	10	8	2025-09-28 09:13:30.845128
36	1	38	0	1	0	0	21	0	23	0	1	85	Indonesia	1	0	0	2025-09-28 09:13:30.845128
37	1	59	2	0	6	1	46	0	4	0	7	132	Ireland	6	0	1	2025-09-28 09:13:30.845128
38	1	16	1	1	3	0	11	0	7	0	3	43	Kenya	0	0	1	2025-09-28 09:13:30.845128
39	1	0	0	0	1	0	4	0	0	0	0	79	Lithuania	0	74	0	2025-09-28 09:13:30.845128
40	1	11	14	19	62	0	40	0	2	1	4	164	Malta	3	3	5	2025-09-28 09:13:30.845128
41	1	4	0	0	0	0	1	0	5	0	3	13	Mozambique	0	0	0	2025-09-28 09:13:30.845128
42	1	71	8	1	35	2	326	0	17	5	15	502	New Zealand	7	8	7	2025-09-28 09:13:30.845128
43	1	59	1	0	8	0	37	0	16	0	4	128	Papua New Guinea	2	1	0	2025-09-28 09:13:30.845128
44	1	16	0	0	0	0	5	0	2	0	0	25	Republic of Dominican	1	0	1	2025-09-28 09:13:30.845128
45	1	0	19	21	237	11	172	0	1	0	0	509	Russia	1	46	1	2025-09-28 09:13:30.845128
46	1	3	0	0	0	0	2	0	2	0	1	10	Rwand	1	0	1	2025-09-28 09:13:30.845128
47	1	6	6	58	9196	0	123	0	2	1	1	9394	South Korea	0	0	1	2025-09-28 09:13:30.845128
48	1	5	0	1	5	0	16	0	1	0	1	29	Sudan	0	0	0	2025-09-28 09:13:30.845128
49	1	33	0	0	4	0	15	0	9	0	2	67	Vietnam	0	4	0	2025-09-28 09:13:30.845128
50	1	249	39	43	123	0	538	6	95	11	72	1343	Other	25	129	13	2025-09-28 09:13:30.845128
\.


--
-- Data for Name: attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932 (id, entity_attribute_id, district, number_of_rooms, created_at) FROM stdin;
1	27	Colombo	8758	2025-09-28 09:13:43.040967
2	27	Galle	8135	2025-09-28 09:13:43.040967
3	27	Gampaha	4261	2025-09-28 09:13:43.040967
4	27	Kaluthara	3809	2025-09-28 09:13:43.040967
5	27	Kandy	3637	2025-09-28 09:13:43.040967
6	27	Matale	2177	2025-09-28 09:13:43.040967
7	27	Matara	2292	2025-09-28 09:13:43.040967
8	27	Nuwara Eliya	2206	2025-09-28 09:13:43.040967
9	27	Hambantota	2088	2025-09-28 09:13:43.040967
10	27	Badulla	1986	2025-09-28 09:13:43.040967
11	27	Anuradhapura	1543	2025-09-28 09:13:43.040967
12	27	Puttalam	1364	2025-09-28 09:13:43.040967
13	27	Batticaloa	869	2025-09-28 09:13:43.040967
14	27	Ampara	725	2025-09-28 09:13:43.040967
15	27	Trincomalee	720	2025-09-28 09:13:43.040967
16	27	Polonnaruwa	615	2025-09-28 09:13:43.040967
17	27	Ratnapura	601	2025-09-28 09:13:43.040967
18	27	Moneragala	604	2025-09-28 09:13:43.040967
19	27	Jaffna	540	2025-09-28 09:13:43.040967
20	27	Kurunegala	520	2025-09-28 09:13:43.040967
21	27	Kegalle	424	2025-09-28 09:13:43.040967
22	27	Vavuniya	77	2025-09-28 09:13:43.040967
23	27	Kilinochchi	85	2025-09-28 09:13:43.040967
24	27	Mullaitivu	58	2025-09-28 09:13:43.040967
25	27	Mannar	26	2025-09-28 09:13:43.040967
\.


--
-- Data for Name: attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0 (id, entity_attribute_id, arrivals, country_of_residence, created_at) FROM stdin;
1	33	39	Afghanistan	2025-09-28 09:13:45.137622
2	33	83	Albania	2025-09-28 09:13:45.137622
3	33	174	Algeria	2025-09-28 09:13:45.137622
4	33	25	Andorra	2025-09-28 09:13:45.137622
5	33	1	Antarctica	2025-09-28 09:13:45.137622
6	33	13	Angola	2025-09-28 09:13:45.137622
7	33	16	Antigua & Barbuda	2025-09-28 09:13:45.137622
8	33	268	Argentina	2025-09-28 09:13:45.137622
9	33	779	Armenia	2025-09-28 09:13:45.137622
10	33	30924	Australia	2025-09-28 09:13:45.137622
11	33	5541	Austria	2025-09-28 09:13:45.137622
12	33	781	Azerbaijan	2025-09-28 09:13:45.137622
13	33	2	Bahamas	2025-09-28 09:13:45.137622
14	33	510	Bahrain	2025-09-28 09:13:45.137622
15	33	3817	Bangladesh	2025-09-28 09:13:45.137622
16	33	13	Barbados	2025-09-28 09:13:45.137622
17	33	3621	Belarus	2025-09-28 09:13:45.137622
18	33	6164	Belgium	2025-09-28 09:13:45.137622
19	33	2	Belize	2025-09-28 09:13:45.137622
20	33	1	Benin	2025-09-28 09:13:45.137622
21	33	139	Bhutan	2025-09-28 09:13:45.137622
22	33	37	Bolivia	2025-09-28 09:13:45.137622
23	33	104	Bosnia & Herzegovina	2025-09-28 09:13:45.137622
24	33	15	Botswana	2025-09-28 09:13:45.137622
25	33	669	Brazil	2025-09-28 09:13:45.137622
26	33	16	Brunei Darussalam	2025-09-28 09:13:45.137622
27	33	1643	Bulgaria	2025-09-28 09:13:45.137622
28	33	1	Burkina Faso	2025-09-28 09:13:45.137622
29	33	157	Cambodia	2025-09-28 09:13:45.137622
30	33	7	Cameroon	2025-09-28 09:13:45.137622
31	33	26845	Canada	2025-09-28 09:13:45.137622
32	33	6	Cape Verde	2025-09-28 09:13:45.137622
33	33	5	Chad	2025-09-28 09:13:45.137622
34	33	182	Chile	2025-09-28 09:13:45.137622
35	33	4715	China	2025-09-28 09:13:45.137622
36	33	304	Colombia	2025-09-28 09:13:45.137622
37	33	16	Comoros	2025-09-28 09:13:45.137622
38	33	14	Congo, Republic Of.	2025-09-28 09:13:45.137622
39	33	40	Costa Rica	2025-09-28 09:13:45.137622
40	33	1	Cote Divoire	2025-09-28 09:13:45.137622
41	33	338	Croatia	2025-09-28 09:13:45.137622
42	33	19	Cuba	2025-09-28 09:13:45.137622
43	33	390	Cyprus	2025-09-28 09:13:45.137622
44	33	7350	Czech Republic	2025-09-28 09:13:45.137622
45	33	7278	Denmark	2025-09-28 09:13:45.137622
46	33	7	Djibouti	2025-09-28 09:13:45.137622
47	33	37	Dominica	2025-09-28 09:13:45.137622
48	33	8	Dominican Republic	2025-09-28 09:13:45.137622
49	33	59	Ecuador	2025-09-28 09:13:45.137622
50	33	2340	Egypt	2025-09-28 09:13:45.137622
51	33	25	El Salvador	2025-09-28 09:13:45.137622
52	33	3	Equatorial Guinea	2025-09-28 09:13:45.137622
53	33	12	Eritrea	2025-09-28 09:13:45.137622
54	33	978	Estonia	2025-09-28 09:13:45.137622
55	33	56	Ethiopia	2025-09-28 09:13:45.137622
56	33	48	Fiji	2025-09-28 09:13:45.137622
57	33	1500	Finland	2025-09-28 09:13:45.137622
58	33	35482	France	2025-09-28 09:13:45.137622
59	33	3	Gabon	2025-09-28 09:13:45.137622
60	33	1	Gambia	2025-09-28 09:13:45.137622
61	33	792	Georgia	2025-09-28 09:13:45.137622
62	33	55542	Germany	2025-09-28 09:13:45.137622
63	33	29	Ghana	2025-09-28 09:13:45.137622
64	33	899	Greece	2025-09-28 09:13:45.137622
65	33	2	Guam	2025-09-28 09:13:45.137622
66	33	14	Grenada	2025-09-28 09:13:45.137622
67	33	17	Guatemala	2025-09-28 09:13:45.137622
68	33	1	Guinea-Bissau	2025-09-28 09:13:45.137622
69	33	9	Guyana	2025-09-28 09:13:45.137622
70	33	10	Honduras	2025-09-28 09:13:45.137622
71	33	1	Hong Kong	2025-09-28 09:13:45.137622
72	33	1	Haiti	2025-09-28 09:13:45.137622
73	33	2324	Hungary	2025-09-28 09:13:45.137622
74	33	163	Iceland	2025-09-28 09:13:45.137622
75	33	123004	India	2025-09-28 09:13:45.137622
76	33	885	Indonesia	2025-09-28 09:13:45.137622
77	33	4301	Iran	2025-09-28 09:13:45.137622
78	33	1113	Iraq	2025-09-28 09:13:45.137622
79	33	3056	Ireland	2025-09-28 09:13:45.137622
80	33	9326	Israel	2025-09-28 09:13:45.137622
81	33	7449	Italy	2025-09-28 09:13:45.137622
82	33	13	Jamaica	2025-09-28 09:13:45.137622
83	33	3087	Japan	2025-09-28 09:13:45.137622
84	33	2472	Jordan	2025-09-28 09:13:45.137622
85	33	8068	Kazakhstan	2025-09-28 09:13:45.137622
86	33	230	Kenya	2025-09-28 09:13:45.137622
87	33	13	Kosovar	2025-09-28 09:13:45.137622
88	33	952	Kuwait	2025-09-28 09:13:45.137622
89	33	532	Kyrgyzstan	2025-09-28 09:13:45.137622
90	33	29	Lao Peoples	2025-09-28 09:13:45.137622
91	33	1305	Latvia	2025-09-28 09:13:45.137622
92	33	1606	Lebanon	2025-09-28 09:13:45.137622
93	33	3	Lesotho	2025-09-28 09:13:45.137622
94	33	5	Liberia	2025-09-28 09:13:45.137622
95	33	29	Libya	2025-09-28 09:13:45.137622
96	33	27	Liechtenstein	2025-09-28 09:13:45.137622
97	33	2115	Lithuania	2025-09-28 09:13:45.137622
98	33	233	Luxembourg	2025-09-28 09:13:45.137622
99	33	71	Macedonia	2025-09-28 09:13:45.137622
100	33	62	Madagascar	2025-09-28 09:13:45.137622
101	33	15	Malawi	2025-09-28 09:13:45.137622
102	33	2779	Malaysia	2025-09-28 09:13:45.137622
103	33	18880	Maldives	2025-09-28 09:13:45.137622
104	33	3	Mali	2025-09-28 09:13:45.137622
105	33	273	Malta	2025-09-28 09:13:45.137622
106	33	2	Marshall Islands	2025-09-28 09:13:45.137622
107	33	5	Mauritania	2025-09-28 09:13:45.137622
108	33	130	Mauritius	2025-09-28 09:13:45.137622
109	33	334	Mexico	2025-09-28 09:13:45.137622
110	33	1	Micronesia	2025-09-28 09:13:45.137622
111	33	241	Moldova	2025-09-28 09:13:45.137622
112	33	43	Monaco	2025-09-28 09:13:45.137622
113	33	52	Mongolia	2025-09-28 09:13:45.137622
114	33	59	Montenegro	2025-09-28 09:13:45.137622
115	33	446	Morocco	2025-09-28 09:13:45.137622
116	33	14	Mozambique	2025-09-28 09:13:45.137622
117	33	252	Myanmar	2025-09-28 09:13:45.137622
118	33	24	Namibia	2025-09-28 09:13:45.137622
119	33	1065	Nepal	2025-09-28 09:13:45.137622
120	33	11987	Netherlands	2025-09-28 09:13:45.137622
121	33	2866	New Zealand	2025-09-28 09:13:45.137622
122	33	3	Nicaragua	2025-09-28 09:13:45.137622
123	33	27	Nigeria	2025-09-28 09:13:45.137622
124	33	2	Niger	2025-09-28 09:13:45.137622
125	33	5983	Norway	2025-09-28 09:13:45.137622
126	33	876	Oman	2025-09-28 09:13:45.137622
127	33	6260	Pakistan	2025-09-28 09:13:45.137622
128	33	366	Palestinian Territories	2025-09-28 09:13:45.137622
129	33	12	Panama	2025-09-28 09:13:45.137622
130	33	21	Papua New Guinea	2025-09-28 09:13:45.137622
131	33	10	Paraguay	2025-09-28 09:13:45.137622
132	33	87	Peru	2025-09-28 09:13:45.137622
133	33	1961	Philippines	2025-09-28 09:13:45.137622
134	33	15195	Poland	2025-09-28 09:13:45.137622
135	33	1906	Portugal	2025-09-28 09:13:45.137622
136	33	301	Qatar	2025-09-28 09:13:45.137622
137	33	10	Republic Of Zimbabwe	2025-09-28 09:13:45.137622
138	33	3313	Romania	2025-09-28 09:13:45.137622
139	33	91272	Russian Federation	2025-09-28 09:13:45.137622
140	33	9	Rwanda	2025-09-28 09:13:45.137622
141	33	46	Saint Kitts And Nevis	2025-09-28 09:13:45.137622
142	33	1	San Marino	2025-09-28 09:13:45.137622
143	33	7	Saint Lucia	2025-09-28 09:13:45.137622
144	33	5952	Saudi Arabia	2025-09-28 09:13:45.137622
145	33	10	Senegal	2025-09-28 09:13:45.137622
146	33	673	Serbia	2025-09-28 09:13:45.137622
147	33	347	Seychelles	2025-09-28 09:13:45.137622
148	33	10	Sierra Leone	2025-09-28 09:13:45.137622
149	33	3770	Singapore	2025-09-28 09:13:45.137622
150	33	2432	Slovakia	2025-09-28 09:13:45.137622
151	33	602	Slovenia	2025-09-28 09:13:45.137622
152	33	1	Solomon Islands	2025-09-28 09:13:45.137622
153	33	18	Somalia	2025-09-28 09:13:45.137622
154	33	1502	South Africa-Zuid Afrika	2025-09-28 09:13:45.137622
155	33	1843	South Korea	2025-09-28 09:13:45.137622
156	33	1	South Sudan	2025-09-28 09:13:45.137622
157	33	12895	Spain	2025-09-28 09:13:45.137622
158	33	818	Sudan	2025-09-28 09:13:45.137622
159	33	5	Suriname	2025-09-28 09:13:45.137622
160	33	4	Swaziland	2025-09-28 09:13:45.137622
161	33	5097	Sweden	2025-09-28 09:13:45.137622
162	33	13260	Switzerland	2025-09-28 09:13:45.137622
163	33	14	Syrian Arab Republic	2025-09-28 09:13:45.137622
164	33	363	Taiwan	2025-09-28 09:13:45.137622
165	33	133	Tajikistan	2025-09-28 09:13:45.137622
166	33	85	Tanzania	2025-09-28 09:13:45.137622
167	33	1725	Thailand	2025-09-28 09:13:45.137622
168	33	2	TIMOR-LESTE	2025-09-28 09:13:45.137622
169	33	4	Togo	2025-09-28 09:13:45.137622
170	33	1	Tonga	2025-09-28 09:13:45.137622
171	33	22	Trinidad And Tobago	2025-09-28 09:13:45.137622
172	33	379	Tunisia	2025-09-28 09:13:45.137622
173	33	1514	Turkey	2025-09-28 09:13:45.137622
174	33	29	Turkmenistan	2025-09-28 09:13:45.137622
175	33	56	Uganda	2025-09-28 09:13:45.137622
176	33	14917	Ukraine	2025-09-28 09:13:45.137622
177	33	1347	United Arab Emirates	2025-09-28 09:13:45.137622
178	33	85187	United Kingdom	2025-09-28 09:13:45.137622
179	33	22230	United States	2025-09-28 09:13:45.137622
180	33	53	Uruguay	2025-09-28 09:13:45.137622
181	33	1242	Uzbekistan	2025-09-28 09:13:45.137622
182	33	10	Vanuatu	2025-09-28 09:13:45.137622
183	33	30	Venezuela	2025-09-28 09:13:45.137622
184	33	519	Vietnam	2025-09-28 09:13:45.137622
185	33	229	Yemen	2025-09-28 09:13:45.137622
186	33	26	Zambia	2025-09-28 09:13:45.137622
187	33	69	Zimbabwe	2025-09-28 09:13:45.137622
\.


--
-- Data for Name: attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8 (id, entity_attribute_id, middle_level, skilled, clerical___related, semi_skilled_domestic_housekeeping_assistants, semi_skilled_others, total, year, professional_level, low_skilled, created_at) FROM stdin;
\.


--
-- Data for Name: attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f (id, entity_attribute_id, age_group, male, female, total, created_at) FROM stdin;
1	3	<=19	1535	247	1782	2025-09-28 09:13:31.830897
2	3	20-24	22257	6029	28286	2025-09-28 09:13:31.830897
3	3	25-29	37224	13666	50890	2025-09-28 09:13:31.830897
4	3	30-34	34728	16725	51453	2025-09-28 09:13:31.830897
5	3	35-39	29600	20989	50589	2025-09-28 09:13:31.830897
6	3	40-44	26827	25209	52036	2025-09-28 09:13:31.830897
7	3	45-49	17112	18895	36007	2025-09-28 09:13:31.830897
8	3	>=50	17685	22331	40013	2025-09-28 09:13:31.830897
\.


--
-- Data for Name: attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee (id, entity_attribute_id, middle_level_male, skilled_male, semi_skilled_domestic_housekeeping_assistants, middle_level_female, low_skilled_female, total, professional_female, professional_male, skilled_female, semi_skilled_others_female, clerical___related_female, low_skilled_male, district, semi_skilled_others_male, clerical___related_male, created_at) FROM stdin;
1	6	477	8816	1738	11	603	20374	12	990	78	6	56	6568	Ampara	167	852	2025-09-28 09:13:33.11859
2	6	141	3513	5208	29	2719	14487	18	245	357	15	66	1865	Anuradhapura	84	227	2025-09-28 09:13:33.11859
3	6	103	1561	3109	13	1306	7765	20	172	144	22	38	1079	Badulla	54	144	2025-09-28 09:13:33.11859
4	6	421	8107	3128	10	810	22086	14	428	62	2	50	8186	Batticaloa	164	704	2025-09-28 09:13:33.11859
5	6	1581	8571	6424	416	3715	34704	546	3248	930	79	716	6000	Colombo	614	1864	2025-09-28 09:13:33.11859
6	6	301	3947	3601	63	1967	15330	63	490	470	23	113	3534	Galle	387	371	2025-09-28 09:13:33.11859
7	6	1028	8660	5476	280	3912	30871	303	1880	1053	71	503	5811	Gampaha	460	1434	2025-09-28 09:13:33.11859
8	6	80	1206	1240	26	824	5837	15	144	230	10	44	1860	Hambantota	48	110	2025-09-28 09:13:33.11859
9	6	115	1868	234	6	79	4649	13	313	19	1	7	1711	Jaffna	120	163	2025-09-28 09:13:33.11859
10	6	373	4873	4136	79	1942	17323	91	617	547	21	150	3521	Kalutara	290	593	2025-09-28 09:13:33.11859
11	6	737	7820	7498	110	3535	30672	116	1757	515	45	207	6850	Kandy	469	1013	2025-09-28 09:13:33.11859
12	6	220	3016	2711	44	1381	10740	32	450	273	7	75	2145	Kegalle	102	284	2025-09-28 09:13:33.11859
13	6	8	127	96	0	33	437	2	9	6	1	1	130	Kilinochchi	10	14	2025-09-28 09:13:33.11859
14	6	349	6926	7681	90	4535	26135	74	642	655	37	190	4299	Kurunegala	167	490	2025-09-28 09:13:33.11859
15	6	13	378	270	2	77	1151	2	28	12	0	3	328	Mannar	12	26	2025-09-28 09:13:33.11859
16	6	159	2148	2449	25	1537	8601	18	249	138	14	55	1469	Matale	117	223	2025-09-28 09:13:33.11859
17	6	123	1533	1259	28	708	6963	23	254	226	11	47	2522	Matara	78	151	2025-09-28 09:13:33.11859
18	6	38	567	695	6	354	2446	2	53	96	4	11	551	Monaragala	23	46	2025-09-28 09:13:33.11859
19	6	4	119	92	0	39	376	0	10	5	0	1	99	Mullaitivu	6	1	2025-09-28 09:13:33.11859
20	6	22	551	3426	3	701	5463	6	32	85	2	13	517	Nuwara Eliya	41	64	2025-09-28 09:13:33.11859
21	6	86	2055	2576	9	1316	7535	8	87	188	6	39	1012	Polonnaruwa	26	127	2025-09-28 09:13:33.11859
22	6	201	4515	4024	55	2457	15779	42	324	358	23	91	3249	Puttalam	133	307	2025-09-28 09:13:33.11859
23	6	102	1495	3221	22	1392	9362	27	213	327	10	41	2302	Ratnapura	63	147	2025-09-28 09:13:33.11859
24	6	88	3016	3063	6	1285	9965	10	151	63	2	24	2010	Trincomalee	69	178	2025-09-28 09:13:33.11859
25	6	25	590	652	2	239	2905	9	55	21	0	6	425	Vavuniya	17	54	2025-09-28 09:13:33.11859
\.


--
-- Data for Name: attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8 (id, entity_attribute_id, province, number_of_rooms, created_at) FROM stdin;
1	26	Western Province	16828	2025-09-28 09:13:42.672743
2	26	Southern Province	12514	2025-09-28 09:13:42.672743
3	26	Central Province	8021	2025-09-28 09:13:42.672743
4	26	Eastern Province	2314	2025-09-28 09:13:42.672743
5	26	Uva Province	2590	2025-09-28 09:13:42.672743
6	26	North Central Province	2158	2025-09-28 09:13:42.672743
7	26	North Western Province	1884	2025-09-28 09:13:42.672743
8	26	Sabaragamuwa Province	1025	2025-09-28 09:13:42.672743
9	26	Northern Province	786	2025-09-28 09:13:42.672743
\.


--
-- Data for Name: attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb (id, entity_attribute_id, link, summary, category, title, date, created_at) FROM stdin;
1	18	https://mfa.gov.lk/en/unocean/	During the UN Ocean Conference in Lisbon, Portugal from June 27 to July 1, 2022, Sri Lanka highlighted its historical significance in international trade by bridging the east and west for over two millennia. Sri Lanka's country statement emphasized its crucial role in connecting global commerce routes.	News From Other Sources	UN Ocean Conference, 27 June to 1 July 2022, Lisbon, Portugal Sri Lanka Country Statement	08.07.2022	2025-09-28 09:13:37.494178
\.


--
-- Data for Name: attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289 (id, entity_attribute_id, number, percentage___, country, created_at) FROM stdin;
\.


--
-- Data for Name: attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c (id, entity_attribute_id, airline, number_of_passengers, created_at) FROM stdin;
1	31	SriLankan Airlines	239556	2025-09-28 09:13:44.470324
2	31	Qatar Airways	123156	2025-09-28 09:13:44.470324
3	31	Emirates	108042	2025-09-28 09:13:44.470324
4	31	IndiGo	35493	2025-09-28 09:13:44.470324
5	31	flydubai	32026	2025-09-28 09:13:44.470324
6	31	Aeroflot	19314	2025-09-28 09:13:44.470324
7	31	Singapore Airlines	18893	2025-09-28 09:13:44.470324
8	31	Turkish Airlines	15695	2025-09-28 09:13:44.470324
9	31	Etihad Airways	15613	2025-09-28 09:13:44.470324
10	31	Air Arabia	15609	2025-09-28 09:13:44.470324
11	31	azur air	11768	2025-09-28 09:13:44.470324
12	31	Air India	11714	2025-09-28 09:13:44.470324
13	31	LOT Polish Airlines	11664	2025-09-28 09:13:44.470324
14	31	SpiceJet	7558	2025-09-28 09:13:44.470324
15	31	air astana	7073	2025-09-28 09:13:44.470324
16	31	OTHERS	46814	2025-09-28 09:13:44.470324
\.


--
-- Data for Name: attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047 (id, entity_attribute_id, year, male__number_, male____, female__number_, female____, total, created_at) FROM stdin;
1	4	2022	186965	60.11	124091	39.89	311056	2025-09-28 09:13:32.37879
\.


--
-- Data for Name: attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d (id, entity_attribute_id, professional_male, semi_skilled_other_male, middle_level_female, clerical___related_female, skilled_female, clerical___related_male, low_skilled_male, professional_female, skilled_male, domestic_housekeeping_assistant_female, low_skilled_female, semi_skilled_other_female, middle_level_male, total, created_at) FROM stdin;
1	7	12841	3721	1335	2547	6858	9587	68043	1466	85978	74007	37466	412	6795	311056	2025-09-28 09:13:33.555957
\.


--
-- Data for Name: attribute_schemas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attribute_schemas (id, table_name, schema_version, schema_definition, created_at) FROM stdin;
1	attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6	1	{"Items": null, "Fields": {"Total": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Country": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Skilled Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Skilled Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Low Skilled Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle Level Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Professional Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Low Skilled Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle Level Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Professional Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Clerical & Related Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi-Skilled Others Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Clerical & Related Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi-Skilled Others Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi-Skilled Domestic housekeeping assistants Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:30.837212
2	attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f	1	{"Items": null, "Fields": {"Total": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Age Group": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Skilled Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Skilled Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Low Skilled Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle Level Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Professional Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Low Skilled Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle Level Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Professional Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Clerical & Related Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi Skilled Other Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Clerical & Related Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi Skilled Other Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi Skilled Domestic Housekeeping Assistant Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:31.300464
3	attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f	1	{"Items": null, "Fields": {"Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Total": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Age Group": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:31.823112
4	attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047	1	{"Items": null, "Fields": {"Year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Total": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Male (%)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Female (%)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Male (Number)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Female (Number)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:32.371843
5	attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8	1	{"Items": null, "Fields": {"Year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Total": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Skilled": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Low skilled": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle Level": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Clerical & Related": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Professional Level": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi-Skilled Others": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi Skilled Domestic housekeeping assistants": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:32.742888
6	attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee	1	{"Items": null, "Fields": {"Total": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "District": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Skilled Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Skilled Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Low Skilled Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle Level Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Professional Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Low Skilled Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle Level Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Professional Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Clerical & Related Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi-Skilled Others Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Clerical & Related Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi-Skilled Others Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi-Skilled Domestic housekeeping assistants": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:33.110728
7	attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d	1	{"Items": null, "Fields": {"Total": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Skilled Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Skilled Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Low-Skilled Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle Level Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Professional Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Low-Skilled Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle Level Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Professional Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Clerical & Related Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi-Skilled Other Male": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Clerical & Related Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Semi-Skilled Other Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Domestic Housekeeping Assistant Female": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:33.547883
8	attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb	1	{"Items": null, "Fields": {"Number": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Country": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Percentage": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:34.039551
9	attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289	1	{"Items": null, "Fields": {"Number": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Country": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Percentage(%)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:34.408896
10	attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165	1	{"Items": null, "Fields": {"Year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Complaints Received": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:34.67759
11	attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165	1	{"Items": null, "Fields": {"Month": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Earning (Rs. Million)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:35.01039
12	attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165	1	{"Items": null, "Fields": {"Month": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Number of persons": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:35.529167
13	attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165	1	{"Items": null, "Fields": {"Month": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Number of arrivals": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:35.812149
14	attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165	1	{"Items": null, "Fields": {"Year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Complaints Resolved": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:36.067926
15	attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165	1	{"Items": null, "Fields": {"Year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Remittances Total (Rs. Million)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Remittances Total (US$ Million)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Remittances Middle East (Rs. Million)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Remittances Middle East (US$ Million)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Middle East as a % of total remittance": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:36.376487
16	attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165	1	{"Items": null, "Fields": {"(Rs)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Ref. No.": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Division Activities": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:36.664936
17	attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165	1	{"Items": null, "Fields": {"Year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Number of Raids conducted": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Number of Successful Raids": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:36.933194
18	attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb	1	{"Items": null, "Fields": {"Date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Link": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Title": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Summary": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:37.486929
27	attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932	1	{"Items": null, "Fields": {"District": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Number of Rooms": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:43.031003
19	attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30	1	{"Items": null, "Fields": {"Date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Link": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Title": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Summary": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:38.730149
20	attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387	1	{"Items": null, "Fields": {"Date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Link": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Title": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Summary": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:39.832684
21	attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2	1	{"Items": null, "Fields": {"Category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Existing": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Staff Type": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Approved Cadre": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Vacancy_Excess_Type": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Vacancy_Excess_Count": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:40.226635
22	attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20	1	{"Items": null, "Fields": {"Nationality": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Number of Foreigners with Refused Entry": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:40.459487
23	attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20	1	{"Items": null, "Fields": {"Nationality": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "No. entered": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "No. removed": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:41.346904
24	attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20	1	{"Items": null, "Fields": {"Nationality": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "No. of Persons": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:41.689908
25	attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20	1	{"Items": null, "Fields": {"Nationality": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "No. of Persons": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:41.989634
26	attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8	1	{"Items": null, "Fields": {"Province": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Number of Rooms": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:42.664822
28	attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440	1	{"Items": null, "Fields": {"Year": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Value in USD(Mn)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Value in Rupees(Mn)": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:43.244287
29	attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440	1	{"Items": null, "Fields": {"Share": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Country": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Arrivals": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:43.524714
30	attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1	1	{"Items": null, "Fields": {"May": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "July": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "June": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "April": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "March": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "August": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Country": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "January": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "October": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "December": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "February": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "November": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "September": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:44.097561
31	attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c	1	{"Items": null, "Fields": {"Airline": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Number of Passengers": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:44.463127
32	attr_cat_333e54f020_db905fd311_2022_cat_333e54f020	1	{"Items": null, "Fields": {"Port": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Arrivals": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:44.815875
33	attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0	1	{"Items": null, "Fields": {"Arrivals": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Country of Residence": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:45.127527
34	attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369	1	{"Items": null, "Fields": {"Month": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Number of tourist arrivals": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:45.451753
35	attr_cat_382785f270_f19d1a303a_2022_cat_382785f270	1	{"Items": null, "Fields": {"Purpose": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "Percentage": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-28 09:13:45.764303
\.


--
-- Data for Name: entity_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entity_attributes (id, entity_id, attribute_name, table_name, schema_version, created_at) FROM stdin;
1	cat_48c98ee4a6	7a7c0dbcf7_2022_cat_48c98ee4a6	attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6	1	2025-09-28 09:13:30.842239
2	cat_3f2863d75f	3f6a9c67d9_2022_cat_3f2863d75f	attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f	1	2025-09-28 09:13:31.305983
3	cat_a046794d1f	367c1f457e_2022_cat_a046794d1f	attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f	1	2025-09-28 09:13:31.828502
4	cat_eaa3f03047	6452a0a58d_2022_cat_eaa3f03047	attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047	1	2025-09-28 09:13:32.376437
5	cat_999a059ca8	ee9a492c7f_2022_cat_999a059ca8	attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8	1	2025-09-28 09:13:32.74885
6	cat_ae618ce2ee	8b50a5c9d0_2022_cat_ae618ce2ee	attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee	1	2025-09-28 09:13:33.116201
7	cat_eee2f0139d	4a7b813f99_2022_cat_eee2f0139d	attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d	1	2025-09-28 09:13:33.553491
8	cat_11d7d6a4bb	e0c576d13b_2022_cat_11d7d6a4bb	attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb	1	2025-09-28 09:13:34.044275
9	cat_d4e0796289	c4f6c245cd_2022_cat_d4e0796289	attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289	1	2025-09-28 09:13:34.413469
10	2153-12_dep_165	e8245521e1_2022_2153-12_dep_165	attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165	1	2025-09-28 09:13:34.683029
11	2153-12_dep_165	c1cb957af9_2022_2153-12_dep_165	attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165	1	2025-09-28 09:13:35.018589
12	2153-12_dep_165	fd13d3fdd7_2022_2153-12_dep_165	attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165	1	2025-09-28 09:13:35.538148
13	2153-12_dep_165	32b5b4b140_2022_2153-12_dep_165	attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165	1	2025-09-28 09:13:35.816948
14	2153-12_dep_165	3ee0fd7e69_2022_2153-12_dep_165	attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165	1	2025-09-28 09:13:36.0726
15	2153-12_dep_165	2efbe2dc16_2022_2153-12_dep_165	attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165	1	2025-09-28 09:13:36.381667
16	2153-12_dep_165	bb18c931f5_2022_2153-12_dep_165	attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165	1	2025-09-28 09:13:36.669759
17	2153-12_dep_165	1f4cc86af0_2022_2153-12_dep_165	attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165	1	2025-09-28 09:13:36.937861
18	cat_baa4a237eb	fe95666d76_2022_cat_baa4a237eb	attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb	1	2025-09-28 09:13:37.491622
19	cat_0758fcbe30	fe95666d76_2022_cat_0758fcbe30	attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30	1	2025-09-28 09:13:38.737428
20	cat_3e91bc3387	fe95666d76_2022_cat_3e91bc3387	attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387	1	2025-09-28 09:13:39.839412
21	2268-51_min_2	216b6b9795_2022_2268-51_min_2	attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2	1	2025-09-28 09:13:40.231836
22	2153-12_dep_20	0776a5328b_2022_2153-12_dep_20	attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20	1	2025-09-28 09:13:40.464087
23	2153-12_dep_20	afad8dc14d_2022_2153-12_dep_20	attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20	1	2025-09-28 09:13:41.353741
24	2153-12_dep_20	ddb3b28098_2022_2153-12_dep_20	attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20	1	2025-09-28 09:13:41.694861
25	2153-12_dep_20	4604d6237a_2022_2153-12_dep_20	attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20	1	2025-09-28 09:13:41.994325
26	cat_b400cbb1c8	1a04c3567d_2022_cat_b400cbb1c8	attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8	1	2025-09-28 09:13:42.670352
27	cat_525b7a9932	23892ae96e_2022_cat_525b7a9932	attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932	1	2025-09-28 09:13:43.038017
28	2153-12_dep_440	cd65eefa04_2022_2153-12_dep_440	attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440	1	2025-09-28 09:13:43.25125
29	2153-12_dep_440	b3c26bb079_2022_2153-12_dep_440	attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440	1	2025-09-28 09:13:43.529935
30	cat_2660d24ee1	3d37716277_2022_cat_2660d24ee1	attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1	1	2025-09-28 09:13:44.10641
31	cat_e30bbf201c	12af00bc2a_2022_cat_e30bbf201c	attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c	1	2025-09-28 09:13:44.468147
32	cat_333e54f020	db905fd311_2022_cat_333e54f020	attr_cat_333e54f020_db905fd311_2022_cat_333e54f020	1	2025-09-28 09:13:44.821409
33	cat_8b6d10c5b0	8508753bee_2022_cat_8b6d10c5b0	attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0	1	2025-09-28 09:13:45.134353
34	cat_4412441369	4fea7f1a45_2022_cat_4412441369	attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369	1	2025-09-28 09:13:45.457303
35	cat_382785f270	f19d1a303a_2022_cat_382785f270	attr_cat_382785f270_f19d1a303a_2022_cat_382785f270	1	2025-09-28 09:13:45.774175
\.


--
-- Name: attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_id_seq', 1, true);


--
-- Name: attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_id_seq', 1, true);


--
-- Name: attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_id_seq', 12, true);


--
-- Name: attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_id_seq', 1, true);


--
-- Name: attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_id_seq', 4, true);


--
-- Name: attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_id_seq', 12, true);


--
-- Name: attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_id_seq', 1, true);


--
-- Name: attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_id_seq', 12, true);


--
-- Name: attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_id_seq', 35, true);


--
-- Name: attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_id_seq', 9, true);


--
-- Name: attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_id_seq', 17, true);


--
-- Name: attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_id_seq', 12, true);


--
-- Name: attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_id_seq', 10, true);


--
-- Name: attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_id_seq', 1, true);


--
-- Name: attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_id_seq', 9, true);


--
-- Name: attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_id_seq', 398, true);


--
-- Name: attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_id_seq', 58, true);


--
-- Name: attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_id_seq', 187, true);


--
-- Name: attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_id_seq', 5, true);


--
-- Name: attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_id_seq', 10, true);


--
-- Name: attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_id_seq', 259, true);


--
-- Name: attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_id_seq', 8, true);


--
-- Name: attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_id_seq', 12, true);


--
-- Name: attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_id_seq', 50, true);


--
-- Name: attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_id_seq', 25, true);


--
-- Name: attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_id_seq', 187, true);


--
-- Name: attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_id_seq', 1, false);


--
-- Name: attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_id_seq', 8, true);


--
-- Name: attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_id_seq', 25, true);


--
-- Name: attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_id_seq', 9, true);


--
-- Name: attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_id_seq', 1, true);


--
-- Name: attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_id_seq', 1, false);


--
-- Name: attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_id_seq', 16, true);


--
-- Name: attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_id_seq', 1, true);


--
-- Name: attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_id_seq', 1, true);


--
-- Name: attribute_schemas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attribute_schemas_id_seq', 35, true);


--
-- Name: entity_attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.entity_attributes_id_seq', 35, true);


--
-- Name: attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165 attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165 attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165 attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165 attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165 attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165 attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165 attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165 attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20 attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20
    ADD CONSTRAINT attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20 attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20
    ADD CONSTRAINT attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20 attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20
    ADD CONSTRAINT attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20 attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20
    ADD CONSTRAINT attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440 attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440
    ADD CONSTRAINT attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440 attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440
    ADD CONSTRAINT attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440_pkey PRIMARY KEY (id);


--
-- Name: attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2 attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2
    ADD CONSTRAINT attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30 attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30
    ADD CONSTRAINT attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb
    ADD CONSTRAINT attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1 attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1
    ADD CONSTRAINT attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_333e54f020_db905fd311_2022_cat_333e54f020 attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020
    ADD CONSTRAINT attr_cat_333e54f020_db905fd311_2022_cat_333e54f020_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_382785f270_f19d1a303a_2022_cat_382785f270 attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270
    ADD CONSTRAINT attr_cat_382785f270_f19d1a303a_2022_cat_382785f270_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387 attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387
    ADD CONSTRAINT attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f
    ADD CONSTRAINT attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369 attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369
    ADD CONSTRAINT attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6 attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6
    ADD CONSTRAINT attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932 attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932
    ADD CONSTRAINT attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0 attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0
    ADD CONSTRAINT attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8 attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8
    ADD CONSTRAINT attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f
    ADD CONSTRAINT attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee
    ADD CONSTRAINT attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8 attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8
    ADD CONSTRAINT attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb
    ADD CONSTRAINT attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289 attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289
    ADD CONSTRAINT attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c
    ADD CONSTRAINT attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047 attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047
    ADD CONSTRAINT attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047_pkey PRIMARY KEY (id);


--
-- Name: attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d
    ADD CONSTRAINT attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d_pkey PRIMARY KEY (id);


--
-- Name: attribute_schemas attribute_schemas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attribute_schemas
    ADD CONSTRAINT attribute_schemas_pkey PRIMARY KEY (id);


--
-- Name: attribute_schemas attribute_schemas_table_name_schema_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attribute_schemas
    ADD CONSTRAINT attribute_schemas_table_name_schema_version_key UNIQUE (table_name, schema_version);


--
-- Name: entity_attributes entity_attributes_entity_id_attribute_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_attributes
    ADD CONSTRAINT entity_attributes_entity_id_attribute_name_key UNIQUE (entity_id, attribute_name);


--
-- Name: entity_attributes entity_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_attributes
    ADD CONSTRAINT entity_attributes_pkey PRIMARY KEY (id);


--
-- Name: attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165 attr__2153_12_dep_165__1f4cc86af0_2022_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__1f4cc86af0_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165__1f4cc86af0_2022_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165 attr__2153_12_dep_165__2efbe2dc16_2022_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__2efbe2dc16_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165__2efbe2dc16_2022_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165 attr__2153_12_dep_165__32b5b4b140_2022_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__32b5b4b140_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165__32b5b4b140_2022_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165 attr__2153_12_dep_165__3ee0fd7e69_2022_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165__3ee0fd7e69_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165__3ee0fd7e69_2022_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165 attr__2153_12_dep_165_bb18c931f5_2022__entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_bb18c931f5_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165_bb18c931f5_2022__entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165 attr__2153_12_dep_165_c1cb957af9_2022__entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_c1cb957af9_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165_c1cb957af9_2022__entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165 attr__2153_12_dep_165_e8245521e1_2022__entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_e8245521e1_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165_e8245521e1_2022__entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165 attr__2153_12_dep_165_fd13d3fdd7_2022__entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_165_fd13d3fdd7_2022_2153_12_dep_165
    ADD CONSTRAINT attr__2153_12_dep_165_fd13d3fdd7_2022__entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20 attr__2153_12_dep_20__0776a5328b_2022__entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20__0776a5328b_2022_2153_12_dep_20
    ADD CONSTRAINT attr__2153_12_dep_20__0776a5328b_2022__entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20 attr__2153_12_dep_20__4604d6237a_2022__entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20__4604d6237a_2022_2153_12_dep_20
    ADD CONSTRAINT attr__2153_12_dep_20__4604d6237a_2022__entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20 attr__2153_12_dep_20_afad8dc14d_2022_2_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20_afad8dc14d_2022_2153_12_dep_20
    ADD CONSTRAINT attr__2153_12_dep_20_afad8dc14d_2022_2_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20 attr__2153_12_dep_20_ddb3b28098_2022_2_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_20_ddb3b28098_2022_2153_12_dep_20
    ADD CONSTRAINT attr__2153_12_dep_20_ddb3b28098_2022_2_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440 attr__2153_12_dep_440_b3c26bb079_2022__entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_440_b3c26bb079_2022_2153_12_dep_440
    ADD CONSTRAINT attr__2153_12_dep_440_b3c26bb079_2022__entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440 attr__2153_12_dep_440_cd65eefa04_2022__entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2153_12_dep_440_cd65eefa04_2022_2153_12_dep_440
    ADD CONSTRAINT attr__2153_12_dep_440_cd65eefa04_2022__entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2 attr__2268_51_min_2__216b6b9795_2022_2_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr__2268_51_min_2__216b6b9795_2022_2268_51_min_2
    ADD CONSTRAINT attr__2268_51_min_2__216b6b9795_2022_2_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30 attr_cat_0758fcbe30_fe95666d76_2022_ca_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_0758fcbe30_fe95666d76_2022_cat_0758fcbe30
    ADD CONSTRAINT attr_cat_0758fcbe30_fe95666d76_2022_ca_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb attr_cat_11d7d6a4bb_e0c576d13b_2022_ca_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_11d7d6a4bb_e0c576d13b_2022_cat_11d7d6a4bb
    ADD CONSTRAINT attr_cat_11d7d6a4bb_e0c576d13b_2022_ca_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1 attr_cat_2660d24ee1__3d37716277_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_2660d24ee1__3d37716277_2022_cat_2660d24ee1
    ADD CONSTRAINT attr_cat_2660d24ee1__3d37716277_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_333e54f020_db905fd311_2022_cat_333e54f020 attr_cat_333e54f020_db905fd311_2022_ca_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_333e54f020_db905fd311_2022_cat_333e54f020
    ADD CONSTRAINT attr_cat_333e54f020_db905fd311_2022_ca_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_382785f270_f19d1a303a_2022_cat_382785f270 attr_cat_382785f270_f19d1a303a_2022_ca_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_382785f270_f19d1a303a_2022_cat_382785f270
    ADD CONSTRAINT attr_cat_382785f270_f19d1a303a_2022_ca_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387 attr_cat_3e91bc3387_fe95666d76_2022_ca_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_3e91bc3387_fe95666d76_2022_cat_3e91bc3387
    ADD CONSTRAINT attr_cat_3e91bc3387_fe95666d76_2022_ca_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f attr_cat_3f2863d75f__3f6a9c67d9_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_3f2863d75f__3f6a9c67d9_2022_cat_3f2863d75f
    ADD CONSTRAINT attr_cat_3f2863d75f__3f6a9c67d9_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369 attr_cat_4412441369__4fea7f1a45_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_4412441369__4fea7f1a45_2022_cat_4412441369
    ADD CONSTRAINT attr_cat_4412441369__4fea7f1a45_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6 attr_cat_48c98ee4a6__7a7c0dbcf7_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_48c98ee4a6__7a7c0dbcf7_2022_cat_48c98ee4a6
    ADD CONSTRAINT attr_cat_48c98ee4a6__7a7c0dbcf7_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932 attr_cat_525b7a9932__23892ae96e_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_525b7a9932__23892ae96e_2022_cat_525b7a9932
    ADD CONSTRAINT attr_cat_525b7a9932__23892ae96e_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0 attr_cat_8b6d10c5b0__8508753bee_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_8b6d10c5b0__8508753bee_2022_cat_8b6d10c5b0
    ADD CONSTRAINT attr_cat_8b6d10c5b0__8508753bee_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8 attr_cat_999a059ca8_ee9a492c7f_2022_ca_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_999a059ca8_ee9a492c7f_2022_cat_999a059ca8
    ADD CONSTRAINT attr_cat_999a059ca8_ee9a492c7f_2022_ca_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f attr_cat_a046794d1f__367c1f457e_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_a046794d1f__367c1f457e_2022_cat_a046794d1f
    ADD CONSTRAINT attr_cat_a046794d1f__367c1f457e_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee attr_cat_ae618ce2ee__8b50a5c9d0_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_ae618ce2ee__8b50a5c9d0_2022_cat_ae618ce2ee
    ADD CONSTRAINT attr_cat_ae618ce2ee__8b50a5c9d0_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8 attr_cat_b400cbb1c8__1a04c3567d_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_b400cbb1c8__1a04c3567d_2022_cat_b400cbb1c8
    ADD CONSTRAINT attr_cat_b400cbb1c8__1a04c3567d_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb attr_cat_baa4a237eb_fe95666d76_2022_ca_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_baa4a237eb_fe95666d76_2022_cat_baa4a237eb
    ADD CONSTRAINT attr_cat_baa4a237eb_fe95666d76_2022_ca_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289 attr_cat_d4e0796289_c4f6c245cd_2022_ca_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_d4e0796289_c4f6c245cd_2022_cat_d4e0796289
    ADD CONSTRAINT attr_cat_d4e0796289_c4f6c245cd_2022_ca_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c attr_cat_e30bbf201c__12af00bc2a_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_e30bbf201c__12af00bc2a_2022_cat_e30bbf201c
    ADD CONSTRAINT attr_cat_e30bbf201c__12af00bc2a_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047 attr_cat_eaa3f03047__6452a0a58d_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_eaa3f03047__6452a0a58d_2022_cat_eaa3f03047
    ADD CONSTRAINT attr_cat_eaa3f03047__6452a0a58d_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d attr_cat_eee2f0139d__4a7b813f99_2022_c_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_cat_eee2f0139d__4a7b813f99_2022_cat_eee2f0139d
    ADD CONSTRAINT attr_cat_eee2f0139d__4a7b813f99_2022_c_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- PostgreSQL database dump complete
--

\unrestrict p2rhXKBlKoNhi5jXouG4sluhgKxCOA3aRnbmlNJ7dz9gZSzySJx6BpePky9uBk6

