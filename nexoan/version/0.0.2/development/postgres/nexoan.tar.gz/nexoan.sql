--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Debian 16.9-1.pgdg120+1)
-- Dumped by pg_dump version 16.9 (Debian 16.9-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attr_abc_pvt_ltd_employee_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_abc_pvt_ltd_employee_data (
    id integer NOT NULL,
    entity_attribute_id integer,
    salary double precision NOT NULL,
    join_date timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    emp_id integer NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_abc_pvt_ltd_employee_data OWNER TO postgres;

--
-- Name: attr_abc_pvt_ltd_employee_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_abc_pvt_ltd_employee_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_abc_pvt_ltd_employee_data_id_seq OWNER TO postgres;

--
-- Name: attr_abc_pvt_ltd_employee_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_abc_pvt_ltd_employee_data_id_seq OWNED BY public.attr_abc_pvt_ltd_employee_data.id;


--
-- Name: attr_id_min_a_employee_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_id_min_a_employee_data (
    id integer NOT NULL,
    entity_attribute_id integer,
    name text NOT NULL,
    age integer NOT NULL,
    department text NOT NULL,
    salary double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_id_min_a_employee_data OWNER TO postgres;

--
-- Name: attr_id_min_a_employee_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_id_min_a_employee_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_id_min_a_employee_data_id_seq OWNER TO postgres;

--
-- Name: attr_id_min_a_employee_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_id_min_a_employee_data_id_seq OWNED BY public.attr_id_min_a_employee_data.id;


--
-- Name: attr_id_min_a_multi_rels_budget_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_id_min_a_multi_rels_budget_data (
    id integer NOT NULL,
    entity_attribute_id integer,
    amount double precision NOT NULL,
    quarter text NOT NULL,
    status text NOT NULL,
    category text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_id_min_a_multi_rels_budget_data OWNER TO postgres;

--
-- Name: attr_id_min_a_multi_rels_budget_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_id_min_a_multi_rels_budget_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_id_min_a_multi_rels_budget_data_id_seq OWNER TO postgres;

--
-- Name: attr_id_min_a_multi_rels_budget_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_id_min_a_multi_rels_budget_data_id_seq OWNED BY public.attr_id_min_a_multi_rels_budget_data.id;


--
-- Name: attr_id_min_a_multi_rels_employee_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_id_min_a_multi_rels_employee_data (
    id integer NOT NULL,
    entity_attribute_id integer,
    name text NOT NULL,
    age integer NOT NULL,
    department text NOT NULL,
    salary double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_id_min_a_multi_rels_employee_data OWNER TO postgres;

--
-- Name: attr_id_min_a_multi_rels_employee_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_id_min_a_multi_rels_employee_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_id_min_a_multi_rels_employee_data_id_seq OWNER TO postgres;

--
-- Name: attr_id_min_a_multi_rels_employee_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_id_min_a_multi_rels_employee_data_id_seq OWNED BY public.attr_id_min_a_multi_rels_employee_data.id;


--
-- Name: attr_id_min_a_update_employee_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attr_id_min_a_update_employee_data (
    id integer NOT NULL,
    entity_attribute_id integer,
    department text NOT NULL,
    salary double precision NOT NULL,
    name text NOT NULL,
    age integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attr_id_min_a_update_employee_data OWNER TO postgres;

--
-- Name: attr_id_min_a_update_employee_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attr_id_min_a_update_employee_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attr_id_min_a_update_employee_data_id_seq OWNER TO postgres;

--
-- Name: attr_id_min_a_update_employee_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attr_id_min_a_update_employee_data_id_seq OWNED BY public.attr_id_min_a_update_employee_data.id;


--
-- Name: attribute_schemas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attribute_schemas (
    id integer NOT NULL,
    table_name character varying(255) NOT NULL,
    schema_version integer NOT NULL,
    schema_definition jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attribute_schemas OWNER TO postgres;

--
-- Name: attribute_schemas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attribute_schemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attribute_schemas_id_seq OWNER TO postgres;

--
-- Name: attribute_schemas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attribute_schemas_id_seq OWNED BY public.attribute_schemas.id;


--
-- Name: entity_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entity_attributes (
    id integer NOT NULL,
    entity_id character varying(255) NOT NULL,
    attribute_name character varying(255) NOT NULL,
    table_name character varying(255) NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.entity_attributes OWNER TO postgres;

--
-- Name: entity_attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.entity_attributes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.entity_attributes_id_seq OWNER TO postgres;

--
-- Name: entity_attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.entity_attributes_id_seq OWNED BY public.entity_attributes.id;


--
-- Name: test_internal_filtering_1758191926236708093; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_internal_filtering_1758191926236708093 (
    id integer NOT NULL,
    name text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    entity_attribute_id text
);


ALTER TABLE public.test_internal_filtering_1758191926236708093 OWNER TO postgres;

--
-- Name: test_internal_filtering_1758191926236708093_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_internal_filtering_1758191926236708093_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.test_internal_filtering_1758191926236708093_id_seq OWNER TO postgres;

--
-- Name: test_internal_filtering_1758191926236708093_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_internal_filtering_1758191926236708093_id_seq OWNED BY public.test_internal_filtering_1758191926236708093.id;


--
-- Name: test_tabular_table_1758191926323979260; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_tabular_table_1758191926323979260 (
    id text,
    name text,
    email text,
    department text
);


ALTER TABLE public.test_tabular_table_1758191926323979260 OWNER TO postgres;

--
-- Name: attr_abc_pvt_ltd_employee_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_abc_pvt_ltd_employee_data ALTER COLUMN id SET DEFAULT nextval('public.attr_abc_pvt_ltd_employee_data_id_seq'::regclass);


--
-- Name: attr_id_min_a_employee_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_employee_data ALTER COLUMN id SET DEFAULT nextval('public.attr_id_min_a_employee_data_id_seq'::regclass);


--
-- Name: attr_id_min_a_multi_rels_budget_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_multi_rels_budget_data ALTER COLUMN id SET DEFAULT nextval('public.attr_id_min_a_multi_rels_budget_data_id_seq'::regclass);


--
-- Name: attr_id_min_a_multi_rels_employee_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_multi_rels_employee_data ALTER COLUMN id SET DEFAULT nextval('public.attr_id_min_a_multi_rels_employee_data_id_seq'::regclass);


--
-- Name: attr_id_min_a_update_employee_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_update_employee_data ALTER COLUMN id SET DEFAULT nextval('public.attr_id_min_a_update_employee_data_id_seq'::regclass);


--
-- Name: attribute_schemas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attribute_schemas ALTER COLUMN id SET DEFAULT nextval('public.attribute_schemas_id_seq'::regclass);


--
-- Name: entity_attributes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_attributes ALTER COLUMN id SET DEFAULT nextval('public.entity_attributes_id_seq'::regclass);


--
-- Name: test_internal_filtering_1758191926236708093 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_internal_filtering_1758191926236708093 ALTER COLUMN id SET DEFAULT nextval('public.test_internal_filtering_1758191926236708093_id_seq'::regclass);


--
-- Data for Name: attr_abc_pvt_ltd_employee_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_abc_pvt_ltd_employee_data (id, entity_attribute_id, salary, join_date, is_active, emp_id, name, created_at) FROM stdin;
1	11	75000.5	2024-01-15 09:00:00+00	t	1001	John Doe	2025-09-18 10:39:11.113654
2	11	82000.75	2024-02-01 09:00:00+00	t	1002	Jane Smith	2025-09-18 10:39:11.113654
3	11	65000.25	2024-03-01 09:00:00+00	f	1003	Bob Wilson	2025-09-18 10:39:11.113654
4	11	70000.25	2024-04-01 09:00:00+00	t	1004	Alice Brown	2025-09-18 10:39:11.113654
5	11	80000	2024-05-01 09:00:00+00	t	1005	Charlie Davis	2025-09-18 10:39:11.113654
\.


--
-- Data for Name: attr_id_min_a_employee_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_id_min_a_employee_data (id, entity_attribute_id, name, age, department, salary, created_at) FROM stdin;
1	12	John Doe	30	Engineering	75000.5	2025-09-18 10:39:12.635725
2	12	Jane Smith	25	Marketing	65000	2025-09-18 10:39:12.635725
3	12	Bob Wilson	35	Sales	85000.75	2025-09-18 10:39:12.635725
4	12	Alice Brown	28	Engineering	70000.25	2025-09-18 10:39:12.635725
5	12	Charlie Davis	32	Finance	80000	2025-09-18 10:39:12.635725
\.


--
-- Data for Name: attr_id_min_a_multi_rels_budget_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_id_min_a_multi_rels_budget_data (id, entity_attribute_id, amount, quarter, status, category, created_at) FROM stdin;
1	14	150000.5	Q1	Approved	Infrastructure	2025-09-18 10:39:13.482957
2	14	75000	Q1	Pending	Marketing	2025-09-18 10:39:13.482957
3	14	200000.75	Q2	Approved	Research	2025-09-18 10:39:13.482957
4	14	120000.25	Q1	Approved	Operations	2025-09-18 10:39:13.482957
5	14	45000	Q2	Pending	Training	2025-09-18 10:39:13.482957
\.


--
-- Data for Name: attr_id_min_a_multi_rels_employee_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_id_min_a_multi_rels_employee_data (id, entity_attribute_id, name, age, department, salary, created_at) FROM stdin;
1	13	John Doe	30	Engineering	75000.5	2025-09-18 10:39:13.358191
2	13	Jane Smith	25	Marketing	65000	2025-09-18 10:39:13.358191
3	13	Bob Wilson	35	Sales	85000.75	2025-09-18 10:39:13.358191
4	13	Alice Brown	28	Engineering	70000.25	2025-09-18 10:39:13.358191
5	13	Charlie Davis	32	Finance	80000	2025-09-18 10:39:13.358191
\.


--
-- Data for Name: attr_id_min_a_update_employee_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attr_id_min_a_update_employee_data (id, entity_attribute_id, department, salary, name, age, created_at) FROM stdin;
1	15	Engineering	75000.5	John Doe	30	2025-09-18 10:39:14.102187
2	15	Marketing	65000	Jane Smith	25	2025-09-18 10:39:14.102187
3	15	Sales	85000.75	Bob Wilson	35	2025-09-18 10:39:14.102187
4	15	Engineering	70000.25	Alice Brown	28	2025-09-18 10:39:14.102187
5	15	Finance	80000	Charlie Davis	32	2025-09-18 10:39:14.102187
\.


--
-- Data for Name: attribute_schemas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attribute_schemas (id, table_name, schema_version, schema_definition, created_at) FROM stdin;
1	attr_abc_pvt_ltd_employee_data	1	{"Items": null, "Fields": {"name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "emp_id": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "is_active": {"Items": null, "Fields": null, "TypeInfo": {"Type": "bool", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "join_date": {"Items": null, "Fields": null, "TypeInfo": {"Type": "datetime", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-18 10:39:11.107346
2	attr_id_min_a_employee_data	1	{"Items": null, "Fields": {"id": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "age": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "department": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-18 10:39:12.629256
3	attr_id_min_a_multi_rels_employee_data	1	{"Items": null, "Fields": {"id": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "age": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "department": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-18 10:39:13.352902
4	attr_id_min_a_multi_rels_budget_data	1	{"Items": null, "Fields": {"id": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "amount": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "status": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "quarter": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "category": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-18 10:39:13.475218
5	attr_id_min_a_update_employee_data	1	{"Items": null, "Fields": {"id": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "age": {"Items": null, "Fields": null, "TypeInfo": {"Type": "int", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "name": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "salary": {"Items": null, "Fields": null, "TypeInfo": {"Type": "float", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}, "department": {"Items": null, "Fields": null, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "scalar"}}, "TypeInfo": {"Type": "string", "IsArray": false, "ArrayType": null, "IsNullable": false, "Properties": null}, "Properties": null, "StorageType": "tabular"}	2025-09-18 10:39:14.096906
\.


--
-- Data for Name: entity_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entity_attributes (id, entity_id, attribute_name, table_name, schema_version, created_at) FROM stdin;
2	emp_data	employee_records	attr_emp_data_employee_records	1	2025-09-18 10:38:46.508108
3	inventory	product_stock	attr_inventory_product_stock	1	2025-09-18 10:38:46.531326
4	sensor_data	temperature_readings	attr_sensor_data_temperature_readings	1	2025-09-18 10:38:46.541546
5	id-tabular-entity-1	employees	attr_id_tabular_entity_1_employees	1	2025-09-18 10:38:48.730424
6	id-mixed-entity-1	performance_data	attr_id_mixed_entity_1_performance_data	1	2025-09-18 10:38:49.342218
7	id-complex-tabular-entity-1	employee_data	attr_id_complex_tabular_entity_1_employee_data	1	2025-09-18 10:38:49.587049
8	id-multi-attr-entity-1	personal_data	attr_id_multi_attr_entity_1_personal_data	1	2025-09-18 10:38:49.946617
9	id-multi-attr-entity-1	performance_data	attr_id_multi_attr_entity_1_performance_data	1	2025-09-18 10:38:50.116087
10	engine-id-integration-test-entity-1	tabular_data	attr_engine_id_integration_test_entity_1_tabular_data	1	2025-09-18 10:38:52.442293
11	ABC Pvt Ltd	employee_data	attr_abc_pvt_ltd_employee_data	1	2025-09-18 10:39:11.111082
12	ID-MIN-A	employee_data	attr_id_min_a_employee_data	1	2025-09-18 10:39:12.633951
13	ID-MIN-A-MULTI-RELS	employee_data	attr_id_min_a_multi_rels_employee_data	1	2025-09-18 10:39:13.356477
14	ID-MIN-A-MULTI-RELS	budget_data	attr_id_min_a_multi_rels_budget_data	1	2025-09-18 10:39:13.48065
15	ID-MIN-A-UPDATE	employee_data	attr_id_min_a_update_employee_data	1	2025-09-18 10:39:14.100669
\.


--
-- Data for Name: test_internal_filtering_1758191926236708093; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_internal_filtering_1758191926236708093 (id, name, created_at, entity_attribute_id) FROM stdin;
1	John Doe	2025-09-18 10:38:46.258066	attr_123
2	Jane Smith	2025-09-18 10:38:46.258066	attr_456
\.


--
-- Data for Name: test_tabular_table_1758191926323979260; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_tabular_table_1758191926323979260 (id, name, email, department) FROM stdin;
001	John Doe	john@example.com	Engineering
002	Jane Smith	jane@example.com	Marketing
003	Bob Wilson	bob@example.com	Sales
\.


--
-- Name: attr_abc_pvt_ltd_employee_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_abc_pvt_ltd_employee_data_id_seq', 5, true);


--
-- Name: attr_id_min_a_employee_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_id_min_a_employee_data_id_seq', 1, false);


--
-- Name: attr_id_min_a_multi_rels_budget_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_id_min_a_multi_rels_budget_data_id_seq', 1, false);


--
-- Name: attr_id_min_a_multi_rels_employee_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_id_min_a_multi_rels_employee_data_id_seq', 1, false);


--
-- Name: attr_id_min_a_update_employee_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attr_id_min_a_update_employee_data_id_seq', 1, false);


--
-- Name: attribute_schemas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attribute_schemas_id_seq', 5, true);


--
-- Name: entity_attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.entity_attributes_id_seq', 15, true);


--
-- Name: test_internal_filtering_1758191926236708093_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_internal_filtering_1758191926236708093_id_seq', 2, true);


--
-- Name: attr_abc_pvt_ltd_employee_data attr_abc_pvt_ltd_employee_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_abc_pvt_ltd_employee_data
    ADD CONSTRAINT attr_abc_pvt_ltd_employee_data_pkey PRIMARY KEY (id);


--
-- Name: attr_id_min_a_employee_data attr_id_min_a_employee_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_employee_data
    ADD CONSTRAINT attr_id_min_a_employee_data_pkey PRIMARY KEY (id);


--
-- Name: attr_id_min_a_multi_rels_budget_data attr_id_min_a_multi_rels_budget_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_multi_rels_budget_data
    ADD CONSTRAINT attr_id_min_a_multi_rels_budget_data_pkey PRIMARY KEY (id);


--
-- Name: attr_id_min_a_multi_rels_employee_data attr_id_min_a_multi_rels_employee_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_multi_rels_employee_data
    ADD CONSTRAINT attr_id_min_a_multi_rels_employee_data_pkey PRIMARY KEY (id);


--
-- Name: attr_id_min_a_update_employee_data attr_id_min_a_update_employee_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_update_employee_data
    ADD CONSTRAINT attr_id_min_a_update_employee_data_pkey PRIMARY KEY (id);


--
-- Name: attribute_schemas attribute_schemas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attribute_schemas
    ADD CONSTRAINT attribute_schemas_pkey PRIMARY KEY (id);


--
-- Name: attribute_schemas attribute_schemas_table_name_schema_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attribute_schemas
    ADD CONSTRAINT attribute_schemas_table_name_schema_version_key UNIQUE (table_name, schema_version);


--
-- Name: entity_attributes entity_attributes_entity_id_attribute_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_attributes
    ADD CONSTRAINT entity_attributes_entity_id_attribute_name_key UNIQUE (entity_id, attribute_name);


--
-- Name: entity_attributes entity_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_attributes
    ADD CONSTRAINT entity_attributes_pkey PRIMARY KEY (id);


--
-- Name: test_internal_filtering_1758191926236708093 test_internal_filtering_1758191926236708093_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_internal_filtering_1758191926236708093
    ADD CONSTRAINT test_internal_filtering_1758191926236708093_pkey PRIMARY KEY (id);


--
-- Name: attr_abc_pvt_ltd_employee_data attr_abc_pvt_ltd_employee_data_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_abc_pvt_ltd_employee_data
    ADD CONSTRAINT attr_abc_pvt_ltd_employee_data_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_id_min_a_employee_data attr_id_min_a_employee_data_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_employee_data
    ADD CONSTRAINT attr_id_min_a_employee_data_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_id_min_a_multi_rels_budget_data attr_id_min_a_multi_rels_budget_data_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_multi_rels_budget_data
    ADD CONSTRAINT attr_id_min_a_multi_rels_budget_data_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_id_min_a_multi_rels_employee_data attr_id_min_a_multi_rels_employee_data_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_multi_rels_employee_data
    ADD CONSTRAINT attr_id_min_a_multi_rels_employee_data_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- Name: attr_id_min_a_update_employee_data attr_id_min_a_update_employee_data_entity_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attr_id_min_a_update_employee_data
    ADD CONSTRAINT attr_id_min_a_update_employee_data_entity_attribute_id_fkey FOREIGN KEY (entity_attribute_id) REFERENCES public.entity_attributes(id);


--
-- PostgreSQL database dump complete
--

